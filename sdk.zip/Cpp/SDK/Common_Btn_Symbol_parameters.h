﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function Common_Btn_Symbol.Common_Btn_Symbol_C.Construct
struct UCommon_Btn_Symbol_C_Construct_Params
{
};

// Function Common_Btn_Symbol.Common_Btn_Symbol_C.PreConstruct
struct UCommon_Btn_Symbol_C_PreConstruct_Params
{
	bool                                               IsDesignTime;                                              // 0x0000(0x0001)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function Common_Btn_Symbol.Common_Btn_Symbol_C.ExecuteUbergraph_Common_Btn_Symbol
struct UCommon_Btn_Symbol_C_ExecuteUbergraph_Common_Btn_Symbol_Params
{
	int                                                EntryPoint;                                                // 0x0000(0x0004)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

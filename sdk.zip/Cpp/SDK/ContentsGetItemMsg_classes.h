﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass ContentsGetItemMsg.ContentsGetItemMsg_C
// 0x0858 (FullSize[0x0DE0] - InheritedSize[0x0588])
class UContentsGetItemMsg_C : public UMM_ContentsGetItemMsg
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                            // 0x0588(0x0008) (ZeroConstructor, Transient, DuplicateTransient)
	class UWidgetAnimation*                            Ani_Start_MakeFail_Item;                                   // 0x0590(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                            Ani_Start_MakeSuccessBonus_Item;                           // 0x0598(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                            Ani_Start_MakeSuccess_Item;                                // 0x05A0(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                            ani_end;                                                   // 0x05A8(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                            Ani_Start_Single_Cost;                                     // 0x05B0(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                            Ani_Start_Single_Item;                                     // 0x05B8(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                            Ani_Start_Multiple;                                        // 0x05C0(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                            Ani_Start_Speical;                                         // 0x05C8(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)
	class UMirCanvasPanel*                             EFFECT;                                                    // 0x05D0(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UMirCanvasPanel*                             Effect_Fail;                                               // 0x05D8(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UGridPanel*                                  Grid_AddedOption;                                          // 0x05E0(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UGridPanel*                                  Grid_ItemSlot;                                             // 0x05E8(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UGridPanel*                                  Grid_TitleIcon;                                            // 0x05F0(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UHorizontalBox*                              Hrz_TitleInfoDeco;                                         // 0x05F8(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UImage*                                      Img_Back;                                                  // 0x0600(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UImage*                                      Img_TitleBg;                                               // 0x0608(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UMirImage*                                   Img_TitleIconBg_1;                                         // 0x0610(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UMirImage*                                   Img_TitleIconBg_2;                                         // 0x0618(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UMirRichTextBlock*                           RTxt_TitleSub;                                             // 0x0620(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class USafeZone*                                   SafeZone_1;                                                // 0x0628(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UMirTextBlock*                               Txt_Notice;                                                // 0x0630(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	struct FSlateBrush                                 TitleIcon_SingleItem;                                      // 0x0638(0x0088) (Edit, BlueprintVisible)
	struct FSlateBrush                                 TitleIcon_SingleCost;                                      // 0x06C0(0x0088) (Edit, BlueprintVisible)
	struct FSlateBrush                                 TitleIcon_Multiple;                                        // 0x0748(0x0088) (Edit, BlueprintVisible)
	struct FSlateBrush                                 TitleIcon_Special;                                         // 0x07D0(0x0088) (Edit, BlueprintVisible)
	struct FSlateBrush                                 TitleBg_SingleItem;                                        // 0x0858(0x0088) (Edit, BlueprintVisible)
	struct FSlateBrush                                 TitleBg_SingleCost;                                        // 0x08E0(0x0088) (Edit, BlueprintVisible)
	struct FSlateBrush                                 TitleBg_Multiple;                                          // 0x0968(0x0088) (Edit, BlueprintVisible)
	struct FSlateBrush                                 TitleBg_Special;                                           // 0x09F0(0x0088) (Edit, BlueprintVisible)
	struct FSlateBrush                                 TitleIcon_MakeSuccess_Item;                                // 0x0A78(0x0088) (Edit, BlueprintVisible)
	struct FSlateBrush                                 TitleIcon_MakeSuccessBonus_Item;                           // 0x0B00(0x0088) (Edit, BlueprintVisible)
	struct FSlateBrush                                 TitleIcon_MakeFail_Item;                                   // 0x0B88(0x0088) (Edit, BlueprintVisible)
	struct FVector2D                                   TitleTranslation_SingleItem;                               // 0x0C10(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector2D                                   TitleTranslation_SingleCost;                               // 0x0C18(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector2D                                   TitleTranslation_Multiple;                                 // 0x0C20(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector2D                                   TitleTranslation_Special;                                  // 0x0C28(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector2D                                   TitleTranslation_MakeSuccess_Item;                         // 0x0C30(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector2D                                   TitleTranslation_MakeSuccessBonus_Item;                    // 0x0C38(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FSlateBrush                                 TitleBg_MakwSuccess_Item;                                  // 0x0C40(0x0088) (Edit, BlueprintVisible)
	struct FSlateBrush                                 TitleBg_MakwSuccessBonus_Item;                             // 0x0CC8(0x0088) (Edit, BlueprintVisible)
	struct FVector2D                                   TitleTranslation_MakeFail_Item;                            // 0x0D50(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FSlateBrush                                 TitleBg_MakeFail_Item;                                     // 0x0D58(0x0088) (Edit, BlueprintVisible)


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("WidgetBlueprintGeneratedClass ContentsGetItemMsg.ContentsGetItemMsg_C");
		return ptr;
	}



	void Construct();
	void UpdateDesign();
	void ExecuteUbergraph_ContentsGetItemMsg(int EntryPoint);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

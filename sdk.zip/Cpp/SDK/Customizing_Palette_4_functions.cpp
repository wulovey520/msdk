﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x01C40890
//		Name   -> Function Customizing_Palette_4.Customizing_Palette_3_C.CreatePaletteItem
//		Flags  -> (Event, Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
//		int                                                Count                                                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
//		TArray<class UMM_Customizing_PaletteItem*>         ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, ContainsInstancedReference)
TArray<class UMM_Customizing_PaletteItem*> UCustomizing_Palette_3_C::CreatePaletteItem(int Count)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function Customizing_Palette_4.Customizing_Palette_3_C.CreatePaletteItem");

	UCustomizing_Palette_3_C_CreatePaletteItem_Params params;
	params.Count = Count;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function Customizing_Palette_4.Customizing_Palette_3_C.PreConstruct
//		Flags  -> (BlueprintCosmetic, Event, Public, BlueprintEvent)
// Parameters:
//		bool                                               IsDesignTime                                               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
void UCustomizing_Palette_3_C::PreConstruct(bool IsDesignTime)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function Customizing_Palette_4.Customizing_Palette_3_C.PreConstruct");

	UCustomizing_Palette_3_C_PreConstruct_Params params;
	params.IsDesignTime = IsDesignTime;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function Customizing_Palette_4.Customizing_Palette_3_C.ExecuteUbergraph_Customizing_Palette_4
//		Flags  -> (Final)
// Parameters:
//		int                                                EntryPoint                                                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UCustomizing_Palette_3_C::ExecuteUbergraph_Customizing_Palette_4(int EntryPoint)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function Customizing_Palette_4.Customizing_Palette_3_C.ExecuteUbergraph_Customizing_Palette_4");

	UCustomizing_Palette_3_C_ExecuteUbergraph_Customizing_Palette_4_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ContentsGetItemMsg.ContentsGetItemMsg_C.Construct
struct UContentsGetItemMsg_C_Construct_Params
{
};

// Function ContentsGetItemMsg.ContentsGetItemMsg_C.UpdateDesign
struct UContentsGetItemMsg_C_UpdateDesign_Params
{
};

// Function ContentsGetItemMsg.ContentsGetItemMsg_C.ExecuteUbergraph_ContentsGetItemMsg
struct UContentsGetItemMsg_C_ExecuteUbergraph_ContentsGetItemMsg_Params
{
	int                                                EntryPoint;                                                // 0x0000(0x0004)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

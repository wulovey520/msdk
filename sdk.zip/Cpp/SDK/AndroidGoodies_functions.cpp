﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x0050FDA0
//		Name   -> Function AndroidGoodies.AGAlarmClock.SnoozeAlarm
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		int                                                snoozeDurationMinutes                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGAlarmClock::STATIC_SnoozeAlarm(int snoozeDurationMinutes)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGAlarmClock.SnoozeAlarm");

	UAGAlarmClock_SnoozeAlarm_Params params;
	params.snoozeDurationMinutes = snoozeDurationMinutes;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00423660
//		Name   -> Function AndroidGoodies.AGAlarmClock.ShowAllTimers
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
void UAGAlarmClock::STATIC_ShowAllTimers()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGAlarmClock.ShowAllTimers");

	UAGAlarmClock_ShowAllTimers_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00423660
//		Name   -> Function AndroidGoodies.AGAlarmClock.ShowAllAlarms
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
void UAGAlarmClock::STATIC_ShowAllAlarms()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGAlarmClock.ShowAllAlarms");

	UAGAlarmClock_ShowAllAlarms_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050F6B0
//		Name   -> Function AndroidGoodies.AGAlarmClock.SetTimer
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		int                                                lengthSeconds                                              (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Message                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               skipUi                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGAlarmClock::STATIC_SetTimer(int lengthSeconds, const struct FString& Message, bool skipUi)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGAlarmClock.SetTimer");

	UAGAlarmClock_SetTimer_Params params;
	params.lengthSeconds = lengthSeconds;
	params.Message = Message;
	params.skipUi = skipUi;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050F480
//		Name   -> Function AndroidGoodies.AGAlarmClock.SetAlarm
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		int                                                Hour                                                       (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                Minute                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Message                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FAGAlarmDaysData                            days                                                       (Parm, NoDestructor, NativeAccessSpecifierPublic)
//		bool                                               Vibrate                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               skipUi                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGAlarmClock::STATIC_SetAlarm(int Hour, int Minute, const struct FString& Message, const struct FAGAlarmDaysData& days, bool Vibrate, bool skipUi)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGAlarmClock.SetAlarm");

	UAGAlarmClock_SetAlarm_Params params;
	params.Hour = Hour;
	params.Minute = Minute;
	params.Message = Message;
	params.days = days;
	params.Vibrate = Vibrate;
	params.skipUi = skipUi;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGAlarmClock.CanSetTimer
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGAlarmClock::STATIC_CanSetTimer()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGAlarmClock.CanSetTimer");

	UAGAlarmClock_CanSetTimer_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGAlarmClock.CanSetAlarm
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGAlarmClock::STATIC_CanSetAlarm()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGAlarmClock.CanSetAlarm");

	UAGAlarmClock_CanSetAlarm_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGApps.UninstallPackage
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     PackageName                                                (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGApps::STATIC_UninstallPackage(const struct FString& PackageName)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGApps.UninstallPackage");

	UAGApps_UninstallPackage_Params params;
	params.PackageName = PackageName;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGApps.OpenYoutubeVideo
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     videoId                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGApps::STATIC_OpenYoutubeVideo(const struct FString& videoId)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGApps.OpenYoutubeVideo");

	UAGApps_OpenYoutubeVideo_Params params;
	params.videoId = videoId;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGApps.OpenTwitterProfile
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     profileId                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGApps::STATIC_OpenTwitterProfile(const struct FString& profileId)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGApps.OpenTwitterProfile");

	UAGApps_OpenTwitterProfile_Params params;
	params.profileId = profileId;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGApps.OpenInstagramProfile
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     profileId                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGApps::STATIC_OpenInstagramProfile(const struct FString& profileId)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGApps.OpenInstagramProfile");

	UAGApps_OpenInstagramProfile_Params params;
	params.profileId = profileId;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGApps.OpenFacebookProfile
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     profileId                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGApps::STATIC_OpenFacebookProfile(const struct FString& profileId)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGApps.OpenFacebookProfile");

	UAGApps_OpenFacebookProfile_Params params;
	params.profileId = profileId;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGApps.OpenAnotherApplication
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     PackageName                                                (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGApps::STATIC_OpenAnotherApplication(const struct FString& PackageName)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGApps.OpenAnotherApplication");

	UAGApps_OpenAnotherApplication_Params params;
	params.PackageName = PackageName;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050F310
//		Name   -> Function AndroidGoodies.AGApps.InstallApkFromFile
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		struct FString                                     FilePath                                                   (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             OnError                                                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
void UAGApps::STATIC_InstallApkFromFile(const struct FString& FilePath, const struct FScriptDelegate& OnError)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGApps.InstallApkFromFile");

	UAGApps_InstallApkFromFile_Params params;
	params.FilePath = FilePath;
	params.OnError = OnError;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGApps.HasPhoneApp
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGApps::STATIC_HasPhoneApp()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGApps.HasPhoneApp");

	UAGApps_HasPhoneApp_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EBE0
//		Name   -> Function AndroidGoodies.AGApps.DownloadAndInstallApk
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		struct FString                                     DownloadUrl                                                (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     DownloadTitle                                              (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     DownloadDescription                                        (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             OnError                                                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
void UAGApps::STATIC_DownloadAndInstallApk(const struct FString& DownloadUrl, const struct FString& DownloadTitle, const struct FString& DownloadDescription, const struct FScriptDelegate& OnError)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGApps.DownloadAndInstallApk");

	UAGApps_DownloadAndInstallApk_Params params;
	params.DownloadUrl = DownloadUrl;
	params.DownloadTitle = DownloadTitle;
	params.DownloadDescription = DownloadDescription;
	params.OnError = OnError;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGApps.DialPhoneNumber
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Number                                                     (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGApps::STATIC_DialPhoneNumber(const struct FString& Number)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGApps.DialPhoneNumber");

	UAGApps_DialPhoneNumber_Params params;
	params.Number = Number;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGApps.CallPhoneNumber
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Number                                                     (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGApps::STATIC_CallPhoneNumber(const struct FString& Number)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGApps.CallPhoneNumber");

	UAGApps_CallPhoneNumber_Params params;
	params.Number = Number;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050F450
//		Name   -> Function AndroidGoodies.AGChosenFile.IsSuccess
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGChosenFile::IsSuccess()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenFile.IsSuccess");

	UAGChosenFile_IsSuccess_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F200
//		Name   -> Function AndroidGoodies.AGChosenFile.GetSize
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		int64_t                                            ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int64_t UAGChosenFile::GetSize()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenFile.GetSize");

	UAGChosenFile_GetSize_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGChosenFile.GetOriginalPath
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGChosenFile::GetOriginalPath()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenFile.GetOriginalPath");

	UAGChosenFile_GetOriginalPath_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGChosenFile.GetMimeType
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGChosenFile::GetMimeType()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenFile.GetMimeType");

	UAGChosenFile_GetMimeType_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F0F0
//		Name   -> Function AndroidGoodies.AGChosenFile.GetHumanReadableSize
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               bytesRounded                                               (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGChosenFile::GetHumanReadableSize(bool bytesRounded)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenFile.GetHumanReadableSize");

	UAGChosenFile_GetHumanReadableSize_Params params;
	params.bytesRounded = bytesRounded;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGChosenFile.GetFileExtensionFromMimeTypeWithoutDot
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGChosenFile::GetFileExtensionFromMimeTypeWithoutDot()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenFile.GetFileExtensionFromMimeTypeWithoutDot");

	UAGChosenFile_GetFileExtensionFromMimeTypeWithoutDot_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGChosenFile.GetFileExtensionFromMimeType
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGChosenFile::GetFileExtensionFromMimeType()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenFile.GetFileExtensionFromMimeType");

	UAGChosenFile_GetFileExtensionFromMimeType_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGChosenFile.GetDisplayName
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGChosenFile::GetDisplayName()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenFile.GetDisplayName");

	UAGChosenFile_GetDisplayName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F000
//		Name   -> Function AndroidGoodies.AGChosenFile.GetCreatedAt
//		Flags  -> (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
//		struct FDateTime                                   ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FDateTime UAGChosenFile::GetCreatedAt()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenFile.GetCreatedAt");

	UAGChosenFile_GetCreatedAt_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F0C0
//		Name   -> Function AndroidGoodies.AGChosenImage.GetWidth
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGChosenImage::GetWidth()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenImage.GetWidth");

	UAGChosenImage_GetWidth_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGChosenImage.GetThumbnailSmallPath
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGChosenImage::GetThumbnailSmallPath()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenImage.GetThumbnailSmallPath");

	UAGChosenImage_GetThumbnailSmallPath_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGChosenImage.GetThumbnailPath
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGChosenImage::GetThumbnailPath()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenImage.GetThumbnailPath");

	UAGChosenImage_GetThumbnailPath_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGChosenImage.GetOrientationName
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGChosenImage::GetOrientationName()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenImage.GetOrientationName");

	UAGChosenImage_GetOrientationName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F0C0
//		Name   -> Function AndroidGoodies.AGChosenImage.GetOrientation
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGChosenImage::GetOrientation()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenImage.GetOrientation");

	UAGChosenImage_GetOrientation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F0C0
//		Name   -> Function AndroidGoodies.AGChosenImage.GetHeight
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGChosenImage::GetHeight()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGChosenImage.GetHeight");

	UAGChosenImage_GetHeight_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGContactsBPL.GetUserPhoneNumber
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGContactsBPL::STATIC_GetUserPhoneNumber()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGContactsBPL.GetUserPhoneNumber");

	UAGContactsBPL_GetUserPhoneNumber_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EF00
//		Name   -> Function AndroidGoodies.AGContactsBPL.GetContactsWithNumber
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Number                                                     (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TArray<struct FAGContact>                          ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
TArray<struct FAGContact> UAGContactsBPL::STATIC_GetContactsWithNumber(const struct FString& Number)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGContactsBPL.GetContactsWithNumber");

	UAGContactsBPL_GetContactsWithNumber_Params params;
	params.Number = Number;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EF00
//		Name   -> Function AndroidGoodies.AGContactsBPL.GetContactsWithName
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Name                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TArray<struct FAGContact>                          ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
TArray<struct FAGContact> UAGContactsBPL::STATIC_GetContactsWithName(const struct FString& Name)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGContactsBPL.GetContactsWithName");

	UAGContactsBPL_GetContactsWithName_Params params;
	params.Name = Name;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE30
//		Name   -> Function AndroidGoodies.AGContactsBPL.GetAllContacts
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		TArray<struct FAGContact>                          ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
TArray<struct FAGContact> UAGContactsBPL::STATIC_GetAllContacts()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGContactsBPL.GetAllContacts");

	UAGContactsBPL_GetAllContacts_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050E970
//		Name   -> Function AndroidGoodies.AGContactsBPL.AddContact
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FAGContact                                  contact                                                    (Parm, NativeAccessSpecifierPublic)
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGContactsBPL::STATIC_AddContact(const struct FAGContact& contact)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGContactsBPL.AddContact");

	UAGContactsBPL_AddContact_Params params;
	params.contact = contact;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050FBA0
//		Name   -> Function AndroidGoodies.AGDateTimePickerBPL.ShowTimePicker
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		int                                                Hour                                                       (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                Minute                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onTimeSetCallback                                          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onCancelCallback                                           (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               is24HourView                                               (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGDateTimePickerBPL::STATIC_ShowTimePicker(int Hour, int Minute, const struct FScriptDelegate& onTimeSetCallback, const struct FScriptDelegate& onCancelCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme, bool is24HourView)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDateTimePickerBPL.ShowTimePicker");

	UAGDateTimePickerBPL_ShowTimePicker_Params params;
	params.Hour = Hour;
	params.Minute = Minute;
	params.onTimeSetCallback = onTimeSetCallback;
	params.onCancelCallback = onCancelCallback;
	params.Theme = Theme;
	params.is24HourView = is24HourView;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050F9A0
//		Name   -> Function AndroidGoodies.AGDateTimePickerBPL.ShowDatePickerWithLimits
//		Flags  -> (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
//		struct FDateTime                                   initialDate                                                (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onDateSetCallback                                          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onCancelCallback                                           (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FDateTime                                   fromDate                                                   (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FDateTime                                   toDate                                                     (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGDateTimePickerBPL::STATIC_ShowDatePickerWithLimits(const struct FDateTime& initialDate, const struct FScriptDelegate& onDateSetCallback, const struct FScriptDelegate& onCancelCallback, const struct FDateTime& fromDate, const struct FDateTime& toDate, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDateTimePickerBPL.ShowDatePickerWithLimits");

	UAGDateTimePickerBPL_ShowDatePickerWithLimits_Params params;
	params.initialDate = initialDate;
	params.onDateSetCallback = onDateSetCallback;
	params.onCancelCallback = onCancelCallback;
	params.fromDate = fromDate;
	params.toDate = toDate;
	params.Theme = Theme;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050F800
//		Name   -> Function AndroidGoodies.AGDateTimePickerBPL.ShowDatePicker
//		Flags  -> (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
//		struct FDateTime                                   initialDate                                                (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onDateSetCallback                                          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onCancelCallback                                           (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGDateTimePickerBPL::STATIC_ShowDatePicker(const struct FDateTime& initialDate, const struct FScriptDelegate& onDateSetCallback, const struct FScriptDelegate& onCancelCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDateTimePickerBPL.ShowDatePicker");

	UAGDateTimePickerBPL_ShowDatePicker_Params params;
	params.initialDate = initialDate;
	params.onDateSetCallback = onDateSetCallback;
	params.onCancelCallback = onCancelCallback;
	params.Theme = Theme;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsWifiRtt
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsWifiRtt()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsWifiRtt");

	UAGDeviceInfo_SupportsWifiRtt_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsWifiPassPoint
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsWifiPassPoint()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsWifiPassPoint");

	UAGDeviceInfo_SupportsWifiPassPoint_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsWifiDirect
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsWifiDirect()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsWifiDirect");

	UAGDeviceInfo_SupportsWifiDirect_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsWifiAware
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsWifiAware()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsWifiAware");

	UAGDeviceInfo_SupportsWifiAware_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsWifi
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsWifi()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsWifi");

	UAGDeviceInfo_SupportsWifi_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsWebView
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsWebView()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsWebView");

	UAGDeviceInfo_SupportsWebView_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsVulkanHardwareVersion
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsVulkanHardwareVersion()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsVulkanHardwareVersion");

	UAGDeviceInfo_SupportsVulkanHardwareVersion_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsVulkanHardwareLevel
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsVulkanHardwareLevel()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsVulkanHardwareLevel");

	UAGDeviceInfo_SupportsVulkanHardwareLevel_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsVulkanHardwareCompute
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsVulkanHardwareCompute()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsVulkanHardwareCompute");

	UAGDeviceInfo_SupportsVulkanHardwareCompute_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsVerifiedBoot
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsVerifiedBoot()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsVerifiedBoot");

	UAGDeviceInfo_SupportsVerifiedBoot_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsUsbHost
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsUsbHost()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsUsbHost");

	UAGDeviceInfo_SupportsUsbHost_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsUsbAccessory
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsUsbAccessory()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsUsbAccessory");

	UAGDeviceInfo_SupportsUsbAccessory_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsTouchScreenMultiTouchJazzHand
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsTouchScreenMultiTouchJazzHand()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsTouchScreenMultiTouchJazzHand");

	UAGDeviceInfo_SupportsTouchScreenMultiTouchJazzHand_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsTouchScreenMultiTouchDistinct
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsTouchScreenMultiTouchDistinct()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsTouchScreenMultiTouchDistinct");

	UAGDeviceInfo_SupportsTouchScreenMultiTouchDistinct_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsTouchScreenMultiTouch
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsTouchScreenMultiTouch()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsTouchScreenMultiTouch");

	UAGDeviceInfo_SupportsTouchScreenMultiTouch_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsSipVoip
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsSipVoip()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsSipVoip");

	UAGDeviceInfo_SupportsSipVoip_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsSecureUserRemoval
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsSecureUserRemoval()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsSecureUserRemoval");

	UAGDeviceInfo_SupportsSecureUserRemoval_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsScreenPortrtait
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsScreenPortrtait()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsScreenPortrtait");

	UAGDeviceInfo_SupportsScreenPortrtait_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsScreenLandscape
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsScreenLandscape()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsScreenLandscape");

	UAGDeviceInfo_SupportsScreenLandscape_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsPrinting
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsPrinting()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsPrinting");

	UAGDeviceInfo_SupportsPrinting_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsPictureInPicture
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsPictureInPicture()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsPictureInPicture");

	UAGDeviceInfo_SupportsPictureInPicture_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsOpenGlEsExtensionPack
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsOpenGlEsExtensionPack()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsOpenGlEsExtensionPack");

	UAGDeviceInfo_SupportsOpenGlEsExtensionPack_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsNfcHostCardEmulationNfcf
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsNfcHostCardEmulationNfcf()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsNfcHostCardEmulationNfcf");

	UAGDeviceInfo_SupportsNfcHostCardEmulationNfcf_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsNfcHostCardEmulation
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsNfcHostCardEmulation()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsNfcHostCardEmulation");

	UAGDeviceInfo_SupportsNfcHostCardEmulation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsNfc
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsNfc()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsNfc");

	UAGDeviceInfo_SupportsNfc_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsMidi
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsMidi()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsMidi");

	UAGDeviceInfo_SupportsMidi_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsManagedUsers
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsManagedUsers()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsManagedUsers");

	UAGDeviceInfo_SupportsManagedUsers_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsLocationNetwork
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsLocationNetwork()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsLocationNetwork");

	UAGDeviceInfo_SupportsLocationNetwork_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsLocationGps
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsLocationGps()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsLocationGps");

	UAGDeviceInfo_SupportsLocationGps_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsLocation
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsLocation()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsLocation");

	UAGDeviceInfo_SupportsLocation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsLiveWallpaper
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsLiveWallpaper()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsLiveWallpaper");

	UAGDeviceInfo_SupportsLiveWallpaper_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsLiveTv
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsLiveTv()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsLiveTv");

	UAGDeviceInfo_SupportsLiveTv_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsLeanbackOnly
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsLeanbackOnly()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsLeanbackOnly");

	UAGDeviceInfo_SupportsLeanbackOnly_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsLeanback
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsLeanback()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsLeanback");

	UAGDeviceInfo_SupportsLeanback_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsInputMethods
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsInputMethods()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsInputMethods");

	UAGDeviceInfo_SupportsInputMethods_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsHomeScreen
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsHomeScreen()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsHomeScreen");

	UAGDeviceInfo_SupportsHomeScreen_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsHifiSensors
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsHifiSensors()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsHifiSensors");

	UAGDeviceInfo_SupportsHifiSensors_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsFreeFormWindowManagement
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsFreeFormWindowManagement()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsFreeFormWindowManagement");

	UAGDeviceInfo_SupportsFreeFormWindowManagement_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsFingerprint
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsFingerprint()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsFingerprint");

	UAGDeviceInfo_SupportsFingerprint_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsFakeTouchMultiTouchJazzHand
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsFakeTouchMultiTouchJazzHand()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsFakeTouchMultiTouchJazzHand");

	UAGDeviceInfo_SupportsFakeTouchMultiTouchJazzHand_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsFakeTouchMultiTouchDistinct
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsFakeTouchMultiTouchDistinct()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsFakeTouchMultiTouchDistinct");

	UAGDeviceInfo_SupportsFakeTouchMultiTouchDistinct_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsFakeTouch
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsFakeTouch()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsFakeTouch");

	UAGDeviceInfo_SupportsFakeTouch_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsEthernet
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsEthernet()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsEthernet");

	UAGDeviceInfo_SupportsEthernet_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsDeviceAdmin
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsDeviceAdmin()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsDeviceAdmin");

	UAGDeviceInfo_SupportsDeviceAdmin_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsConsumerIr
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsConsumerIr()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsConsumerIr");

	UAGDeviceInfo_SupportsConsumerIr_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsConnectionService
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsConnectionService()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsConnectionService");

	UAGDeviceInfo_SupportsConnectionService_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsCompanionDeviceSetup
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsCompanionDeviceSetup()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsCompanionDeviceSetup");

	UAGDeviceInfo_SupportsCompanionDeviceSetup_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsCantSaveState
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsCantSaveState()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsCantSaveState");

	UAGDeviceInfo_SupportsCantSaveState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsBluetoothLe
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsBluetoothLe()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsBluetoothLe");

	UAGDeviceInfo_SupportsBluetoothLe_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsBluetooth
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsBluetooth()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsBluetooth");

	UAGDeviceInfo_SupportsBluetooth_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsBackup
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsBackup()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsBackup");

	UAGDeviceInfo_SupportsBackup_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsAutomotive
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsAutomotive()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsAutomotive");

	UAGDeviceInfo_SupportsAutomotive_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsAutofill
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsAutofill()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsAutofill");

	UAGDeviceInfo_SupportsAutofill_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsAudioPro
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsAudioPro()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsAudioPro");

	UAGDeviceInfo_SupportsAudioPro_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsAudioOutput
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsAudioOutput()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsAudioOutput");

	UAGDeviceInfo_SupportsAudioOutput_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsAudioLowLatency
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsAudioLowLatency()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsAudioLowLatency");

	UAGDeviceInfo_SupportsAudioLowLatency_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsAppWidgets
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsAppWidgets()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsAppWidgets");

	UAGDeviceInfo_SupportsAppWidgets_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.SupportsActivitiesOnSecondaryDisplays
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_SupportsActivitiesOnSecondaryDisplays()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.SupportsActivitiesOnSecondaryDisplays");

	UAGDeviceInfo_SupportsActivitiesOnSecondaryDisplays_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.IsWatch
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_IsWatch()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.IsWatch");

	UAGDeviceInfo_IsWatch_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.IsTelevision
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_IsTelevision()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.IsTelevision");

	UAGDeviceInfo_IsTelevision_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.IsPc
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_IsPc()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.IsPc");

	UAGDeviceInfo_IsPc_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F230
//		Name   -> Function AndroidGoodies.AGDeviceInfo.IsPackageInstalled
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     PackageName                                                (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_IsPackageInstalled(const struct FString& PackageName)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.IsPackageInstalled");

	UAGDeviceInfo_IsPackageInstalled_Params params;
	params.PackageName = PackageName;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.IsEmbedded
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_IsEmbedded()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.IsEmbedded");

	UAGDeviceInfo_IsEmbedded_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasVrModeHighPerformance
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasVrModeHighPerformance()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasVrModeHighPerformance");

	UAGDeviceInfo_HasVrModeHighPerformance_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasVrMode
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasVrMode()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasVrMode");

	UAGDeviceInfo_HasVrMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasVrHeadTracking
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasVrHeadTracking()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasVrHeadTracking");

	UAGDeviceInfo_HasVrHeadTracking_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasTouchScreen
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasTouchScreen()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasTouchScreen");

	UAGDeviceInfo_HasTouchScreen_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasTelephonyMbms
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasTelephonyMbms()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasTelephonyMbms");

	UAGDeviceInfo_HasTelephonyMbms_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasTelephonyGsm
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasTelephonyGsm()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasTelephonyGsm");

	UAGDeviceInfo_HasTelephonyGsm_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasTelephonyEuicc
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasTelephonyEuicc()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasTelephonyEuicc");

	UAGDeviceInfo_HasTelephonyEuicc_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasTelephonyCdma
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasTelephonyCdma()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasTelephonyCdma");

	UAGDeviceInfo_HasTelephonyCdma_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasTelephony
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasTelephony()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasTelephony");

	UAGDeviceInfo_HasTelephony_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F230
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSystemFeature
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     featureName                                                (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSystemFeature(const struct FString& featureName)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSystemFeature");

	UAGDeviceInfo_HasSystemFeature_Params params;
	params.featureName = featureName;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasStrongBoxKeyStore
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasStrongBoxKeyStore()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasStrongBoxKeyStore");

	UAGDeviceInfo_HasStrongBoxKeyStore_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSip
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSip()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSip");

	UAGDeviceInfo_HasSip_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorStepDetector
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorStepDetector()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorStepDetector");

	UAGDeviceInfo_HasSensorStepDetector_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorStepCounter
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorStepCounter()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorStepCounter");

	UAGDeviceInfo_HasSensorStepCounter_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorRelativeHumidity
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorRelativeHumidity()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorRelativeHumidity");

	UAGDeviceInfo_HasSensorRelativeHumidity_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorProximity
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorProximity()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorProximity");

	UAGDeviceInfo_HasSensorProximity_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorLight
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorLight()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorLight");

	UAGDeviceInfo_HasSensorLight_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorHeartRateEcg
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorHeartRateEcg()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorHeartRateEcg");

	UAGDeviceInfo_HasSensorHeartRateEcg_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorHeartRate
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorHeartRate()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorHeartRate");

	UAGDeviceInfo_HasSensorHeartRate_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorGyroscope
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorGyroscope()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorGyroscope");

	UAGDeviceInfo_HasSensorGyroscope_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorCompass
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorCompass()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorCompass");

	UAGDeviceInfo_HasSensorCompass_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorBarometer
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorBarometer()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorBarometer");

	UAGDeviceInfo_HasSensorBarometer_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorAmbientTemperature
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorAmbientTemperature()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorAmbientTemperature");

	UAGDeviceInfo_HasSensorAmbientTemperature_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasSensorAccelerometer
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasSensorAccelerometer()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasSensorAccelerometer");

	UAGDeviceInfo_HasSensorAccelerometer_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasRamNormal
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasRamNormal()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasRamNormal");

	UAGDeviceInfo_HasRamNormal_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasRamLow
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasRamLow()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasRamLow");

	UAGDeviceInfo_HasRamLow_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasMicrophone
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasMicrophone()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasMicrophone");

	UAGDeviceInfo_HasMicrophone_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasGamepad
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasGamepad()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasGamepad");

	UAGDeviceInfo_HasGamepad_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasCameraLevelFull
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasCameraLevelFull()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasCameraLevelFull");

	UAGDeviceInfo_HasCameraLevelFull_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasCameraFront
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasCameraFront()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasCameraFront");

	UAGDeviceInfo_HasCameraFront_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasCameraFlash
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasCameraFlash()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasCameraFlash");

	UAGDeviceInfo_HasCameraFlash_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasCameraExternal
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasCameraExternal()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasCameraExternal");

	UAGDeviceInfo_HasCameraExternal_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasCameraCapabilityRaw
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasCameraCapabilityRaw()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasCameraCapabilityRaw");

	UAGDeviceInfo_HasCameraCapabilityRaw_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasCameraCapabilityManualSensor
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasCameraCapabilityManualSensor()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasCameraCapabilityManualSensor");

	UAGDeviceInfo_HasCameraCapabilityManualSensor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasCameraCapabilityManualPostprocessing
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasCameraCapabilityManualPostprocessing()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasCameraCapabilityManualPostprocessing");

	UAGDeviceInfo_HasCameraCapabilityManualPostprocessing_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasCameraAutofocus
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasCameraAutofocus()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasCameraAutofocus");

	UAGDeviceInfo_HasCameraAutofocus_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasCameraAr
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasCameraAr()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasCameraAr");

	UAGDeviceInfo_HasCameraAr_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasCameraAny
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasCameraAny()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasCameraAny");

	UAGDeviceInfo_HasCameraAny_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGDeviceInfo.HasCamera
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGDeviceInfo::STATIC_HasCamera()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.HasCamera");

	UAGDeviceInfo_HasCamera_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetType
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetType()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetType");

	UAGDeviceInfo_GetType_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetTags
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetTags()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetTags");

	UAGDeviceInfo_GetTags_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetSerial
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetSerial()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetSerial");

	UAGDeviceInfo_GetSerial_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F1D0
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetSdkInt
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGDeviceInfo::STATIC_GetSdkInt()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetSdkInt");

	UAGDeviceInfo_GetSdkInt_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetRelease
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetRelease()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetRelease");

	UAGDeviceInfo_GetRelease_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetRadio
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetRadio()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetRadio");

	UAGDeviceInfo_GetRadio_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetProduct
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetProduct()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetProduct");

	UAGDeviceInfo_GetProduct_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetModel
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetModel()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetModel");

	UAGDeviceInfo_GetModel_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetManufacturer
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetManufacturer()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetManufacturer");

	UAGDeviceInfo_GetManufacturer_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetHardware
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetHardware()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetHardware");

	UAGDeviceInfo_GetHardware_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetDisplay
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetDisplay()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetDisplay");

	UAGDeviceInfo_GetDisplay_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetDevice
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetDevice()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetDevice");

	UAGDeviceInfo_GetDevice_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetCodeName
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetCodeName()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetCodeName");

	UAGDeviceInfo_GetCodeName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetBrand
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetBrand()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetBrand");

	UAGDeviceInfo_GetBrand_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetBootloader
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetBootloader()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetBootloader");

	UAGDeviceInfo_GetBootloader_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetBoard
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetBoard()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetBoard");

	UAGDeviceInfo_GetBoard_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetBaseOs
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetBaseOs()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetBaseOs");

	UAGDeviceInfo_GetBaseOs_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetApplicationPackageName
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetApplicationPackageName()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetApplicationPackageName");

	UAGDeviceInfo_GetApplicationPackageName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGDeviceInfo.GetAndroidId
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGDeviceInfo::STATIC_GetAndroidId()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDeviceInfo.GetAndroidId");

	UAGDeviceInfo_GetAndroidId_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005141B0
//		Name   -> Function AndroidGoodies.AGDialogBPL.ShowTwoButtonsDialog
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		struct FString                                     messageTitle                                               (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Message                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     PositiveButtonText                                         (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     NegativeButtonText                                         (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onPositiveButtonClickedCallback                            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onNegativeButtonClickedCallback                            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onDialogCancelledCallback                                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGDialogBPL::STATIC_ShowTwoButtonsDialog(const struct FString& messageTitle, const struct FString& Message, const struct FString& PositiveButtonText, const struct FString& NegativeButtonText, const struct FScriptDelegate& onPositiveButtonClickedCallback, const struct FScriptDelegate& onNegativeButtonClickedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDialogBPL.ShowTwoButtonsDialog");

	UAGDialogBPL_ShowTwoButtonsDialog_Params params;
	params.messageTitle = messageTitle;
	params.Message = Message;
	params.PositiveButtonText = PositiveButtonText;
	params.NegativeButtonText = NegativeButtonText;
	params.onPositiveButtonClickedCallback = onPositiveButtonClickedCallback;
	params.onNegativeButtonClickedCallback = onNegativeButtonClickedCallback;
	params.onDialogCancelledCallback = onDialogCancelledCallback;
	params.Theme = Theme;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00513CB0
//		Name   -> Function AndroidGoodies.AGDialogBPL.ShowThreeButtonsDialog
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		struct FString                                     messageTitle                                               (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Message                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     PositiveButtonText                                         (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     NegativeButtonText                                         (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     NeutralButtonText                                          (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onPositiveButtonClickedCallback                            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onNegativeButtonClickedCallback                            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onNeutralButtonClickedCallback                             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onDialogCancelledCallback                                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGDialogBPL::STATIC_ShowThreeButtonsDialog(const struct FString& messageTitle, const struct FString& Message, const struct FString& PositiveButtonText, const struct FString& NegativeButtonText, const struct FString& NeutralButtonText, const struct FScriptDelegate& onPositiveButtonClickedCallback, const struct FScriptDelegate& onNegativeButtonClickedCallback, const struct FScriptDelegate& onNeutralButtonClickedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDialogBPL.ShowThreeButtonsDialog");

	UAGDialogBPL_ShowThreeButtonsDialog_Params params;
	params.messageTitle = messageTitle;
	params.Message = Message;
	params.PositiveButtonText = PositiveButtonText;
	params.NegativeButtonText = NegativeButtonText;
	params.NeutralButtonText = NeutralButtonText;
	params.onPositiveButtonClickedCallback = onPositiveButtonClickedCallback;
	params.onNegativeButtonClickedCallback = onNegativeButtonClickedCallback;
	params.onNeutralButtonClickedCallback = onNeutralButtonClickedCallback;
	params.onDialogCancelledCallback = onDialogCancelledCallback;
	params.Theme = Theme;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00513860
//		Name   -> Function AndroidGoodies.AGDialogBPL.ShowSingleItemChoiceDialog
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		struct FString                                     listTitle                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TArray<struct FString>                             listItems                                                  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		struct FString                                     PositiveButtonText                                         (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                selectedItemIndex                                          (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onSingleChoiceItemClickedCallback                          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onPositiveButtonClickedCallback                            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onDialogCancelledCallback                                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGDialogBPL::STATIC_ShowSingleItemChoiceDialog(const struct FString& listTitle, TArray<struct FString> listItems, const struct FString& PositiveButtonText, int selectedItemIndex, const struct FScriptDelegate& onSingleChoiceItemClickedCallback, const struct FScriptDelegate& onPositiveButtonClickedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDialogBPL.ShowSingleItemChoiceDialog");

	UAGDialogBPL_ShowSingleItemChoiceDialog_Params params;
	params.listTitle = listTitle;
	params.listItems = listItems;
	params.PositiveButtonText = PositiveButtonText;
	params.selectedItemIndex = selectedItemIndex;
	params.onSingleChoiceItemClickedCallback = onSingleChoiceItemClickedCallback;
	params.onPositiveButtonClickedCallback = onPositiveButtonClickedCallback;
	params.onDialogCancelledCallback = onDialogCancelledCallback;
	params.Theme = Theme;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00513570
//		Name   -> Function AndroidGoodies.AGDialogBPL.ShowSingleButtonDialog
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		struct FString                                     messageTitle                                               (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Message                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     PositiveButtonText                                         (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onPositiveButtonClickedCallback                            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onDialogCancelledCallback                                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGDialogBPL::STATIC_ShowSingleButtonDialog(const struct FString& messageTitle, const struct FString& Message, const struct FString& PositiveButtonText, const struct FScriptDelegate& onPositiveButtonClickedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDialogBPL.ShowSingleButtonDialog");

	UAGDialogBPL_ShowSingleButtonDialog_Params params;
	params.messageTitle = messageTitle;
	params.Message = Message;
	params.PositiveButtonText = PositiveButtonText;
	params.onPositiveButtonClickedCallback = onPositiveButtonClickedCallback;
	params.onDialogCancelledCallback = onDialogCancelledCallback;
	params.Theme = Theme;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x005130E0
//		Name   -> Function AndroidGoodies.AGDialogBPL.ShowMultipleItemChoiceDialog
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		struct FString                                     listTitle                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TArray<struct FString>                             listItems                                                  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		struct FString                                     PositiveButtonText                                         (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TArray<bool>                                       checkedListItems                                           (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onMultipleChoiceItemClickedCallback                        (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onPositiveButtonClickedCallback                            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onDialogCancelledCallback                                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGDialogBPL::STATIC_ShowMultipleItemChoiceDialog(const struct FString& listTitle, TArray<struct FString> listItems, const struct FString& PositiveButtonText, TArray<bool> checkedListItems, const struct FScriptDelegate& onMultipleChoiceItemClickedCallback, const struct FScriptDelegate& onPositiveButtonClickedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDialogBPL.ShowMultipleItemChoiceDialog");

	UAGDialogBPL_ShowMultipleItemChoiceDialog_Params params;
	params.listTitle = listTitle;
	params.listItems = listItems;
	params.PositiveButtonText = PositiveButtonText;
	params.checkedListItems = checkedListItems;
	params.onMultipleChoiceItemClickedCallback = onMultipleChoiceItemClickedCallback;
	params.onPositiveButtonClickedCallback = onPositiveButtonClickedCallback;
	params.onDialogCancelledCallback = onDialogCancelledCallback;
	params.Theme = Theme;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00512DE0
//		Name   -> Function AndroidGoodies.AGDialogBPL.ShowChooserDialog
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		struct FString                                     listTitle                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TArray<struct FString>                             listItems                                                  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onItemChoosedCallback                                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onDialogCancelledCallback                                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGDialogBPL::STATIC_ShowChooserDialog(const struct FString& listTitle, TArray<struct FString> listItems, const struct FScriptDelegate& onItemChoosedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGDialogBPL.ShowChooserDialog");

	UAGDialogBPL_ShowChooserDialog_Params params;
	params.listTitle = listTitle;
	params.listItems = listItems;
	params.onItemChoosedCallback = onItemChoosedCallback;
	params.onDialogCancelledCallback = onDialogCancelledCallback;
	params.Theme = Theme;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00514760
//		Name   -> Function AndroidGoodies.AGHardwareBPL.VibrateWithPattern
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		TArray<float>                                      pattern                                                    (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		int                                                repeatFrom                                                 (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGHardwareBPL::STATIC_VibrateWithPattern(TArray<float> pattern, int repeatFrom)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.VibrateWithPattern");

	UAGHardwareBPL_VibrateWithPattern_Params params;
	params.pattern = pattern;
	params.repeatFrom = repeatFrom;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00514690
//		Name   -> Function AndroidGoodies.AGHardwareBPL.VibrateWithEffectAndAttributes
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		class UAGVibrationEffect*                          vibrationEffect                                            (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FAGAudioAttributes                          audioAttributes                                            (Parm, NoDestructor, NativeAccessSpecifierPublic)
void UAGHardwareBPL::STATIC_VibrateWithEffectAndAttributes(class UAGVibrationEffect* vibrationEffect, const struct FAGAudioAttributes& audioAttributes)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.VibrateWithEffectAndAttributes");

	UAGHardwareBPL_VibrateWithEffectAndAttributes_Params params;
	params.vibrationEffect = vibrationEffect;
	params.audioAttributes = audioAttributes;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00514620
//		Name   -> Function AndroidGoodies.AGHardwareBPL.VibrateWithEffect
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		class UAGVibrationEffect*                          vibrationEffect                                            (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGHardwareBPL::STATIC_VibrateWithEffect(class UAGVibrationEffect* vibrationEffect)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.VibrateWithEffect");

	UAGHardwareBPL_VibrateWithEffect_Params params;
	params.vibrationEffect = vibrationEffect;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x005145B0
//		Name   -> Function AndroidGoodies.AGHardwareBPL.Vibrate
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		float                                              Duration                                                   (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGHardwareBPL::STATIC_Vibrate(float Duration)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.Vibrate");

	UAGHardwareBPL_Vibrate_Params params;
	params.Duration = Duration;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00423660
//		Name   -> Function AndroidGoodies.AGHardwareBPL.StopVibration
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
void UAGHardwareBPL::STATIC_StopVibration()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.StopVibration");

	UAGHardwareBPL_StopVibration_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGHardwareBPL.IsBatteryPresent
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGHardwareBPL::STATIC_IsBatteryPresent()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.IsBatteryPresent");

	UAGHardwareBPL_IsBatteryPresent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGHardwareBPL.IsBatteryLow
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGHardwareBPL::STATIC_IsBatteryLow()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.IsBatteryLow");

	UAGHardwareBPL_IsBatteryLow_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGHardwareBPL.HasVibrator
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGHardwareBPL::STATIC_HasVibrator()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.HasVibrator");

	UAGHardwareBPL_HasVibrator_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGHardwareBPL.HasAmplitudeControl
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGHardwareBPL::STATIC_HasAmplitudeControl()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.HasAmplitudeControl");

	UAGHardwareBPL_HasAmplitudeControl_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511E50
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetImmediateBatteryCurrent
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGHardwareBPL::STATIC_GetImmediateBatteryCurrent()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetImmediateBatteryCurrent");

	UAGHardwareBPL_GetImmediateBatteryCurrent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F1D0
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetBatteryVoltage
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGHardwareBPL::STATIC_GetBatteryVoltage()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetBatteryVoltage");

	UAGHardwareBPL_GetBatteryVoltage_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512110
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetBatteryTemperature
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGHardwareBPL::STATIC_GetBatteryTemperature()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetBatteryTemperature");

	UAGHardwareBPL_GetBatteryTemperature_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512090
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetBatteryTechnology
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGHardwareBPL::STATIC_GetBatteryTechnology()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetBatteryTechnology");

	UAGHardwareBPL_GetBatteryTechnology_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetBatteryStatus
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		AndroidGoodies_EBatteryStatus                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
AndroidGoodies_EBatteryStatus UAGHardwareBPL::STATIC_GetBatteryStatus()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetBatteryStatus");

	UAGHardwareBPL_GetBatteryStatus_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511E50
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetBatteryScale
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGHardwareBPL::STATIC_GetBatteryScale()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetBatteryScale");

	UAGHardwareBPL_GetBatteryScale_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512060
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetBatteryPluggedState
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_EBatteryPluggedState>   ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
TEnumAsByte<AndroidGoodies_EBatteryPluggedState> UAGHardwareBPL::STATIC_GetBatteryPluggedState()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetBatteryPluggedState");

	UAGHardwareBPL_GetBatteryPluggedState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511E50
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetBatteryLevel
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGHardwareBPL::STATIC_GetBatteryLevel()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetBatteryLevel");

	UAGHardwareBPL_GetBatteryLevel_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetBatteryHealth
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		AndroidGoodies_EBatteryHealth                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
AndroidGoodies_EBatteryHealth UAGHardwareBPL::STATIC_GetBatteryHealth()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetBatteryHealth");

	UAGHardwareBPL_GetBatteryHealth_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511E50
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetBatteryEnergyCounter
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGHardwareBPL::STATIC_GetBatteryEnergyCounter()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetBatteryEnergyCounter");

	UAGHardwareBPL_GetBatteryEnergyCounter_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511E50
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetBatteryChargeCounter
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGHardwareBPL::STATIC_GetBatteryChargeCounter()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetBatteryChargeCounter");

	UAGHardwareBPL_GetBatteryChargeCounter_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511E50
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetBatteryCapacity
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGHardwareBPL::STATIC_GetBatteryCapacity()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetBatteryCapacity");

	UAGHardwareBPL_GetBatteryCapacity_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511E50
//		Name   -> Function AndroidGoodies.AGHardwareBPL.GetAverageBatteryCurrent
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGHardwareBPL::STATIC_GetAverageBatteryCurrent()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.GetAverageBatteryCurrent");

	UAGHardwareBPL_GetAverageBatteryCurrent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511FE0
//		Name   -> Function AndroidGoodies.AGHardwareBPL.EnableFlashlight
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		bool                                               Enable                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGHardwareBPL::STATIC_EnableFlashlight(bool Enable)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.EnableFlashlight");

	UAGHardwareBPL_EnableFlashlight_Params params;
	params.Enable = Enable;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00511E50
//		Name   -> Function AndroidGoodies.AGHardwareBPL.ComputeRemainingChargeTime
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		int                                                ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
int UAGHardwareBPL::STATIC_ComputeRemainingChargeTime()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.ComputeRemainingChargeTime");

	UAGHardwareBPL_ComputeRemainingChargeTime_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGHardwareBPL.AreVibrationEffectsSupported
//		Flags  -> (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGHardwareBPL::STATIC_AreVibrationEffectsSupported()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGHardwareBPL.AreVibrationEffectsSupported");

	UAGHardwareBPL_AreVibrationEffectsSupported_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGMaps.UserHasMapsApp
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGMaps::STATIC_UserHasMapsApp()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGMaps.UserHasMapsApp");

	UAGMaps_UserHasMapsApp_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512410
//		Name   -> Function AndroidGoodies.AGMaps.OpenMapLocationWithLabel
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		float                                              latitude                                                   (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		float                                              longitude                                                  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Label                                                      (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGMaps::STATIC_OpenMapLocationWithLabel(float latitude, float longitude, const struct FString& Label)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGMaps.OpenMapLocationWithLabel");

	UAGMaps_OpenMapLocationWithLabel_Params params;
	params.latitude = latitude;
	params.longitude = longitude;
	params.Label = Label;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGMaps.OpenMapLocationWithAddress
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     address                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGMaps::STATIC_OpenMapLocationWithAddress(const struct FString& address)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGMaps.OpenMapLocationWithAddress");

	UAGMaps_OpenMapLocationWithAddress_Params params;
	params.address = address;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00512310
//		Name   -> Function AndroidGoodies.AGMaps.OpenMapLocation
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		float                                              latitude                                                   (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		float                                              longitude                                                  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                zoom                                                       (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGMaps::STATIC_OpenMapLocation(float latitude, float longitude, int zoom)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGMaps.OpenMapLocation");

	UAGMaps_OpenMapLocation_Params params;
	params.latitude = latitude;
	params.longitude = longitude;
	params.zoom = zoom;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBigPictureStyle.SetSummaryText
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBigPictureStyle*              ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBigPictureStyle* UAGNotificationBigPictureStyle::SetSummaryText(const struct FString& Text)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBigPictureStyle.SetSummaryText");

	UAGNotificationBigPictureStyle_SetSummaryText_Params params;
	params.Text = Text;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512790
//		Name   -> Function AndroidGoodies.AGNotificationBigPictureStyle.SetBigLargeIcon
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		class UTexture2D*                                  icon                                                       (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBigPictureStyle*              ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBigPictureStyle* UAGNotificationBigPictureStyle::SetBigLargeIcon(class UTexture2D* icon)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBigPictureStyle.SetBigLargeIcon");

	UAGNotificationBigPictureStyle_SetBigLargeIcon_Params params;
	params.icon = icon;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBigPictureStyle.SetBigContentTitle
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Title                                                      (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBigPictureStyle*              ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBigPictureStyle* UAGNotificationBigPictureStyle::SetBigContentTitle(const struct FString& Title)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBigPictureStyle.SetBigContentTitle");

	UAGNotificationBigPictureStyle_SetBigContentTitle_Params params;
	params.Title = Title;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511E80
//		Name   -> Function AndroidGoodies.AGNotificationBigPictureStyle.CreateBigPictureStyle
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UTexture2D*                                  bigPicture                                                 (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBigPictureStyle*              ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBigPictureStyle* UAGNotificationBigPictureStyle::STATIC_CreateBigPictureStyle(class UTexture2D* bigPicture)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBigPictureStyle.CreateBigPictureStyle");

	UAGNotificationBigPictureStyle_CreateBigPictureStyle_Params params;
	params.bigPicture = bigPicture;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBigTextStyle.SetSummaryText
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     summary                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBigTextStyle*                 ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBigTextStyle* UAGNotificationBigTextStyle::SetSummaryText(const struct FString& summary)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBigTextStyle.SetSummaryText");

	UAGNotificationBigTextStyle_SetSummaryText_Params params;
	params.summary = summary;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBigTextStyle.SetBigContentTitle
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Title                                                      (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBigTextStyle*                 ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBigTextStyle* UAGNotificationBigTextStyle::SetBigContentTitle(const struct FString& Title)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBigTextStyle.SetBigContentTitle");

	UAGNotificationBigTextStyle_SetBigContentTitle_Params params;
	params.Title = Title;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511F00
//		Name   -> Function AndroidGoodies.AGNotificationBigTextStyle.CreateBigTextStyle
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     bigText                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBigTextStyle*                 ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBigTextStyle* UAGNotificationBigTextStyle::STATIC_CreateBigTextStyle(const struct FString& bigText)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBigTextStyle.CreateBigTextStyle");

	UAGNotificationBigTextStyle_CreateBigTextStyle_Params params;
	params.bigText = bigText;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512D50
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetWhen
//		Flags  -> (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
//		struct FDateTime                                   DateTime                                                   (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetWhen(const struct FDateTime& DateTime)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetWhen");

	UAGNotificationBuilder_SetWhen_Params params;
	params.DateTime = DateTime;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512610
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetVisibility
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_ENotificationVisibility> Visibility                                                 (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetVisibility(TEnumAsByte<AndroidGoodies_ENotificationVisibility> Visibility)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetVisibility");

	UAGNotificationBuilder_SetVisibility_Params params;
	params.Visibility = Visibility;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512C60
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetVibrate
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TArray<float>                                      pattern                                                    (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetVibrate(TArray<float> pattern)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetVibrate");

	UAGNotificationBuilder_SetVibrate_Params params;
	params.pattern = pattern;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetUsesChronometer
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               usesChronometer                                            (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetUsesChronometer(bool usesChronometer)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetUsesChronometer");

	UAGNotificationBuilder_SetUsesChronometer_Params params;
	params.usesChronometer = usesChronometer;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetTitle
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Title                                                      (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetTitle(const struct FString& Title)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetTitle");

	UAGNotificationBuilder_SetTitle_Params params;
	params.Title = Title;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512AD0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetTimeoutAfter
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		int                                                milliSeconds                                               (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetTimeoutAfter(int milliSeconds)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetTimeoutAfter");

	UAGNotificationBuilder_SetTimeoutAfter_Params params;
	params.milliSeconds = milliSeconds;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetTicker
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetTicker(const struct FString& Text)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetTicker");

	UAGNotificationBuilder_SetTicker_Params params;
	params.Text = Text;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetText
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetText(const struct FString& Text)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetText");

	UAGNotificationBuilder_SetText_Params params;
	params.Text = Text;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetSubText
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetSubText(const struct FString& Text)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetSubText");

	UAGNotificationBuilder_SetSubText_Params params;
	params.Text = Text;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetSound
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Path                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetSound(const struct FString& Path)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetSound");

	UAGNotificationBuilder_SetSound_Params params;
	params.Path = Path;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetSortKey
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Key                                                        (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetSortKey(const struct FString& Key)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetSortKey");

	UAGNotificationBuilder_SetSortKey_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetSmallIcon
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Filename                                                   (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetSmallIcon(const struct FString& Filename)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetSmallIcon");

	UAGNotificationBuilder_SetSmallIcon_Params params;
	params.Filename = Filename;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetShowWhen
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               showWhen                                                   (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetShowWhen(bool showWhen)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetShowWhen");

	UAGNotificationBuilder_SetShowWhen_Params params;
	params.showWhen = showWhen;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetShortcutId
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ID                                                         (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetShortcutId(const struct FString& ID)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetShortcutId");

	UAGNotificationBuilder_SetShortcutId_Params params;
	params.ID = ID;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512790
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetPublicVersion
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		class UAGNotification*                             Notification                                               (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetPublicVersion(class UAGNotification* Notification)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetPublicVersion");

	UAGNotificationBuilder_SetPublicVersion_Params params;
	params.Notification = Notification;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512B60
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetProgress
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		int                                                current                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                Max                                                        (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               indeterminate                                              (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetProgress(int current, int Max, bool indeterminate)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetProgress");

	UAGNotificationBuilder_SetProgress_Params params;
	params.current = current;
	params.Max = Max;
	params.indeterminate = indeterminate;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512610
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetPriority
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_ENotificationPriority>  Priority                                                   (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetPriority(TEnumAsByte<AndroidGoodies_ENotificationPriority> Priority)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetPriority");

	UAGNotificationBuilder_SetPriority_Params params;
	params.Priority = Priority;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetOngoing
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               ongoing                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetOngoing(bool ongoing)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetOngoing");

	UAGNotificationBuilder_SetOngoing_Params params;
	params.ongoing = ongoing;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512AD0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetNumber
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		int                                                Number                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetNumber(int Number)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetNumber");

	UAGNotificationBuilder_SetNumber_Params params;
	params.Number = Number;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512790
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetMessagingStyle
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		class UAGNotificationMessageStyle*                 Style                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetMessagingStyle(class UAGNotificationMessageStyle* Style)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetMessagingStyle");

	UAGNotificationBuilder_SetMessagingStyle_Params params;
	params.Style = Style;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetLocalOnly
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               localOnly                                                  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetLocalOnly(bool localOnly)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetLocalOnly");

	UAGNotificationBuilder_SetLocalOnly_Params params;
	params.localOnly = localOnly;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005129D0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetLights
//		Flags  -> (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
//		struct FColor                                      Color                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                inMilliSeconds                                             (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                outMilliSeconds                                            (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetLights(const struct FColor& Color, int inMilliSeconds, int outMilliSeconds)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetLights");

	UAGNotificationBuilder_SetLights_Params params;
	params.Color = Color;
	params.inMilliSeconds = inMilliSeconds;
	params.outMilliSeconds = outMilliSeconds;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512790
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetLargeIcon
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		class UTexture2D*                                  icon                                                       (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetLargeIcon(class UTexture2D* icon)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetLargeIcon");

	UAGNotificationBuilder_SetLargeIcon_Params params;
	params.icon = icon;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512790
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetInboxStyle
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		class UAGNotificationInboxStyle*                   Style                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetInboxStyle(class UAGNotificationInboxStyle* Style)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetInboxStyle");

	UAGNotificationBuilder_SetInboxStyle_Params params;
	params.Style = Style;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetGroupSummary
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               summary                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetGroupSummary(bool summary)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetGroupSummary");

	UAGNotificationBuilder_SetGroupSummary_Params params;
	params.summary = summary;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512610
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetGroupAlertBehaviour
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_ENotificationGroupAlert> behaviour                                                  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetGroupAlertBehaviour(TEnumAsByte<AndroidGoodies_ENotificationGroupAlert> behaviour)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetGroupAlertBehaviour");

	UAGNotificationBuilder_SetGroupAlertBehaviour_Params params;
	params.behaviour = behaviour;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetGroup
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     groupKey                                                   (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetGroup(const struct FString& groupKey)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetGroup");

	UAGNotificationBuilder_SetGroup_Params params;
	params.groupKey = groupKey;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512930
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetDefaults
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FAGNotificationDefaults                     defaults                                                   (Parm, NoDestructor, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetDefaults(const struct FAGNotificationDefaults& defaults)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetDefaults");

	UAGNotificationBuilder_SetDefaults_Params params;
	params.defaults = defaults;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetContentInfo
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetContentInfo(const struct FString& Text)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetContentInfo");

	UAGNotificationBuilder_SetContentInfo_Params params;
	params.Text = Text;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetColorized
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               colorized                                                  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetColorized(bool colorized)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetColorized");

	UAGNotificationBuilder_SetColorized_Params params;
	params.colorized = colorized;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005128B0
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetColor
//		Flags  -> (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
//		struct FColor                                      Color                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetColor(const struct FColor& Color)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetColor");

	UAGNotificationBuilder_SetColor_Params params;
	params.Color = Color;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512820
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetCategory
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_ENotificationCategory>  Category                                                   (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetCategory(TEnumAsByte<AndroidGoodies_ENotificationCategory> Category)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetCategory");

	UAGNotificationBuilder_SetCategory_Params params;
	params.Category = Category;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512790
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetBigTextStyle
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		class UAGNotificationBigTextStyle*                 Style                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetBigTextStyle(class UAGNotificationBigTextStyle* Style)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetBigTextStyle");

	UAGNotificationBuilder_SetBigTextStyle_Params params;
	params.Style = Style;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512790
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetBigPictureStyle
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		class UAGNotificationBigPictureStyle*              Style                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetBigPictureStyle(class UAGNotificationBigPictureStyle* Style)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetBigPictureStyle");

	UAGNotificationBuilder_SetBigPictureStyle_Params params;
	params.Style = Style;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512610
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetBadgeIconType
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_ENotificationBadgeIconType> badgeIconType                                              (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetBadgeIconType(TEnumAsByte<AndroidGoodies_ENotificationBadgeIconType> badgeIconType)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetBadgeIconType");

	UAGNotificationBuilder_SetBadgeIconType_Params params;
	params.badgeIconType = badgeIconType;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetAutoCancel
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               autoCancel                                                 (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetAutoCancel(bool autoCancel)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetAutoCancel");

	UAGNotificationBuilder_SetAutoCancel_Params params;
	params.autoCancel = autoCancel;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.SetAlertOnce
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               alertOnce                                                  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::SetAlertOnce(bool alertOnce)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.SetAlertOnce");

	UAGNotificationBuilder_SetAlertOnce_Params params;
	params.alertOnce = alertOnce;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512140
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.NewNotificationBuilder
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ChannelId                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TMap<struct FString, struct FString>               additionalData                                             (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::STATIC_NewNotificationBuilder(const struct FString& ChannelId, TMap<struct FString, struct FString> additionalData)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.NewNotificationBuilder");

	UAGNotificationBuilder_NewNotificationBuilder_Params params;
	params.ChannelId = ChannelId;
	params.additionalData = additionalData;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511E20
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.Build
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		class UAGNotification*                             ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotification* UAGNotificationBuilder::Build()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.Build");

	UAGNotificationBuilder_Build_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00511C20
//		Name   -> Function AndroidGoodies.AGNotificationBuilder.AddOpenUrlAction
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     iconName                                                   (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Title                                                      (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     URL                                                        (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationBuilder*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationBuilder* UAGNotificationBuilder::AddOpenUrlAction(const struct FString& iconName, const struct FString& Title, const struct FString& URL)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationBuilder.AddOpenUrlAction");

	UAGNotificationBuilder_AddOpenUrlAction_Params params;
	params.iconName = iconName;
	params.Title = Title;
	params.URL = URL;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F450
//		Name   -> Function AndroidGoodies.AGNotificationChannel.ShouldVibrate
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGNotificationChannel::ShouldVibrate()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.ShouldVibrate");

	UAGNotificationChannel_ShouldVibrate_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F450
//		Name   -> Function AndroidGoodies.AGNotificationChannel.ShouldShowLights
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGNotificationChannel::ShouldShowLights()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.ShouldShowLights");

	UAGNotificationChannel_ShouldShowLights_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512C60
//		Name   -> Function AndroidGoodies.AGNotificationChannel.SetVibrationPattern
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TArray<float>                                      pattern                                                    (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::SetVibrationPattern(TArray<float> pattern)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.SetVibrationPattern");

	UAGNotificationChannel_SetVibrationPattern_Params params;
	params.pattern = pattern;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00517C10
//		Name   -> Function AndroidGoodies.AGNotificationChannel.SetSound
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     FilePath                                                   (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FAGAudioAttributes                          Attributes                                                 (Parm, NoDestructor, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::SetSound(const struct FString& FilePath, const struct FAGAudioAttributes& Attributes)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.SetSound");

	UAGNotificationChannel_SetSound_Params params;
	params.FilePath = FilePath;
	params.Attributes = Attributes;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationChannel.SetShowBadge
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               Show                                                       (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::SetShowBadge(bool Show)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.SetShowBadge");

	UAGNotificationChannel_SetShowBadge_Params params;
	params.Show = Show;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512610
//		Name   -> Function AndroidGoodies.AGNotificationChannel.SetLockScreenVisibility
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_ENotificationVisibility> Visibility                                                 (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::SetLockScreenVisibility(TEnumAsByte<AndroidGoodies_ENotificationVisibility> Visibility)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.SetLockScreenVisibility");

	UAGNotificationChannel_SetLockScreenVisibility_Params params;
	params.Visibility = Visibility;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005128B0
//		Name   -> Function AndroidGoodies.AGNotificationChannel.SetLightColor
//		Flags  -> (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
//		struct FColor                                      Color                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::SetLightColor(const struct FColor& Color)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.SetLightColor");

	UAGNotificationChannel_SetLightColor_Params params;
	params.Color = Color;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512610
//		Name   -> Function AndroidGoodies.AGNotificationChannel.SetImportance
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_EChannelImportance>     importance                                                 (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::SetImportance(TEnumAsByte<AndroidGoodies_EChannelImportance> importance)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.SetImportance");

	UAGNotificationChannel_SetImportance_Params params;
	params.importance = importance;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationChannel.SetGroup
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     GroupId                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::SetGroup(const struct FString& GroupId)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.SetGroup");

	UAGNotificationChannel_SetGroup_Params params;
	params.GroupId = GroupId;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationChannel.SetEnableVibration
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               Enable                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::SetEnableVibration(bool Enable)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.SetEnableVibration");

	UAGNotificationChannel_SetEnableVibration_Params params;
	params.Enable = Enable;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationChannel.SetEnableLights
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               Enable                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::SetEnableLights(bool Enable)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.SetEnableLights");

	UAGNotificationChannel_SetEnableLights_Params params;
	params.Enable = Enable;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationChannel.SetDescription
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Description                                                (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::SetDescription(const struct FString& Description)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.SetDescription");

	UAGNotificationChannel_SetDescription_Params params;
	params.Description = Description;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationChannel.SetBypassDnd
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               bypass                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::SetBypassDnd(bool bypass)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.SetBypassDnd");

	UAGNotificationChannel_SetBypassDnd_Params params;
	params.bypass = bypass;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00517020
//		Name   -> Function AndroidGoodies.AGNotificationChannel.NewNotificationChannel
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ID                                                         (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Name                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EChannelImportance>     importance                                                 (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationChannel::STATIC_NewNotificationChannel(const struct FString& ID, const struct FString& Name, TEnumAsByte<AndroidGoodies_EChannelImportance> importance)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.NewNotificationChannel");

	UAGNotificationChannel_NewNotificationChannel_Params params;
	params.ID = ID;
	params.Name = Name;
	params.importance = importance;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGNotificationChannel.GetVibrationPattern
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TArray<float>                                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
TArray<float> UAGNotificationChannel::GetVibrationPattern()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.GetVibrationPattern");

	UAGNotificationChannel_GetVibrationPattern_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGNotificationChannel.GetSoundPath
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGNotificationChannel::GetSoundPath()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.GetSoundPath");

	UAGNotificationChannel_GetSoundPath_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGNotificationChannel.GetName
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGNotificationChannel::GetName()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.GetName");

	UAGNotificationChannel_GetName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005169E0
//		Name   -> Function AndroidGoodies.AGNotificationChannel.GetLockScreenVisibility
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_ENotificationVisibility> ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
TEnumAsByte<AndroidGoodies_ENotificationVisibility> UAGNotificationChannel::GetLockScreenVisibility()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.GetLockScreenVisibility");

	UAGNotificationChannel_GetLockScreenVisibility_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005169A0
//		Name   -> Function AndroidGoodies.AGNotificationChannel.GetLightColor
//		Flags  -> (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
//		struct FColor                                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FColor UAGNotificationChannel::GetLightColor()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.GetLightColor");

	UAGNotificationChannel_GetLightColor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00516970
//		Name   -> Function AndroidGoodies.AGNotificationChannel.GetImportance
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_EChannelImportance>     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
TEnumAsByte<AndroidGoodies_EChannelImportance> UAGNotificationChannel::GetImportance()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.GetImportance");

	UAGNotificationChannel_GetImportance_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGNotificationChannel.GetId
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGNotificationChannel::GetId()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.GetId");

	UAGNotificationChannel_GetId_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGNotificationChannel.GetGroupId
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGNotificationChannel::GetGroupId()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.GetGroupId");

	UAGNotificationChannel_GetGroupId_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGNotificationChannel.GetDescription
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGNotificationChannel::GetDescription()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.GetDescription");

	UAGNotificationChannel_GetDescription_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005166A0
//		Name   -> Function AndroidGoodies.AGNotificationChannel.GetAudioAttributes
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FAGAudioAttributes                          ReturnValue                                                (Parm, OutParm, ReturnParm, NoDestructor, NativeAccessSpecifierPublic)
struct FAGAudioAttributes UAGNotificationChannel::GetAudioAttributes()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.GetAudioAttributes");

	UAGNotificationChannel_GetAudioAttributes_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F450
//		Name   -> Function AndroidGoodies.AGNotificationChannel.CanShowBadge
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGNotificationChannel::CanShowBadge()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.CanShowBadge");

	UAGNotificationChannel_CanShowBadge_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F450
//		Name   -> Function AndroidGoodies.AGNotificationChannel.CanBypassDnd
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGNotificationChannel::CanBypassDnd()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannel.CanBypassDnd");

	UAGNotificationChannel_CanBypassDnd_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationChannelGroup.SetDescription
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Description                                                (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannelGroup*                 ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannelGroup* UAGNotificationChannelGroup::SetDescription(const struct FString& Description)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannelGroup.SetDescription");

	UAGNotificationChannelGroup_SetDescription_Params params;
	params.Description = Description;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005171C0
//		Name   -> Function AndroidGoodies.AGNotificationChannelGroup.NewNotificationChannelGroup
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ID                                                         (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Name                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannelGroup*                 ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannelGroup* UAGNotificationChannelGroup::STATIC_NewNotificationChannelGroup(const struct FString& ID, const struct FString& Name)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannelGroup.NewNotificationChannelGroup");

	UAGNotificationChannelGroup_NewNotificationChannelGroup_Params params;
	params.ID = ID;
	params.Name = Name;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00516FF0
//		Name   -> Function AndroidGoodies.AGNotificationChannelGroup.IsBlocked
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGNotificationChannelGroup::IsBlocked()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannelGroup.IsBlocked");

	UAGNotificationChannelGroup_IsBlocked_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGNotificationChannelGroup.GetName
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGNotificationChannelGroup::GetName()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannelGroup.GetName");

	UAGNotificationChannelGroup_GetName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGNotificationChannelGroup.GetId
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGNotificationChannelGroup::GetId()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannelGroup.GetId");

	UAGNotificationChannelGroup_GetId_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGNotificationChannelGroup.GetDescription
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGNotificationChannelGroup::GetDescription()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannelGroup.GetDescription");

	UAGNotificationChannelGroup_GetDescription_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050F040
//		Name   -> Function AndroidGoodies.AGNotificationChannelGroup.GetChannels
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		TArray<class UAGNotificationChannel*>              ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
TArray<class UAGNotificationChannel*> UAGNotificationChannelGroup::GetChannels()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationChannelGroup.GetChannels");

	UAGNotificationChannelGroup_GetChannels_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationInboxStyle.SetSummaryText
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     summary                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationInboxStyle*                   ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationInboxStyle* UAGNotificationInboxStyle::SetSummaryText(const struct FString& summary)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationInboxStyle.SetSummaryText");

	UAGNotificationInboxStyle_SetSummaryText_Params params;
	params.summary = summary;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationInboxStyle.SetBigContentTitle
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Title                                                      (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationInboxStyle*                   ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationInboxStyle* UAGNotificationInboxStyle::SetBigContentTitle(const struct FString& Title)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationInboxStyle.SetBigContentTitle");

	UAGNotificationInboxStyle_SetBigContentTitle_Params params;
	params.Title = Title;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00516550
//		Name   -> Function AndroidGoodies.AGNotificationInboxStyle.CreateInboxStyle
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UAGNotificationInboxStyle*                   ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationInboxStyle* UAGNotificationInboxStyle::STATIC_CreateInboxStyle()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationInboxStyle.CreateInboxStyle");

	UAGNotificationInboxStyle_CreateInboxStyle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationInboxStyle.AddLine
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     line                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationInboxStyle*                   ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationInboxStyle* UAGNotificationInboxStyle::AddLine(const struct FString& line)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationInboxStyle.AddLine");

	UAGNotificationInboxStyle_AddLine_Params params;
	params.line = line;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00419700
//		Name   -> Function AndroidGoodies.AGNotificationManager.WasApplicationOpenViaNotification
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGNotificationManager::STATIC_WasApplicationOpenViaNotification()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.WasApplicationOpenViaNotification");

	UAGNotificationManager_WasApplicationOpenViaNotification_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00517BA0
//		Name   -> Function AndroidGoodies.AGNotificationManager.SetCurrentInterruptionFilter
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_EInterruptionFilter>    Filter                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGNotificationManager::STATIC_SetCurrentInterruptionFilter(TEnumAsByte<AndroidGoodies_EInterruptionFilter> Filter)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.SetCurrentInterruptionFilter");

	UAGNotificationManager_SetCurrentInterruptionFilter_Params params;
	params.Filter = Filter;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00517A70
//		Name   -> Function AndroidGoodies.AGNotificationManager.ScheduleRepeatingNotification
//		Flags  -> (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
//		class UAGNotification*                             Notification                                               (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                ID                                                         (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FTimespan                                   notifyAfter                                                (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FTimespan                                   repeatAfter                                                (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGNotificationManager::STATIC_ScheduleRepeatingNotification(class UAGNotification* Notification, int ID, const struct FTimespan& notifyAfter, const struct FTimespan& repeatAfter)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.ScheduleRepeatingNotification");

	UAGNotificationManager_ScheduleRepeatingNotification_Params params;
	params.Notification = Notification;
	params.ID = ID;
	params.notifyAfter = notifyAfter;
	params.repeatAfter = repeatAfter;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00517980
//		Name   -> Function AndroidGoodies.AGNotificationManager.ScheduleNotification
//		Flags  -> (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
//		class UAGNotification*                             Notification                                               (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                ID                                                         (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FTimespan                                   notifyAfter                                                (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGNotificationManager::STATIC_ScheduleNotification(class UAGNotification* Notification, int ID, const struct FTimespan& notifyAfter)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.ScheduleNotification");

	UAGNotificationManager_ScheduleNotification_Params params;
	params.Notification = Notification;
	params.ID = ID;
	params.notifyAfter = notifyAfter;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGNotificationManager.OpenNotificationChannelSettings
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ChannelId                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGNotificationManager::STATIC_OpenNotificationChannelSettings(const struct FString& ChannelId)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.OpenNotificationChannelSettings");

	UAGNotificationManager_OpenNotificationChannelSettings_Params params;
	params.ChannelId = ChannelId;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00517330
//		Name   -> Function AndroidGoodies.AGNotificationManager.Notify
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UAGNotification*                             Notification                                               (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                ID                                                         (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGNotificationManager::STATIC_Notify(class UAGNotification* Notification, int ID)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.Notify");

	UAGNotificationManager_Notify_Params params;
	params.Notification = Notification;
	params.ID = ID;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00516BD0
//		Name   -> Function AndroidGoodies.AGNotificationManager.GetNotificationDataForKey
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Key                                                        (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
struct FString UAGNotificationManager::STATIC_GetNotificationDataForKey(const struct FString& Key)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.GetNotificationDataForKey");

	UAGNotificationManager_GetNotificationDataForKey_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGNotificationManager.GetNotificationChannels
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		TArray<class UAGNotificationChannel*>              ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
TArray<class UAGNotificationChannel*> UAGNotificationManager::STATIC_GetNotificationChannels()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.GetNotificationChannels");

	UAGNotificationManager_GetNotificationChannels_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EE80
//		Name   -> Function AndroidGoodies.AGNotificationManager.GetNotificationChannelGroups
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		TArray<class UAGNotificationChannelGroup*>         ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
TArray<class UAGNotificationChannelGroup*> UAGNotificationManager::STATIC_GetNotificationChannelGroups()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.GetNotificationChannelGroups");

	UAGNotificationManager_GetNotificationChannelGroups_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00516AF0
//		Name   -> Function AndroidGoodies.AGNotificationManager.GetNotificationChannelGroup
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     GroupId                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannelGroup*                 ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannelGroup* UAGNotificationManager::STATIC_GetNotificationChannelGroup(const struct FString& GroupId)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.GetNotificationChannelGroup");

	UAGNotificationManager_GetNotificationChannelGroup_Params params;
	params.GroupId = GroupId;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00516A10
//		Name   -> Function AndroidGoodies.AGNotificationManager.GetNotificationChannel
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ChannelId                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationChannel*                      ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationChannel* UAGNotificationManager::STATIC_GetNotificationChannel(const struct FString& ChannelId)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.GetNotificationChannel");

	UAGNotificationManager_GetNotificationChannel_Params params;
	params.ChannelId = ChannelId;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00516930
//		Name   -> Function AndroidGoodies.AGNotificationManager.GetCurrentInterruptionFilter
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_EInterruptionFilter>    ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
TEnumAsByte<AndroidGoodies_EInterruptionFilter> UAGNotificationManager::STATIC_GetCurrentInterruptionFilter()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.GetCurrentInterruptionFilter");

	UAGNotificationManager_GetCurrentInterruptionFilter_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005168F0
//		Name   -> Function AndroidGoodies.AGNotificationManager.GetCurrentImportance
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		TEnumAsByte<AndroidGoodies_EChannelImportance>     ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
TEnumAsByte<AndroidGoodies_EChannelImportance> UAGNotificationManager::STATIC_GetCurrentImportance()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.GetCurrentImportance");

	UAGNotificationManager_GetCurrentImportance_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGNotificationManager.DeleteNotificationChannelGroup
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     GroupId                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGNotificationManager::STATIC_DeleteNotificationChannelGroup(const struct FString& GroupId)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.DeleteNotificationChannelGroup");

	UAGNotificationManager_DeleteNotificationChannelGroup_Params params;
	params.GroupId = GroupId;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGNotificationManager.DeleteNotificationChannel
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     ChannelId                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGNotificationManager::STATIC_DeleteNotificationChannel(const struct FString& ChannelId)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.DeleteNotificationChannel");

	UAGNotificationManager_DeleteNotificationChannel_Params params;
	params.ChannelId = ChannelId;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00514620
//		Name   -> Function AndroidGoodies.AGNotificationManager.CreateNotificationChannelGroup
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UAGNotificationChannelGroup*                 Group                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGNotificationManager::STATIC_CreateNotificationChannelGroup(class UAGNotificationChannelGroup* Group)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.CreateNotificationChannelGroup");

	UAGNotificationManager_CreateNotificationChannelGroup_Params params;
	params.Group = Group;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00514620
//		Name   -> Function AndroidGoodies.AGNotificationManager.CreateNotificationChannel
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UAGNotificationChannel*                      Channel                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGNotificationManager::STATIC_CreateNotificationChannel(class UAGNotificationChannel* Channel)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.CreateNotificationChannel");

	UAGNotificationManager_CreateNotificationChannel_Params params;
	params.Channel = Channel;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050FDA0
//		Name   -> Function AndroidGoodies.AGNotificationManager.CancelScheduledNotification
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		int                                                ID                                                         (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGNotificationManager::STATIC_CancelScheduledNotification(int ID)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.CancelScheduledNotification");

	UAGNotificationManager_CancelScheduledNotification_Params params;
	params.ID = ID;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050FDA0
//		Name   -> Function AndroidGoodies.AGNotificationManager.CancelNotification
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		int                                                ID                                                         (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGNotificationManager::STATIC_CancelNotification(int ID)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.CancelNotification");

	UAGNotificationManager_CancelNotification_Params params;
	params.ID = ID;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00423660
//		Name   -> Function AndroidGoodies.AGNotificationManager.CancelAllNotifications
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
void UAGNotificationManager::STATIC_CancelAllNotifications()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.CancelAllNotifications");

	UAGNotificationManager_CancelAllNotifications_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x005164B0
//		Name   -> Function AndroidGoodies.AGNotificationManager.AreNotificationChannelsSupported
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		bool                                               ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
bool UAGNotificationManager::STATIC_AreNotificationChannelsSupported()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationManager.AreNotificationChannelsSupported");

	UAGNotificationManager_AreNotificationChannelsSupported_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00512570
//		Name   -> Function AndroidGoodies.AGNotificationMessageStyle.SetGroupConversation
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		bool                                               isGroupConversation                                        (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationMessageStyle*                 ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationMessageStyle* UAGNotificationMessageStyle::SetGroupConversation(bool isGroupConversation)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationMessageStyle.SetGroupConversation");

	UAGNotificationMessageStyle_SetGroupConversation_Params params;
	params.isGroupConversation = isGroupConversation;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x005126A0
//		Name   -> Function AndroidGoodies.AGNotificationMessageStyle.SetConversationTitle
//		Flags  -> (Final, Native, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Title                                                      (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationMessageStyle*                 ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationMessageStyle* UAGNotificationMessageStyle::SetConversationTitle(const struct FString& Title)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationMessageStyle.SetConversationTitle");

	UAGNotificationMessageStyle_SetConversationTitle_Params params;
	params.Title = Title;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00516580
//		Name   -> Function AndroidGoodies.AGNotificationMessageStyle.CreateMessageStyle
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     userDisplayName                                            (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationMessageStyle*                 ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationMessageStyle* UAGNotificationMessageStyle::STATIC_CreateMessageStyle(const struct FString& userDisplayName)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationMessageStyle.CreateMessageStyle");

	UAGNotificationMessageStyle_CreateMessageStyle_Params params;
	params.userDisplayName = userDisplayName;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00516300
//		Name   -> Function AndroidGoodies.AGNotificationMessageStyle.AddMessage
//		Flags  -> (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FDateTime                                   Timestamp                                                  (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     sender                                                     (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGNotificationMessageStyle*                 ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGNotificationMessageStyle* UAGNotificationMessageStyle::AddMessage(const struct FString& Text, const struct FDateTime& Timestamp, const struct FString& sender)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGNotificationMessageStyle.AddMessage");

	UAGNotificationMessageStyle_AddMessage_Params params;
	params.Text = Text;
	params.Timestamp = Timestamp;
	params.sender = sender;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x00517D40
//		Name   -> Function AndroidGoodies.AGPickersBPL.TakeScreenShot
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		struct FScriptDelegate                             onScreenShotTakenCallback                                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onErrorCallback                                            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		bool                                               ShowUI                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGPickersBPL::STATIC_TakeScreenShot(const struct FScriptDelegate& onScreenShotTakenCallback, const struct FScriptDelegate& onErrorCallback, bool ShowUI)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGPickersBPL.TakeScreenShot");

	UAGPickersBPL_TakeScreenShot_Params params;
	params.onScreenShotTakenCallback = onScreenShotTakenCallback;
	params.onErrorCallback = onErrorCallback;
	params.ShowUI = ShowUI;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00517870
//		Name   -> Function AndroidGoodies.AGPickersBPL.SaveImageToGallery
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UTexture2D*                                  Image                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Filename                                                   (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGPickersBPL::STATIC_SaveImageToGallery(class UTexture2D* Image, const struct FString& Filename)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGPickersBPL.SaveImageToGallery");

	UAGPickersBPL_SaveImageToGallery_Params params;
	params.Image = Image;
	params.Filename = Filename;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00517710
//		Name   -> Function AndroidGoodies.AGPickersBPL.PickPhotoFromCamera
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		bool                                               shouldGenerateThumbnails                                   (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onPhotoPickedCallback                                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onPhotoPickErrorCallback                                   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
void UAGPickersBPL::STATIC_PickPhotoFromCamera(bool shouldGenerateThumbnails, const struct FScriptDelegate& onPhotoPickedCallback, const struct FScriptDelegate& onPhotoPickErrorCallback)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGPickersBPL.PickPhotoFromCamera");

	UAGPickersBPL_PickPhotoFromCamera_Params params;
	params.shouldGenerateThumbnails = shouldGenerateThumbnails;
	params.onPhotoPickedCallback = onPhotoPickedCallback;
	params.onPhotoPickErrorCallback = onPhotoPickErrorCallback;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00517540
//		Name   -> Function AndroidGoodies.AGPickersBPL.PickImageFromGallery
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		int                                                quality                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EImageSize>             MaxSize                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               shouldGenerateThumbnails                                   (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onImagePickedCallback                                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onImagePickErrorCallback                                   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
void UAGPickersBPL::STATIC_PickImageFromGallery(int quality, TEnumAsByte<AndroidGoodies_EImageSize> MaxSize, bool shouldGenerateThumbnails, const struct FScriptDelegate& onImagePickedCallback, const struct FScriptDelegate& onImagePickErrorCallback)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGPickersBPL.PickImageFromGallery");

	UAGPickersBPL_PickImageFromGallery_Params params;
	params.quality = quality;
	params.MaxSize = MaxSize;
	params.shouldGenerateThumbnails = shouldGenerateThumbnails;
	params.onImagePickedCallback = onImagePickedCallback;
	params.onImagePickErrorCallback = onImagePickErrorCallback;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x005173E0
//		Name   -> Function AndroidGoodies.AGPickersBPL.PickFilesFromLocalStorage
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		bool                                               allowMultiple                                              (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             OnFilesPickedCallback                                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             OnFilesPickErrorCallback                                   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
void UAGPickersBPL::STATIC_PickFilesFromLocalStorage(bool allowMultiple, const struct FScriptDelegate& OnFilesPickedCallback, const struct FScriptDelegate& OnFilesPickErrorCallback)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGPickersBPL.PickFilesFromLocalStorage");

	UAGPickersBPL_PickFilesFromLocalStorage_Params params;
	params.allowMultiple = allowMultiple;
	params.OnFilesPickedCallback = OnFilesPickedCallback;
	params.OnFilesPickErrorCallback = OnFilesPickErrorCallback;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00516E50
//		Name   -> Function AndroidGoodies.AGPickersBPL.GetTextureFromPath
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		struct FString                                     imagePath                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onTextureReadyCallback                                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             onTextureErrorCallback                                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
void UAGPickersBPL::STATIC_GetTextureFromPath(const struct FString& imagePath, const struct FScriptDelegate& onTextureReadyCallback, const struct FScriptDelegate& onTextureErrorCallback)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGPickersBPL.GetTextureFromPath");

	UAGPickersBPL_GetTextureFromPath_Params params;
	params.imagePath = imagePath;
	params.onTextureReadyCallback = onTextureReadyCallback;
	params.onTextureErrorCallback = onTextureErrorCallback;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00516CF0
//		Name   -> Function AndroidGoodies.AGPickersBPL.GetPhotoDataFromCamera
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		bool                                               shouldGenerateThumbnails                                   (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             OnPhotoTakenCallback                                       (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             OnPhotoTakeErrorCallback                                   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
void UAGPickersBPL::STATIC_GetPhotoDataFromCamera(bool shouldGenerateThumbnails, const struct FScriptDelegate& OnPhotoTakenCallback, const struct FScriptDelegate& OnPhotoTakeErrorCallback)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGPickersBPL.GetPhotoDataFromCamera");

	UAGPickersBPL_GetPhotoDataFromCamera_Params params;
	params.shouldGenerateThumbnails = shouldGenerateThumbnails;
	params.OnPhotoTakenCallback = OnPhotoTakenCallback;
	params.OnPhotoTakeErrorCallback = OnPhotoTakeErrorCallback;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x005166E0
//		Name   -> Function AndroidGoodies.AGPickersBPL.GetChosenImagesData
//		Flags  -> (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
//		int                                                quality                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EImageSize>             MaxSize                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               shouldGenerateThumbnails                                   (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               allowMultiple                                              (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             OnImagesPickedCallback                                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
//		struct FScriptDelegate                             OnImagesPickErrorCallback                                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
void UAGPickersBPL::STATIC_GetChosenImagesData(int quality, TEnumAsByte<AndroidGoodies_EImageSize> MaxSize, bool shouldGenerateThumbnails, bool allowMultiple, const struct FScriptDelegate& OnImagesPickedCallback, const struct FScriptDelegate& OnImagesPickErrorCallback)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGPickersBPL.GetChosenImagesData");

	UAGPickersBPL_GetChosenImagesData_Params params;
	params.quality = quality;
	params.MaxSize = MaxSize;
	params.shouldGenerateThumbnails = shouldGenerateThumbnails;
	params.allowMultiple = allowMultiple;
	params.OnImagesPickedCallback = OnImagesPickedCallback;
	params.OnImagesPickErrorCallback = OnImagesPickErrorCallback;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x005164E0
//		Name   -> Function AndroidGoodies.AGPickersBPL.ClearTexture
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UTexture2D*                                  Texture                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGPickersBPL::STATIC_ClearTexture(class UTexture2D* Texture)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGPickersBPL.ClearTexture");

	UAGPickersBPL_ClearTexture_Params params;
	params.Texture = Texture;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00516660
//		Name   -> Function AndroidGoodies.AGProgressDialogBPL.CreateProgressDialog
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
void UAGProgressDialogBPL::STATIC_CreateProgressDialog()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGProgressDialogBPL.CreateProgressDialog");

	UAGProgressDialogBPL_CreateProgressDialog_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00519D90
//		Name   -> Function AndroidGoodies.AGProgressDialogInterface.Show
//		Flags  -> (Native, Public, BlueprintCallable)
// Parameters:
//		struct FAGProgressDialogData                       progressDialogData                                         (Parm, NativeAccessSpecifierPublic)
void UAGProgressDialogInterface::Show(const struct FAGProgressDialogData& progressDialogData)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGProgressDialogInterface.Show");

	UAGProgressDialogInterface_Show_Params params;
	params.progressDialogData = progressDialogData;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x005197B0
//		Name   -> Function AndroidGoodies.AGProgressDialogInterface.SetProgress
//		Flags  -> (Native, Public, BlueprintCallable)
// Parameters:
//		int                                                Progress                                                   (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGProgressDialogInterface::SetProgress(int Progress)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGProgressDialogInterface.SetProgress");

	UAGProgressDialogInterface_SetProgress_Params params;
	params.Progress = Progress;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00519060
//		Name   -> Function AndroidGoodies.AGProgressDialogInterface.Dismiss
//		Flags  -> (Native, Public, BlueprintCallable)
void UAGProgressDialogInterface::Dismiss()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGProgressDialogInterface.Dismiss");

	UAGProgressDialogInterface_Dismiss_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00519080
//		Name   -> Function AndroidGoodies.ScreenShotHelper.ProcessScreenShot
//		Flags  -> (Final, Native, Public, HasOutParms)
// Parameters:
//		int                                                InSizeX                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                InSizeY                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TArray<struct FColor>                              InImageData                                                (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NativeAccessSpecifierPublic)
void UScreenShotHelper::ProcessScreenShot(int InSizeX, int InSizeY, TArray<struct FColor> InImageData)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.ScreenShotHelper.ProcessScreenShot");

	UScreenShotHelper_ProcessScreenShot_Params params;
	params.InSizeX = InSizeX;
	params.InSizeY = InSizeY;
	params.InImageData = InImageData;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00519FA0
//		Name   -> Function AndroidGoodies.AGShareBPL.TweetTextWithImage
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UTexture2D*                                  Image                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_TweetTextWithImage(const struct FString& Text, class UTexture2D* Image)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.TweetTextWithImage");

	UAGShareBPL_TweetTextWithImage_Params params;
	params.Text = Text;
	params.Image = Image;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGShareBPL.TweetText
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_TweetText(const struct FString& Text)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.TweetText");

	UAGShareBPL_TweetText_Params params;
	params.Text = Text;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00519BF0
//		Name   -> Function AndroidGoodies.AGShareBPL.ShareVideo
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     videoPath                                                  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               showChooser                                                (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     chooserTitle                                               (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_ShareVideo(const struct FString& videoPath, bool showChooser, const struct FString& chooserTitle)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.ShareVideo");

	UAGShareBPL_ShareVideo_Params params;
	params.videoPath = videoPath;
	params.showChooser = showChooser;
	params.chooserTitle = chooserTitle;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00519980
//		Name   -> Function AndroidGoodies.AGShareBPL.ShareTextWithImage
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Subject                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UTexture2D*                                  Image                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               showChooser                                                (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     chooserTitle                                               (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_ShareTextWithImage(const struct FString& Subject, const struct FString& Text, class UTexture2D* Image, bool showChooser, const struct FString& chooserTitle)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.ShareTextWithImage");

	UAGShareBPL_ShareTextWithImage_Params params;
	params.Subject = Subject;
	params.Text = Text;
	params.Image = Image;
	params.showChooser = showChooser;
	params.chooserTitle = chooserTitle;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00519580
//		Name   -> Function AndroidGoodies.AGShareBPL.ShareText
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Subject                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               showChooser                                                (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     chooserTitle                                               (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_ShareText(const struct FString& Subject, const struct FString& Text, bool showChooser, const struct FString& chooserTitle)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.ShareText");

	UAGShareBPL_ShareText_Params params;
	params.Subject = Subject;
	params.Text = Text;
	params.showChooser = showChooser;
	params.chooserTitle = chooserTitle;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00514620
//		Name   -> Function AndroidGoodies.AGShareBPL.ShareInstagram
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UTexture2D*                                  Image                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_ShareInstagram(class UTexture2D* Image)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.ShareInstagram");

	UAGShareBPL_ShareInstagram_Params params;
	params.Image = Image;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00519830
//		Name   -> Function AndroidGoodies.AGShareBPL.ShareImage
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UTexture2D*                                  Image                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               showChooser                                                (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     chooserTitle                                               (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_ShareImage(class UTexture2D* Image, bool showChooser, const struct FString& chooserTitle)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.ShareImage");

	UAGShareBPL_ShareImage_Params params;
	params.Image = Image;
	params.showChooser = showChooser;
	params.chooserTitle = chooserTitle;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGShareBPL.SendWhatsAppText
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendWhatsAppText(const struct FString& Text)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendWhatsAppText");

	UAGShareBPL_SendWhatsAppText_Params params;
	params.Text = Text;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00514620
//		Name   -> Function AndroidGoodies.AGShareBPL.SendWhatsAppImage
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UTexture2D*                                  Image                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendWhatsAppImage(class UTexture2D* Image)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendWhatsAppImage");

	UAGShareBPL_SendWhatsAppImage_Params params;
	params.Image = Image;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGShareBPL.SendViberText
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendViberText(const struct FString& Text)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendViberText");

	UAGShareBPL_SendViberText_Params params;
	params.Text = Text;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00514620
//		Name   -> Function AndroidGoodies.AGShareBPL.SendViberImage
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UTexture2D*                                  Image                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendViberImage(class UTexture2D* Image)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendViberImage");

	UAGShareBPL_SendViberImage_Params params;
	params.Image = Image;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGShareBPL.SendTelegramText
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendTelegramText(const struct FString& Text)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendTelegramText");

	UAGShareBPL_SendTelegramText_Params params;
	params.Text = Text;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00514620
//		Name   -> Function AndroidGoodies.AGShareBPL.SendTelegramImage
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UTexture2D*                                  Image                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendTelegramImage(class UTexture2D* Image)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendTelegramImage");

	UAGShareBPL_SendTelegramImage_Params params;
	params.Image = Image;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00519580
//		Name   -> Function AndroidGoodies.AGShareBPL.SendSmsWithDefaultApp
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     phoneNumber                                                (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Message                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		bool                                               showChooser                                                (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     chooserTitle                                               (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendSmsWithDefaultApp(const struct FString& phoneNumber, const struct FString& Message, bool showChooser, const struct FString& chooserTitle)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendSmsWithDefaultApp");

	UAGShareBPL_SendSmsWithDefaultApp_Params params;
	params.phoneNumber = phoneNumber;
	params.Message = Message;
	params.showChooser = showChooser;
	params.chooserTitle = chooserTitle;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x004241D0
//		Name   -> Function AndroidGoodies.AGShareBPL.SendSmsSilently
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     phoneNumber                                                (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     Message                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendSmsSilently(const struct FString& phoneNumber, const struct FString& Message)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendSmsSilently");

	UAGShareBPL_SendSmsSilently_Params params;
	params.phoneNumber = phoneNumber;
	params.Message = Message;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00519340
//		Name   -> Function AndroidGoodies.AGShareBPL.SendMultipleImagesEMail
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FAGShareEmailData                           emailData                                                  (Parm, NativeAccessSpecifierPublic)
//		TArray<class UTexture2D*>                          extraImages                                                (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		bool                                               showChooser                                                (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     chooserTitle                                               (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendMultipleImagesEMail(const struct FAGShareEmailData& emailData, TArray<class UTexture2D*> extraImages, bool showChooser, const struct FString& chooserTitle)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendMultipleImagesEMail");

	UAGShareBPL_SendMultipleImagesEMail_Params params;
	params.emailData = emailData;
	params.extraImages = extraImages;
	params.showChooser = showChooser;
	params.chooserTitle = chooserTitle;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0050EB10
//		Name   -> Function AndroidGoodies.AGShareBPL.SendFacebookText
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Text                                                       (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendFacebookText(const struct FString& Text)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendFacebookText");

	UAGShareBPL_SendFacebookText_Params params;
	params.Text = Text;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00514620
//		Name   -> Function AndroidGoodies.AGShareBPL.SendFacebookImage
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		class UTexture2D*                                  Image                                                      (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendFacebookImage(class UTexture2D* Image)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendFacebookImage");

	UAGShareBPL_SendFacebookImage_Params params;
	params.Image = Image;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x005191A0
//		Name   -> Function AndroidGoodies.AGShareBPL.SendEMail
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FAGShareEmailData                           emailData                                                  (Parm, NativeAccessSpecifierPublic)
//		bool                                               showChooser                                                (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		struct FString                                     chooserTitle                                               (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGShareBPL::STATIC_SendEMail(const struct FAGShareEmailData& emailData, bool showChooser, const struct FString& chooserTitle)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGShareBPL.SendEMail");

	UAGShareBPL_SendEMail_Params params;
	params.emailData = emailData;
	params.showChooser = showChooser;
	params.chooserTitle = chooserTitle;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x00519E90
//		Name   -> Function AndroidGoodies.AGToastBPL.ShowToast
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		struct FString                                     Message                                                    (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		TEnumAsByte<AndroidGoodies_EToastLength>           Length                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
void UAGToastBPL::STATIC_ShowToast(const struct FString& Message, TEnumAsByte<AndroidGoodies_EToastLength> Length)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGToastBPL.ShowToast");

	UAGToastBPL_ShowToast_Params params;
	params.Message = Message;
	params.Length = Length;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x0051A2A0
//		Name   -> Function AndroidGoodies.AGVibrationEffect.VibrationEffectWaveFormWithAmplitudes
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		TArray<float>                                      timings                                                    (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		TArray<int>                                        amplitudes                                                 (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		int                                                Repeat                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGVibrationEffect*                          ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGVibrationEffect* UAGVibrationEffect::STATIC_VibrationEffectWaveFormWithAmplitudes(TArray<float> timings, TArray<int> amplitudes, int Repeat)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGVibrationEffect.VibrationEffectWaveFormWithAmplitudes");

	UAGVibrationEffect_VibrationEffectWaveFormWithAmplitudes_Params params;
	params.timings = timings;
	params.amplitudes = amplitudes;
	params.Repeat = Repeat;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0051A180
//		Name   -> Function AndroidGoodies.AGVibrationEffect.VibrationEffectWaveForm
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		TArray<float>                                      timings                                                    (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
//		int                                                Repeat                                                     (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGVibrationEffect*                          ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGVibrationEffect* UAGVibrationEffect::STATIC_VibrationEffectWaveForm(TArray<float> timings, int Repeat)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGVibrationEffect.VibrationEffectWaveForm");

	UAGVibrationEffect_VibrationEffectWaveForm_Params params;
	params.timings = timings;
	params.Repeat = Repeat;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function:
//		Offset -> 0x0051A0B0
//		Name   -> Function AndroidGoodies.AGVibrationEffect.VibrationEffectOneShot
//		Flags  -> (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
//		float                                              Seconds                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		int                                                Amplitude                                                  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
//		class UAGVibrationEffect*                          ReturnValue                                                (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
class UAGVibrationEffect* UAGVibrationEffect::STATIC_VibrationEffectOneShot(float Seconds, int Amplitude)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AndroidGoodies.AGVibrationEffect.VibrationEffectOneShot");

	UAGVibrationEffect_VibrationEffectOneShot_Params params;
	params.Seconds = Seconds;
	params.Amplitude = Amplitude;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x00000400;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

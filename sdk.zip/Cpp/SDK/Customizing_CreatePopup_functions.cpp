﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x01C40890
//		Name   -> Function Customizing_CreatePopup.Customizing_CreatePopup_C.PlayOpenAnim
//		Flags  -> (Event, Public, BlueprintEvent)
void UCustomizing_CreatePopup_C::PlayOpenAnim()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function Customizing_CreatePopup.Customizing_CreatePopup_C.PlayOpenAnim");

	UCustomizing_CreatePopup_C_PlayOpenAnim_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function Customizing_CreatePopup.Customizing_CreatePopup_C.PlayCloseAnim
//		Flags  -> (Event, Public, BlueprintEvent)
void UCustomizing_CreatePopup_C::PlayCloseAnim()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function Customizing_CreatePopup.Customizing_CreatePopup_C.PlayCloseAnim");

	UCustomizing_CreatePopup_C_PlayCloseAnim_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function Customizing_CreatePopup.Customizing_CreatePopup_C.ExecuteUbergraph_Customizing_CreatePopup
//		Flags  -> (Final)
// Parameters:
//		int                                                EntryPoint                                                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UCustomizing_CreatePopup_C::ExecuteUbergraph_Customizing_CreatePopup(int EntryPoint)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function Customizing_CreatePopup.Customizing_CreatePopup_C.ExecuteUbergraph_Customizing_CreatePopup");

	UCustomizing_CreatePopup_C_ExecuteUbergraph_Customizing_CreatePopup_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

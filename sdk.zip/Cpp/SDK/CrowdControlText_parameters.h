﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function CrowdControlText.CrowdControlText_C.Construct
struct UCrowdControlText_C_Construct_Params
{
};

// Function CrowdControlText.CrowdControlText_C.WidgetAnimationEvt_Ani_Up_K2Node_WidgetAnimationEvent_1
struct UCrowdControlText_C_WidgetAnimationEvt_Ani_Up_K2Node_WidgetAnimationEvent_1_Params
{
};

// Function CrowdControlText.CrowdControlText_C.WidgetAnimationEvt_Ani_Down_K2Node_WidgetAnimationEvent_2
struct UCrowdControlText_C_WidgetAnimationEvt_Ani_Down_K2Node_WidgetAnimationEvent_2_Params
{
};

// Function CrowdControlText.CrowdControlText_C.ExecuteUbergraph_CrowdControlText
struct UCrowdControlText_C_ExecuteUbergraph_CrowdControlText_Params
{
	int                                                EntryPoint;                                                // 0x0000(0x0004)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

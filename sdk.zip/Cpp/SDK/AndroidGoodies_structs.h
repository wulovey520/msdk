﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// Enum AndroidGoodies.AudioAttributesContentType
enum class AndroidGoodies_EAudioAttributesContentType : uint8_t
{
	Unknown                        = 0,
	Speech                         = 1,
	Music                          = 2,
	Movie                          = 3,
	Sonification                   = 4,
	AudioAttributesContentType_MAX = 5,

};

// Enum AndroidGoodies.AudioAttributesUsage
enum class AndroidGoodies_EAudioAttributesUsage : uint8_t
{
	NotSpecified                   = 0,
	Media                          = 1,
	VoiceCommunication             = 2,
	VoiceCommunicationSignalling   = 3,
	Alarm                          = 4,
	Notification                   = 5,
	NotificationRingtone           = 6,
	NotificationCommunicationRequest = 7,
	NotificationCommunicationInstant = 8,
	NotificationCommunicationDelayed = 9,
	NotificationEvent              = 10,
	AssistanceAccessibility        = 11,
	AssistanceNavigationGuidance   = 12,
	AssistanceSonification         = 13,
	Game                           = 14,
	Assistant                      = 15,
	AudioAttributesUsage_MAX       = 16,

};

// Enum AndroidGoodies.BatteryHealth
enum class AndroidGoodies_EBatteryHealth : uint8_t
{
	BatteryHealth__UnknownHealth   = 0,
	BatteryHealth__Good            = 1,
	BatteryHealth__Overheat        = 2,
	BatteryHealth__Dead            = 3,
	BatteryHealth__OverVoltage     = 4,
	BatteryHealth__UnspecifiedFailure = 5,
	BatteryHealth__Cold            = 6,
	BatteryHealth__BatteryHealth_MAX = 7,

};

// Enum AndroidGoodies.BatteryPluggedState
enum class AndroidGoodies_EBatteryPluggedState : uint8_t
{
	OnBattery                      = 0,
	Ac                             = 1,
	Usb                            = 2,
	Wireless                       = 3,
	BatteryPluggedState_MAX        = 4,

};

// Enum AndroidGoodies.BatteryStatus
enum class AndroidGoodies_EBatteryStatus : uint8_t
{
	BatteryStatus__UnknownStatus   = 0,
	BatteryStatus__Charging        = 1,
	BatteryStatus__Discharging     = 2,
	BatteryStatus__NotCharging     = 3,
	BatteryStatus__Full            = 4,
	BatteryStatus__BatteryStatus_MAX = 5,

};

// Enum AndroidGoodies.ChannelImportance
enum class AndroidGoodies_EChannelImportance : uint8_t
{
	ImportanceNone                 = 0,
	ImportanceMin                  = 1,
	ImportanceLow                  = 2,
	ImportanceDefault              = 3,
	ImportanceHigh                 = 4,
	ImportanceMax                  = 5,
	ImportanceUnspecified          = 6,
	ChannelImportance_MAX          = 7,

};

// Enum AndroidGoodies.DialogTheme
enum class AndroidGoodies_EDialogTheme : uint8_t
{
	LightTheme                     = 0,
	DarkTheme                      = 1,
	DefaultTheme                   = 2,
	DialogTheme_MAX                = 3,

};

// Enum AndroidGoodies.ImageSize
enum class AndroidGoodies_EImageSize : uint8_t
{
	Original                       = 0,
	Max256                         = 1,
	Max512                         = 2,
	Max1024                        = 3,
	Max2048                        = 4,
	ImageSize_MAX                  = 5,

};

// Enum AndroidGoodies.InterruptionFilter
enum class AndroidGoodies_EInterruptionFilter : uint8_t
{
	FilterUnknown                  = 0,
	FIlterAll                      = 1,
	FilterPriority                 = 2,
	FilterNone                     = 3,
	FilterAlarms                   = 4,
	InterruptionFilter_MAX         = 5,

};

// Enum AndroidGoodies.NotificationBadgeIconType
enum class AndroidGoodies_ENotificationBadgeIconType : uint8_t
{
	NoBadge                        = 0,
	SmallBadge                     = 1,
	LargeBadge                     = 2,
	NotificationBadgeIconType_MAX  = 3,

};

// Enum AndroidGoodies.NotificationCategory
enum class AndroidGoodies_ENotificationCategory : uint8_t
{
	CategoryAlarm                  = 0,
	CategoryCall                   = 1,
	CategoryEmail                  = 2,
	CategoryError                  = 3,
	CategoryEvent                  = 4,
	CategoryMessage                = 5,
	CategoryNavigation             = 6,
	CategoryProgress               = 7,
	CategoryPromo                  = 8,
	CategoryRecommendation         = 9,
	CategoryReminder               = 10,
	CategoryService                = 11,
	CategorySocial                 = 12,
	CategoryStatus                 = 13,
	CategorySystem                 = 14,
	CategoryTransport              = 15,
	NotificationCategory_MAX       = 16,

};

// Enum AndroidGoodies.NotificationGroupAlert
enum class AndroidGoodies_ENotificationGroupAlert : uint8_t
{
	GroupAlertAll                  = 0,
	GroupAlertSummary              = 1,
	GroupAlertChildren             = 2,
	NotificationGroupAlert_MAX     = 3,

};

// Enum AndroidGoodies.NotificationPriority
enum class AndroidGoodies_ENotificationPriority : uint8_t
{
	PriorityMinimum                = 0,
	PriorityLow                    = 1,
	PriorityDefault                = 2,
	PriorityHigh                   = 3,
	PriorityMaximum                = 4,
	NotificationPriority_MAX       = 5,

};

// Enum AndroidGoodies.NotificationVisibility
enum class AndroidGoodies_ENotificationVisibility : uint8_t
{
	VisibilitySecret               = 0,
	VisibilityPrivate              = 1,
	VisibilityPublic               = 2,
	NotificationVisibility_MAX     = 3,

};

// Enum AndroidGoodies.ProgressDialogStyle
enum class AndroidGoodies_EProgressDialogStyle : uint8_t
{
	Spinner                        = 0,
	ProgressBar                    = 1,
	ProgressDialogStyle_MAX        = 2,

};

// Enum AndroidGoodies.ToastLength
enum class AndroidGoodies_EToastLength : uint8_t
{
	Short                          = 0,
	Long                           = 1,
	ToastLength_MAX                = 2,

};

//---------------------------------------------------------------------------
// Script Structs
//---------------------------------------------------------------------------

// ScriptStruct AndroidGoodies.AGAlarmDaysData
// 0x0007
struct FAGAlarmDaysData
{
	bool                                               Sunday;                                                    // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               Monday;                                                    // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               Tuesday;                                                   // 0x0002(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               Wednesday;                                                 // 0x0003(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               Thursday;                                                  // 0x0004(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               Friday;                                                    // 0x0005(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               Saturday;                                                  // 0x0006(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)

};

// ScriptStruct AndroidGoodies.AGContact
// 0x0020
struct FAGContact
{
	struct FString                                     DisplayName;                                               // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<struct FString>                             Numbers;                                                   // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor, NativeAccessSpecifierPublic)

};

// ScriptStruct AndroidGoodies.AGAudioAttributesFlags
// 0x0003
struct FAGAudioAttributesFlags
{
	bool                                               AudibilityEnforced;                                        // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               HwAvSync;                                                  // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               LowLatency;                                                // 0x0002(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)

};

// ScriptStruct AndroidGoodies.AGAudioAttributes
// 0x0005
struct FAGAudioAttributes
{
	struct FAGAudioAttributesFlags                     Flags;                                                     // 0x0000(0x0003) (Edit, BlueprintVisible, NoDestructor, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EAudioAttributesUsage>  Usage;                                                     // 0x0003(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EAudioAttributesContentType> ContentType;                                               // 0x0004(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)

};

// ScriptStruct AndroidGoodies.AGNotificationDefaults
// 0x0003
struct FAGNotificationDefaults
{
	bool                                               Lights;                                                    // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               sound;                                                     // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               Vibrate;                                                   // 0x0002(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)

};

// ScriptStruct AndroidGoodies.AGProgressDialogData
// 0x0030
struct FAGProgressDialogData
{
	struct FString                                     Title;                                                     // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Message;                                                   // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme;                                                     // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	unsigned char                                      UnknownData_9UIE[0x3];                                     // 0x0021(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	int                                                MaxValue;                                                  // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                Progress;                                                  // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               IsIndeterminate;                                           // 0x002C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               IsCancellable;                                             // 0x002D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EProgressDialogStyle>   Style;                                                     // 0x002E(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	unsigned char                                      UnknownData_9WT1[0x1];                                     // 0x002F(0x0001) MISSED OFFSET (PADDING)

};

// ScriptStruct AndroidGoodies.AGShareEmailData
// 0x0058
struct FAGShareEmailData
{
	struct FString                                     Subject;                                                   // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     TextBody;                                                  // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UTexture2D*                                  Image;                                                     // 0x0020(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<struct FString>                             Recipients;                                                // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor, NativeAccessSpecifierPublic)
	TArray<struct FString>                             CCRecepients;                                              // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor, NativeAccessSpecifierPublic)
	TArray<struct FString>                             BCCRecepients;                                             // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor, NativeAccessSpecifierPublic)

};

// ScriptStruct AndroidGoodies.AGDialogData
// 0x00A0
struct FAGDialogData
{
	struct FString                                     Title;                                                     // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Message;                                                   // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme;                                                     // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	unsigned char                                      UnknownData_QUVR[0x7];                                     // 0x0021(0x0007) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	struct FString                                     PositiveButtonText;                                        // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     NegativeButtonText;                                        // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     NeutralButtonText;                                         // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<struct FString>                             Items;                                                     // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor, NativeAccessSpecifierPublic)
	TArray<struct FString>                             SingleChoiceItems;                                         // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor, NativeAccessSpecifierPublic)
	int                                                SingleChoiceCheckedItem;                                   // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	unsigned char                                      UnknownData_4NWY[0x4];                                     // 0x007C(0x0004) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	TArray<struct FString>                             MultiChoiceItems;                                          // 0x0080(0x0010) (Edit, BlueprintVisible, ZeroConstructor, NativeAccessSpecifierPublic)
	TArray<bool>                                       MultiChoiceCheckedItems;                                   // 0x0090(0x0010) (Edit, BlueprintVisible, ZeroConstructor, NativeAccessSpecifierPublic)

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

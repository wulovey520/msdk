﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BTDeco_CheckHP.BTDeco_CheckHP_C
// 0x002C (FullSize[0x00CC] - InheritedSize[0x00A0])
class UBTDeco_CheckHP_C : public UBTDecorator_BlueprintBase
{
public:
	struct FBlackboardKeySelector                      CharacterKey;                                              // 0x00A0(0x0028) (Edit, BlueprintVisible)
	int                                                CheckHP;                                                   // 0x00C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("BlueprintGeneratedClass BTDeco_CheckHP.BTDeco_CheckHP_C");
		return ptr;
	}



	bool PerformConditionCheck(class AActor* OwnerActor);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass Customizing_MainCategoryItem.Customizing_MainCategoryItem_C
// 0x0000 (FullSize[0x0308] - InheritedSize[0x0308])
class UCustomizing_MainCategoryItem_C : public UMM_Customizing_MainCategoryItem
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("WidgetBlueprintGeneratedClass Customizing_MainCategoryItem.Customizing_MainCategoryItem_C");
		return ptr;
	}



};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

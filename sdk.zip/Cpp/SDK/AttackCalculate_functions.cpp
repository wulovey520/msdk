﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x01C40890
//		Name   -> Function AttackCalculate.AttackCalculate_C.CalcSTD
//		Flags  -> (Static, Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
//		int                                                STDlevel                                                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
//		int                                                Ability                                                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
//		int                                                Max                                                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
//		int                                                Min                                                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
//		class UObject*                                     __WorldContext                                             (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
//		float                                              NewParam4                                                  (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UAttackCalculate_C::STATIC_CalcSTD(int STDlevel, int Ability, int Max, int Min, class UObject* __WorldContext, float* NewParam4)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AttackCalculate.AttackCalculate_C.CalcSTD");

	UAttackCalculate_C_CalcSTD_Params params;
	params.STDlevel = STDlevel;
	params.Ability = Ability;
	params.Max = Max;
	params.Min = Min;
	params.__WorldContext = __WorldContext;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (NewParam4 != nullptr)
		*NewParam4 = params.NewParam4;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function AttackCalculate.AttackCalculate_C.공격데미지계산
//		Flags  -> (Static, Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
//		struct FATTACK_DATA                                Data                                                       (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
//		class UObject*                                     __WorldContext                                             (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
//		float                                              Damage                                                     (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UAttackCalculate_C::STATIC_공격데미지계산(const struct FATTACK_DATA& Data, class UObject* __WorldContext, float* Damage)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AttackCalculate.AttackCalculate_C.공격데미지계산");

	UAttackCalculate_C_공격데미지계산_Params params;
	params.Data = Data;
	params.__WorldContext = __WorldContext;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (Damage != nullptr)
		*Damage = params.Damage;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

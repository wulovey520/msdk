﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// Class AndroidGoodies.AGAlarmClock
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGAlarmClock : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGAlarmClock");
		return ptr;
	}



	void STATIC_SnoozeAlarm(int snoozeDurationMinutes);
	void STATIC_ShowAllTimers();
	void STATIC_ShowAllAlarms();
	void STATIC_SetTimer(int lengthSeconds, const struct FString& Message, bool skipUi);
	void STATIC_SetAlarm(int Hour, int Minute, const struct FString& Message, const struct FAGAlarmDaysData& days, bool Vibrate, bool skipUi);
	bool STATIC_CanSetTimer();
	bool STATIC_CanSetAlarm();
};

// Class AndroidGoodies.AGApps
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGApps : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGApps");
		return ptr;
	}



	void STATIC_UninstallPackage(const struct FString& PackageName);
	void STATIC_OpenYoutubeVideo(const struct FString& videoId);
	void STATIC_OpenTwitterProfile(const struct FString& profileId);
	void STATIC_OpenInstagramProfile(const struct FString& profileId);
	void STATIC_OpenFacebookProfile(const struct FString& profileId);
	void STATIC_OpenAnotherApplication(const struct FString& PackageName);
	void STATIC_InstallApkFromFile(const struct FString& FilePath, const struct FScriptDelegate& OnError);
	bool STATIC_HasPhoneApp();
	void STATIC_DownloadAndInstallApk(const struct FString& DownloadUrl, const struct FString& DownloadTitle, const struct FString& DownloadDescription, const struct FScriptDelegate& OnError);
	void STATIC_DialPhoneNumber(const struct FString& Number);
	void STATIC_CallPhoneNumber(const struct FString& Number);
};

// Class AndroidGoodies.AGChosenFile
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGChosenFile : public UObject
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGChosenFile");
		return ptr;
	}



	bool IsSuccess();
	int64_t GetSize();
	struct FString GetOriginalPath();
	struct FString GetMimeType();
	struct FString GetHumanReadableSize(bool bytesRounded);
	struct FString GetFileExtensionFromMimeTypeWithoutDot();
	struct FString GetFileExtensionFromMimeType();
	struct FString GetDisplayName();
	struct FDateTime GetCreatedAt();
};

// Class AndroidGoodies.AGChosenImage
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGChosenImage : public UAGChosenFile
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGChosenImage");
		return ptr;
	}



	int GetWidth();
	struct FString GetThumbnailSmallPath();
	struct FString GetThumbnailPath();
	struct FString GetOrientationName();
	int GetOrientation();
	int GetHeight();
};

// Class AndroidGoodies.AGContactsBPL
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGContactsBPL : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGContactsBPL");
		return ptr;
	}



	struct FString STATIC_GetUserPhoneNumber();
	TArray<struct FAGContact> STATIC_GetContactsWithNumber(const struct FString& Number);
	TArray<struct FAGContact> STATIC_GetContactsWithName(const struct FString& Name);
	TArray<struct FAGContact> STATIC_GetAllContacts();
	bool STATIC_AddContact(const struct FAGContact& contact);
};

// Class AndroidGoodies.AGDateTimePickerBPL
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGDateTimePickerBPL : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGDateTimePickerBPL");
		return ptr;
	}



	void STATIC_ShowTimePicker(int Hour, int Minute, const struct FScriptDelegate& onTimeSetCallback, const struct FScriptDelegate& onCancelCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme, bool is24HourView);
	void STATIC_ShowDatePickerWithLimits(const struct FDateTime& initialDate, const struct FScriptDelegate& onDateSetCallback, const struct FScriptDelegate& onCancelCallback, const struct FDateTime& fromDate, const struct FDateTime& toDate, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme);
	void STATIC_ShowDatePicker(const struct FDateTime& initialDate, const struct FScriptDelegate& onDateSetCallback, const struct FScriptDelegate& onCancelCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme);
};

// Class AndroidGoodies.AGDeviceInfo
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGDeviceInfo : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGDeviceInfo");
		return ptr;
	}



	bool STATIC_SupportsWifiRtt();
	bool STATIC_SupportsWifiPassPoint();
	bool STATIC_SupportsWifiDirect();
	bool STATIC_SupportsWifiAware();
	bool STATIC_SupportsWifi();
	bool STATIC_SupportsWebView();
	bool STATIC_SupportsVulkanHardwareVersion();
	bool STATIC_SupportsVulkanHardwareLevel();
	bool STATIC_SupportsVulkanHardwareCompute();
	bool STATIC_SupportsVerifiedBoot();
	bool STATIC_SupportsUsbHost();
	bool STATIC_SupportsUsbAccessory();
	bool STATIC_SupportsTouchScreenMultiTouchJazzHand();
	bool STATIC_SupportsTouchScreenMultiTouchDistinct();
	bool STATIC_SupportsTouchScreenMultiTouch();
	bool STATIC_SupportsSipVoip();
	bool STATIC_SupportsSecureUserRemoval();
	bool STATIC_SupportsScreenPortrtait();
	bool STATIC_SupportsScreenLandscape();
	bool STATIC_SupportsPrinting();
	bool STATIC_SupportsPictureInPicture();
	bool STATIC_SupportsOpenGlEsExtensionPack();
	bool STATIC_SupportsNfcHostCardEmulationNfcf();
	bool STATIC_SupportsNfcHostCardEmulation();
	bool STATIC_SupportsNfc();
	bool STATIC_SupportsMidi();
	bool STATIC_SupportsManagedUsers();
	bool STATIC_SupportsLocationNetwork();
	bool STATIC_SupportsLocationGps();
	bool STATIC_SupportsLocation();
	bool STATIC_SupportsLiveWallpaper();
	bool STATIC_SupportsLiveTv();
	bool STATIC_SupportsLeanbackOnly();
	bool STATIC_SupportsLeanback();
	bool STATIC_SupportsInputMethods();
	bool STATIC_SupportsHomeScreen();
	bool STATIC_SupportsHifiSensors();
	bool STATIC_SupportsFreeFormWindowManagement();
	bool STATIC_SupportsFingerprint();
	bool STATIC_SupportsFakeTouchMultiTouchJazzHand();
	bool STATIC_SupportsFakeTouchMultiTouchDistinct();
	bool STATIC_SupportsFakeTouch();
	bool STATIC_SupportsEthernet();
	bool STATIC_SupportsDeviceAdmin();
	bool STATIC_SupportsConsumerIr();
	bool STATIC_SupportsConnectionService();
	bool STATIC_SupportsCompanionDeviceSetup();
	bool STATIC_SupportsCantSaveState();
	bool STATIC_SupportsBluetoothLe();
	bool STATIC_SupportsBluetooth();
	bool STATIC_SupportsBackup();
	bool STATIC_SupportsAutomotive();
	bool STATIC_SupportsAutofill();
	bool STATIC_SupportsAudioPro();
	bool STATIC_SupportsAudioOutput();
	bool STATIC_SupportsAudioLowLatency();
	bool STATIC_SupportsAppWidgets();
	bool STATIC_SupportsActivitiesOnSecondaryDisplays();
	bool STATIC_IsWatch();
	bool STATIC_IsTelevision();
	bool STATIC_IsPc();
	bool STATIC_IsPackageInstalled(const struct FString& PackageName);
	bool STATIC_IsEmbedded();
	bool STATIC_HasVrModeHighPerformance();
	bool STATIC_HasVrMode();
	bool STATIC_HasVrHeadTracking();
	bool STATIC_HasTouchScreen();
	bool STATIC_HasTelephonyMbms();
	bool STATIC_HasTelephonyGsm();
	bool STATIC_HasTelephonyEuicc();
	bool STATIC_HasTelephonyCdma();
	bool STATIC_HasTelephony();
	bool STATIC_HasSystemFeature(const struct FString& featureName);
	bool STATIC_HasStrongBoxKeyStore();
	bool STATIC_HasSip();
	bool STATIC_HasSensorStepDetector();
	bool STATIC_HasSensorStepCounter();
	bool STATIC_HasSensorRelativeHumidity();
	bool STATIC_HasSensorProximity();
	bool STATIC_HasSensorLight();
	bool STATIC_HasSensorHeartRateEcg();
	bool STATIC_HasSensorHeartRate();
	bool STATIC_HasSensorGyroscope();
	bool STATIC_HasSensorCompass();
	bool STATIC_HasSensorBarometer();
	bool STATIC_HasSensorAmbientTemperature();
	bool STATIC_HasSensorAccelerometer();
	bool STATIC_HasRamNormal();
	bool STATIC_HasRamLow();
	bool STATIC_HasMicrophone();
	bool STATIC_HasGamepad();
	bool STATIC_HasCameraLevelFull();
	bool STATIC_HasCameraFront();
	bool STATIC_HasCameraFlash();
	bool STATIC_HasCameraExternal();
	bool STATIC_HasCameraCapabilityRaw();
	bool STATIC_HasCameraCapabilityManualSensor();
	bool STATIC_HasCameraCapabilityManualPostprocessing();
	bool STATIC_HasCameraAutofocus();
	bool STATIC_HasCameraAr();
	bool STATIC_HasCameraAny();
	bool STATIC_HasCamera();
	struct FString STATIC_GetType();
	struct FString STATIC_GetTags();
	struct FString STATIC_GetSerial();
	int STATIC_GetSdkInt();
	struct FString STATIC_GetRelease();
	struct FString STATIC_GetRadio();
	struct FString STATIC_GetProduct();
	struct FString STATIC_GetModel();
	struct FString STATIC_GetManufacturer();
	struct FString STATIC_GetHardware();
	struct FString STATIC_GetDisplay();
	struct FString STATIC_GetDevice();
	struct FString STATIC_GetCodeName();
	struct FString STATIC_GetBrand();
	struct FString STATIC_GetBootloader();
	struct FString STATIC_GetBoard();
	struct FString STATIC_GetBaseOs();
	struct FString STATIC_GetApplicationPackageName();
	struct FString STATIC_GetAndroidId();
};

// Class AndroidGoodies.AGDialogBPL
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGDialogBPL : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGDialogBPL");
		return ptr;
	}



	void STATIC_ShowTwoButtonsDialog(const struct FString& messageTitle, const struct FString& Message, const struct FString& PositiveButtonText, const struct FString& NegativeButtonText, const struct FScriptDelegate& onPositiveButtonClickedCallback, const struct FScriptDelegate& onNegativeButtonClickedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme);
	void STATIC_ShowThreeButtonsDialog(const struct FString& messageTitle, const struct FString& Message, const struct FString& PositiveButtonText, const struct FString& NegativeButtonText, const struct FString& NeutralButtonText, const struct FScriptDelegate& onPositiveButtonClickedCallback, const struct FScriptDelegate& onNegativeButtonClickedCallback, const struct FScriptDelegate& onNeutralButtonClickedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme);
	void STATIC_ShowSingleItemChoiceDialog(const struct FString& listTitle, TArray<struct FString> listItems, const struct FString& PositiveButtonText, int selectedItemIndex, const struct FScriptDelegate& onSingleChoiceItemClickedCallback, const struct FScriptDelegate& onPositiveButtonClickedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme);
	void STATIC_ShowSingleButtonDialog(const struct FString& messageTitle, const struct FString& Message, const struct FString& PositiveButtonText, const struct FScriptDelegate& onPositiveButtonClickedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme);
	void STATIC_ShowMultipleItemChoiceDialog(const struct FString& listTitle, TArray<struct FString> listItems, const struct FString& PositiveButtonText, TArray<bool> checkedListItems, const struct FScriptDelegate& onMultipleChoiceItemClickedCallback, const struct FScriptDelegate& onPositiveButtonClickedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme);
	void STATIC_ShowChooserDialog(const struct FString& listTitle, TArray<struct FString> listItems, const struct FScriptDelegate& onItemChoosedCallback, const struct FScriptDelegate& onDialogCancelledCallback, TEnumAsByte<AndroidGoodies_EDialogTheme> Theme);
};

// Class AndroidGoodies.AGHardwareBPL
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGHardwareBPL : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGHardwareBPL");
		return ptr;
	}



	void STATIC_VibrateWithPattern(TArray<float> pattern, int repeatFrom);
	void STATIC_VibrateWithEffectAndAttributes(class UAGVibrationEffect* vibrationEffect, const struct FAGAudioAttributes& audioAttributes);
	void STATIC_VibrateWithEffect(class UAGVibrationEffect* vibrationEffect);
	void STATIC_Vibrate(float Duration);
	void STATIC_StopVibration();
	bool STATIC_IsBatteryPresent();
	bool STATIC_IsBatteryLow();
	bool STATIC_HasVibrator();
	bool STATIC_HasAmplitudeControl();
	int STATIC_GetImmediateBatteryCurrent();
	int STATIC_GetBatteryVoltage();
	int STATIC_GetBatteryTemperature();
	struct FString STATIC_GetBatteryTechnology();
	AndroidGoodies_EBatteryStatus STATIC_GetBatteryStatus();
	int STATIC_GetBatteryScale();
	TEnumAsByte<AndroidGoodies_EBatteryPluggedState> STATIC_GetBatteryPluggedState();
	int STATIC_GetBatteryLevel();
	AndroidGoodies_EBatteryHealth STATIC_GetBatteryHealth();
	int STATIC_GetBatteryEnergyCounter();
	int STATIC_GetBatteryChargeCounter();
	int STATIC_GetBatteryCapacity();
	int STATIC_GetAverageBatteryCurrent();
	void STATIC_EnableFlashlight(bool Enable);
	int STATIC_ComputeRemainingChargeTime();
	bool STATIC_AreVibrationEffectsSupported();
};

// Class AndroidGoodies.AGMaps
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGMaps : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGMaps");
		return ptr;
	}



	bool STATIC_UserHasMapsApp();
	void STATIC_OpenMapLocationWithLabel(float latitude, float longitude, const struct FString& Label);
	void STATIC_OpenMapLocationWithAddress(const struct FString& address);
	void STATIC_OpenMapLocation(float latitude, float longitude, int zoom);
};

// Class AndroidGoodies.AGNotification
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGNotification : public UObject
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGNotification");
		return ptr;
	}



};

// Class AndroidGoodies.AGNotificationBigPictureStyle
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGNotificationBigPictureStyle : public UObject
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGNotificationBigPictureStyle");
		return ptr;
	}



	class UAGNotificationBigPictureStyle* SetSummaryText(const struct FString& Text);
	class UAGNotificationBigPictureStyle* SetBigLargeIcon(class UTexture2D* icon);
	class UAGNotificationBigPictureStyle* SetBigContentTitle(const struct FString& Title);
	class UAGNotificationBigPictureStyle* STATIC_CreateBigPictureStyle(class UTexture2D* bigPicture);
};

// Class AndroidGoodies.AGNotificationBigTextStyle
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGNotificationBigTextStyle : public UObject
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGNotificationBigTextStyle");
		return ptr;
	}



	class UAGNotificationBigTextStyle* SetSummaryText(const struct FString& summary);
	class UAGNotificationBigTextStyle* SetBigContentTitle(const struct FString& Title);
	class UAGNotificationBigTextStyle* STATIC_CreateBigTextStyle(const struct FString& bigText);
};

// Class AndroidGoodies.AGNotificationBuilder
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGNotificationBuilder : public UObject
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGNotificationBuilder");
		return ptr;
	}



	class UAGNotificationBuilder* SetWhen(const struct FDateTime& DateTime);
	class UAGNotificationBuilder* SetVisibility(TEnumAsByte<AndroidGoodies_ENotificationVisibility> Visibility);
	class UAGNotificationBuilder* SetVibrate(TArray<float> pattern);
	class UAGNotificationBuilder* SetUsesChronometer(bool usesChronometer);
	class UAGNotificationBuilder* SetTitle(const struct FString& Title);
	class UAGNotificationBuilder* SetTimeoutAfter(int milliSeconds);
	class UAGNotificationBuilder* SetTicker(const struct FString& Text);
	class UAGNotificationBuilder* SetText(const struct FString& Text);
	class UAGNotificationBuilder* SetSubText(const struct FString& Text);
	class UAGNotificationBuilder* SetSound(const struct FString& Path);
	class UAGNotificationBuilder* SetSortKey(const struct FString& Key);
	class UAGNotificationBuilder* SetSmallIcon(const struct FString& Filename);
	class UAGNotificationBuilder* SetShowWhen(bool showWhen);
	class UAGNotificationBuilder* SetShortcutId(const struct FString& ID);
	class UAGNotificationBuilder* SetPublicVersion(class UAGNotification* Notification);
	class UAGNotificationBuilder* SetProgress(int current, int Max, bool indeterminate);
	class UAGNotificationBuilder* SetPriority(TEnumAsByte<AndroidGoodies_ENotificationPriority> Priority);
	class UAGNotificationBuilder* SetOngoing(bool ongoing);
	class UAGNotificationBuilder* SetNumber(int Number);
	class UAGNotificationBuilder* SetMessagingStyle(class UAGNotificationMessageStyle* Style);
	class UAGNotificationBuilder* SetLocalOnly(bool localOnly);
	class UAGNotificationBuilder* SetLights(const struct FColor& Color, int inMilliSeconds, int outMilliSeconds);
	class UAGNotificationBuilder* SetLargeIcon(class UTexture2D* icon);
	class UAGNotificationBuilder* SetInboxStyle(class UAGNotificationInboxStyle* Style);
	class UAGNotificationBuilder* SetGroupSummary(bool summary);
	class UAGNotificationBuilder* SetGroupAlertBehaviour(TEnumAsByte<AndroidGoodies_ENotificationGroupAlert> behaviour);
	class UAGNotificationBuilder* SetGroup(const struct FString& groupKey);
	class UAGNotificationBuilder* SetDefaults(const struct FAGNotificationDefaults& defaults);
	class UAGNotificationBuilder* SetContentInfo(const struct FString& Text);
	class UAGNotificationBuilder* SetColorized(bool colorized);
	class UAGNotificationBuilder* SetColor(const struct FColor& Color);
	class UAGNotificationBuilder* SetCategory(TEnumAsByte<AndroidGoodies_ENotificationCategory> Category);
	class UAGNotificationBuilder* SetBigTextStyle(class UAGNotificationBigTextStyle* Style);
	class UAGNotificationBuilder* SetBigPictureStyle(class UAGNotificationBigPictureStyle* Style);
	class UAGNotificationBuilder* SetBadgeIconType(TEnumAsByte<AndroidGoodies_ENotificationBadgeIconType> badgeIconType);
	class UAGNotificationBuilder* SetAutoCancel(bool autoCancel);
	class UAGNotificationBuilder* SetAlertOnce(bool alertOnce);
	class UAGNotificationBuilder* STATIC_NewNotificationBuilder(const struct FString& ChannelId, TMap<struct FString, struct FString> additionalData);
	class UAGNotification* Build();
	class UAGNotificationBuilder* AddOpenUrlAction(const struct FString& iconName, const struct FString& Title, const struct FString& URL);
};

// Class AndroidGoodies.AGNotificationChannel
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGNotificationChannel : public UObject
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGNotificationChannel");
		return ptr;
	}



	bool ShouldVibrate();
	bool ShouldShowLights();
	class UAGNotificationChannel* SetVibrationPattern(TArray<float> pattern);
	class UAGNotificationChannel* SetSound(const struct FString& FilePath, const struct FAGAudioAttributes& Attributes);
	class UAGNotificationChannel* SetShowBadge(bool Show);
	class UAGNotificationChannel* SetLockScreenVisibility(TEnumAsByte<AndroidGoodies_ENotificationVisibility> Visibility);
	class UAGNotificationChannel* SetLightColor(const struct FColor& Color);
	class UAGNotificationChannel* SetImportance(TEnumAsByte<AndroidGoodies_EChannelImportance> importance);
	class UAGNotificationChannel* SetGroup(const struct FString& GroupId);
	class UAGNotificationChannel* SetEnableVibration(bool Enable);
	class UAGNotificationChannel* SetEnableLights(bool Enable);
	class UAGNotificationChannel* SetDescription(const struct FString& Description);
	class UAGNotificationChannel* SetBypassDnd(bool bypass);
	class UAGNotificationChannel* STATIC_NewNotificationChannel(const struct FString& ID, const struct FString& Name, TEnumAsByte<AndroidGoodies_EChannelImportance> importance);
	TArray<float> GetVibrationPattern();
	struct FString GetSoundPath();
	struct FString GetName();
	TEnumAsByte<AndroidGoodies_ENotificationVisibility> GetLockScreenVisibility();
	struct FColor GetLightColor();
	TEnumAsByte<AndroidGoodies_EChannelImportance> GetImportance();
	struct FString GetId();
	struct FString GetGroupId();
	struct FString GetDescription();
	struct FAGAudioAttributes GetAudioAttributes();
	bool CanShowBadge();
	bool CanBypassDnd();
};

// Class AndroidGoodies.AGNotificationChannelGroup
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGNotificationChannelGroup : public UObject
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGNotificationChannelGroup");
		return ptr;
	}



	class UAGNotificationChannelGroup* SetDescription(const struct FString& Description);
	class UAGNotificationChannelGroup* STATIC_NewNotificationChannelGroup(const struct FString& ID, const struct FString& Name);
	bool IsBlocked();
	struct FString GetName();
	struct FString GetId();
	struct FString GetDescription();
	TArray<class UAGNotificationChannel*> GetChannels();
};

// Class AndroidGoodies.AGNotificationInboxStyle
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGNotificationInboxStyle : public UObject
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGNotificationInboxStyle");
		return ptr;
	}



	class UAGNotificationInboxStyle* SetSummaryText(const struct FString& summary);
	class UAGNotificationInboxStyle* SetBigContentTitle(const struct FString& Title);
	class UAGNotificationInboxStyle* STATIC_CreateInboxStyle();
	class UAGNotificationInboxStyle* AddLine(const struct FString& line);
};

// Class AndroidGoodies.AGNotificationManager
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGNotificationManager : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGNotificationManager");
		return ptr;
	}



	bool STATIC_WasApplicationOpenViaNotification();
	void STATIC_SetCurrentInterruptionFilter(TEnumAsByte<AndroidGoodies_EInterruptionFilter> Filter);
	void STATIC_ScheduleRepeatingNotification(class UAGNotification* Notification, int ID, const struct FTimespan& notifyAfter, const struct FTimespan& repeatAfter);
	void STATIC_ScheduleNotification(class UAGNotification* Notification, int ID, const struct FTimespan& notifyAfter);
	void STATIC_OpenNotificationChannelSettings(const struct FString& ChannelId);
	void STATIC_Notify(class UAGNotification* Notification, int ID);
	struct FString STATIC_GetNotificationDataForKey(const struct FString& Key);
	TArray<class UAGNotificationChannel*> STATIC_GetNotificationChannels();
	TArray<class UAGNotificationChannelGroup*> STATIC_GetNotificationChannelGroups();
	class UAGNotificationChannelGroup* STATIC_GetNotificationChannelGroup(const struct FString& GroupId);
	class UAGNotificationChannel* STATIC_GetNotificationChannel(const struct FString& ChannelId);
	TEnumAsByte<AndroidGoodies_EInterruptionFilter> STATIC_GetCurrentInterruptionFilter();
	TEnumAsByte<AndroidGoodies_EChannelImportance> STATIC_GetCurrentImportance();
	void STATIC_DeleteNotificationChannelGroup(const struct FString& GroupId);
	void STATIC_DeleteNotificationChannel(const struct FString& ChannelId);
	void STATIC_CreateNotificationChannelGroup(class UAGNotificationChannelGroup* Group);
	void STATIC_CreateNotificationChannel(class UAGNotificationChannel* Channel);
	void STATIC_CancelScheduledNotification(int ID);
	void STATIC_CancelNotification(int ID);
	void STATIC_CancelAllNotifications();
	bool STATIC_AreNotificationChannelsSupported();
};

// Class AndroidGoodies.AGNotificationMessageStyle
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGNotificationMessageStyle : public UObject
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGNotificationMessageStyle");
		return ptr;
	}



	class UAGNotificationMessageStyle* SetGroupConversation(bool isGroupConversation);
	class UAGNotificationMessageStyle* SetConversationTitle(const struct FString& Title);
	class UAGNotificationMessageStyle* STATIC_CreateMessageStyle(const struct FString& userDisplayName);
	class UAGNotificationMessageStyle* AddMessage(const struct FString& Text, const struct FDateTime& Timestamp, const struct FString& sender);
};

// Class AndroidGoodies.AGPickersBPL
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGPickersBPL : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGPickersBPL");
		return ptr;
	}



	void STATIC_TakeScreenShot(const struct FScriptDelegate& onScreenShotTakenCallback, const struct FScriptDelegate& onErrorCallback, bool ShowUI);
	void STATIC_SaveImageToGallery(class UTexture2D* Image, const struct FString& Filename);
	void STATIC_PickPhotoFromCamera(bool shouldGenerateThumbnails, const struct FScriptDelegate& onPhotoPickedCallback, const struct FScriptDelegate& onPhotoPickErrorCallback);
	void STATIC_PickImageFromGallery(int quality, TEnumAsByte<AndroidGoodies_EImageSize> MaxSize, bool shouldGenerateThumbnails, const struct FScriptDelegate& onImagePickedCallback, const struct FScriptDelegate& onImagePickErrorCallback);
	void STATIC_PickFilesFromLocalStorage(bool allowMultiple, const struct FScriptDelegate& OnFilesPickedCallback, const struct FScriptDelegate& OnFilesPickErrorCallback);
	void STATIC_GetTextureFromPath(const struct FString& imagePath, const struct FScriptDelegate& onTextureReadyCallback, const struct FScriptDelegate& onTextureErrorCallback);
	void STATIC_GetPhotoDataFromCamera(bool shouldGenerateThumbnails, const struct FScriptDelegate& OnPhotoTakenCallback, const struct FScriptDelegate& OnPhotoTakeErrorCallback);
	void STATIC_GetChosenImagesData(int quality, TEnumAsByte<AndroidGoodies_EImageSize> MaxSize, bool shouldGenerateThumbnails, bool allowMultiple, const struct FScriptDelegate& OnImagesPickedCallback, const struct FScriptDelegate& OnImagesPickErrorCallback);
	void STATIC_ClearTexture(class UTexture2D* Texture);
};

// Class AndroidGoodies.AGProgressDialogBPL
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGProgressDialogBPL : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGProgressDialogBPL");
		return ptr;
	}



	void STATIC_CreateProgressDialog();
};

// Class AndroidGoodies.AGProgressDialogInterface
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGProgressDialogInterface : public UInterface
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGProgressDialogInterface");
		return ptr;
	}



	void Show(const struct FAGProgressDialogData& progressDialogData);
	void SetProgress(int Progress);
	void Dismiss();
};

// Class AndroidGoodies.ScreenShotHelper
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UScreenShotHelper : public UObject
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.ScreenShotHelper");
		return ptr;
	}



	void ProcessScreenShot(int InSizeX, int InSizeY, TArray<struct FColor> InImageData);
};

// Class AndroidGoodies.AGShareBPL
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGShareBPL : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGShareBPL");
		return ptr;
	}



	void STATIC_TweetTextWithImage(const struct FString& Text, class UTexture2D* Image);
	void STATIC_TweetText(const struct FString& Text);
	void STATIC_ShareVideo(const struct FString& videoPath, bool showChooser, const struct FString& chooserTitle);
	void STATIC_ShareTextWithImage(const struct FString& Subject, const struct FString& Text, class UTexture2D* Image, bool showChooser, const struct FString& chooserTitle);
	void STATIC_ShareText(const struct FString& Subject, const struct FString& Text, bool showChooser, const struct FString& chooserTitle);
	void STATIC_ShareInstagram(class UTexture2D* Image);
	void STATIC_ShareImage(class UTexture2D* Image, bool showChooser, const struct FString& chooserTitle);
	void STATIC_SendWhatsAppText(const struct FString& Text);
	void STATIC_SendWhatsAppImage(class UTexture2D* Image);
	void STATIC_SendViberText(const struct FString& Text);
	void STATIC_SendViberImage(class UTexture2D* Image);
	void STATIC_SendTelegramText(const struct FString& Text);
	void STATIC_SendTelegramImage(class UTexture2D* Image);
	void STATIC_SendSmsWithDefaultApp(const struct FString& phoneNumber, const struct FString& Message, bool showChooser, const struct FString& chooserTitle);
	void STATIC_SendSmsSilently(const struct FString& phoneNumber, const struct FString& Message);
	void STATIC_SendMultipleImagesEMail(const struct FAGShareEmailData& emailData, TArray<class UTexture2D*> extraImages, bool showChooser, const struct FString& chooserTitle);
	void STATIC_SendFacebookText(const struct FString& Text);
	void STATIC_SendFacebookImage(class UTexture2D* Image);
	void STATIC_SendEMail(const struct FAGShareEmailData& emailData, bool showChooser, const struct FString& chooserTitle);
};

// Class AndroidGoodies.AGToastBPL
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGToastBPL : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGToastBPL");
		return ptr;
	}



	void STATIC_ShowToast(const struct FString& Message, TEnumAsByte<AndroidGoodies_EToastLength> Length);
};

// Class AndroidGoodies.AGVibrationEffect
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAGVibrationEffect : public UObject
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AGVibrationEffect");
		return ptr;
	}



	class UAGVibrationEffect* STATIC_VibrationEffectWaveFormWithAmplitudes(TArray<float> timings, TArray<int> amplitudes, int Repeat);
	class UAGVibrationEffect* STATIC_VibrationEffectWaveForm(TArray<float> timings, int Repeat);
	class UAGVibrationEffect* STATIC_VibrationEffectOneShot(float Seconds, int Amplitude);
};

// Class AndroidGoodies.AndroidGoodiesSettings
// 0x0030 (FullSize[0x0058] - InheritedSize[0x0028])
class UAndroidGoodiesSettings : public UObject
{
public:
	unsigned char                                      UnknownData_M8B4[0x10];                                    // 0x0028(0x0010) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	struct FDirectoryPath                              AndroidDrawablesFolder;                                    // 0x0038(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, Config, NativeAccessSpecifierPublic)
	bool                                               sendSmsPermission;                                         // 0x0048(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               setAlarmPermission;                                        // 0x0049(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               cameraPermission;                                          // 0x004A(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               flashlightPermission;                                      // 0x004B(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               vibratePermission;                                         // 0x004C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               callPhonePermission;                                       // 0x004D(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               readPhoneStatePermission;                                  // 0x004E(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               readContactsPermission;                                    // 0x004F(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               writeContactsPermission;                                   // 0x0050(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               installPackagesPermission;                                 // 0x0051(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	unsigned char                                      UnknownData_60WP[0x6];                                     // 0x0052(0x0006) MISSED OFFSET (PADDING)


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("Class AndroidGoodies.AndroidGoodiesSettings");
		return ptr;
	}



};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Login.B_Login_C.Display_OpenWidget
//		Flags  -> (Event, Public, BlueprintEvent)
void UB_Login_C::Display_OpenWidget()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Login.B_Login_C.Display_OpenWidget");

	UB_Login_C_Display_OpenWidget_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Login.B_Login_C.Display_ClearAll
//		Flags  -> (Event, Public, BlueprintEvent)
void UB_Login_C::Display_ClearAll()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Login.B_Login_C.Display_ClearAll");

	UB_Login_C_Display_ClearAll_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Login.B_Login_C.Display_ShowLoading
//		Flags  -> (Event, Public, BlueprintEvent)
void UB_Login_C::Display_ShowLoading()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Login.B_Login_C.Display_ShowLoading");

	UB_Login_C_Display_ShowLoading_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Login.B_Login_C.Display_EndLoading
//		Flags  -> (Event, Public, BlueprintEvent)
void UB_Login_C::Display_EndLoading()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Login.B_Login_C.Display_EndLoading");

	UB_Login_C_Display_EndLoading_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Login.B_Login_C.Display_ShowLoginInfo
//		Flags  -> (Event, Public, BlueprintEvent)
void UB_Login_C::Display_ShowLoginInfo()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Login.B_Login_C.Display_ShowLoginInfo");

	UB_Login_C_Display_ShowLoginInfo_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Login.B_Login_C.Display_ShowTouchNotice
//		Flags  -> (Event, Public, BlueprintEvent)
void UB_Login_C::Display_ShowTouchNotice()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Login.B_Login_C.Display_ShowTouchNotice");

	UB_Login_C_Display_ShowTouchNotice_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Login.B_Login_C.ExecuteUbergraph_B_Login
//		Flags  -> (Final)
// Parameters:
//		int                                                EntryPoint                                                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UB_Login_C::ExecuteUbergraph_B_Login(int EntryPoint)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Login.B_Login_C.ExecuteUbergraph_B_Login");

	UB_Login_C_ExecuteUbergraph_B_Login_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

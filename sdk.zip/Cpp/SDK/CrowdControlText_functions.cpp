﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x01C40890
//		Name   -> Function CrowdControlText.CrowdControlText_C.Construct
//		Flags  -> (BlueprintCosmetic, Event, Public, BlueprintEvent)
void UCrowdControlText_C::Construct()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function CrowdControlText.CrowdControlText_C.Construct");

	UCrowdControlText_C_Construct_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function CrowdControlText.CrowdControlText_C.WidgetAnimationEvt_Ani_Up_K2Node_WidgetAnimationEvent_1
//		Flags  -> (BlueprintEvent)
void UCrowdControlText_C::WidgetAnimationEvt_Ani_Up_K2Node_WidgetAnimationEvent_1()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function CrowdControlText.CrowdControlText_C.WidgetAnimationEvt_Ani_Up_K2Node_WidgetAnimationEvent_1");

	UCrowdControlText_C_WidgetAnimationEvt_Ani_Up_K2Node_WidgetAnimationEvent_1_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function CrowdControlText.CrowdControlText_C.WidgetAnimationEvt_Ani_Down_K2Node_WidgetAnimationEvent_2
//		Flags  -> (BlueprintEvent)
void UCrowdControlText_C::WidgetAnimationEvt_Ani_Down_K2Node_WidgetAnimationEvent_2()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function CrowdControlText.CrowdControlText_C.WidgetAnimationEvt_Ani_Down_K2Node_WidgetAnimationEvent_2");

	UCrowdControlText_C_WidgetAnimationEvt_Ani_Down_K2Node_WidgetAnimationEvent_2_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function CrowdControlText.CrowdControlText_C.ExecuteUbergraph_CrowdControlText
//		Flags  -> (Final)
// Parameters:
//		int                                                EntryPoint                                                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UCrowdControlText_C::ExecuteUbergraph_CrowdControlText(int EntryPoint)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function CrowdControlText.CrowdControlText_C.ExecuteUbergraph_CrowdControlText");

	UCrowdControlText_C_ExecuteUbergraph_CrowdControlText_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass AttackCalculate.AttackCalculate_C
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UAttackCalculate_C : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("BlueprintGeneratedClass AttackCalculate.AttackCalculate_C");
		return ptr;
	}



	void STATIC_CalcSTD(int STDlevel, int Ability, int Max, int Min, class UObject* __WorldContext, float* NewParam4);
	void STATIC_공격데미지계산(const struct FATTACK_DATA& Data, class UObject* __WorldContext, float* Damage);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

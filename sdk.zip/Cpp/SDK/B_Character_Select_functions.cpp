﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Character_Select.B_Character_Select_C.MoveToClassSelectEvent
//		Flags  -> (Event, Public, BlueprintEvent)
void UB_Character_Select_C::MoveToClassSelectEvent()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Character_Select.B_Character_Select_C.MoveToClassSelectEvent");

	UB_Character_Select_C_MoveToClassSelectEvent_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Character_Select.B_Character_Select_C.PlayOpenAnimation
//		Flags  -> (Event, Public, BlueprintEvent)
void UB_Character_Select_C::PlayOpenAnimation()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Character_Select.B_Character_Select_C.PlayOpenAnimation");

	UB_Character_Select_C_PlayOpenAnimation_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Character_Select.B_Character_Select_C.FinishEvent
//		Flags  -> (BlueprintCallable, BlueprintEvent)
void UB_Character_Select_C::FinishEvent()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Character_Select.B_Character_Select_C.FinishEvent");

	UB_Character_Select_C_FinishEvent_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Character_Select.B_Character_Select_C.Construct
//		Flags  -> (BlueprintCosmetic, Event, Public, BlueprintEvent)
void UB_Character_Select_C::Construct()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Character_Select.B_Character_Select_C.Construct");

	UB_Character_Select_C_Construct_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_Character_Select.B_Character_Select_C.ExecuteUbergraph_B_Character_Select
//		Flags  -> (Final)
// Parameters:
//		int                                                EntryPoint                                                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UB_Character_Select_C::ExecuteUbergraph_B_Character_Select(int EntryPoint)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_Character_Select.B_Character_Select_C.ExecuteUbergraph_B_Character_Select");

	UB_Character_Select_C_ExecuteUbergraph_B_Character_Select_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

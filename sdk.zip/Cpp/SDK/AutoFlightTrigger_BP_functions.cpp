﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x01C40890
//		Name   -> Function AutoFlightTrigger_BP.AutoFlightTrigger_BP_C.UserConstructionScript
//		Flags  -> (Event, Public, HasDefaults, BlueprintCallable, BlueprintEvent)
void AAutoFlightTrigger_BP_C::UserConstructionScript()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AutoFlightTrigger_BP.AutoFlightTrigger_BP_C.UserConstructionScript");

	AAutoFlightTrigger_BP_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function AutoFlightTrigger_BP.AutoFlightTrigger_BP_C.ReceiveBeginPlay
//		Flags  -> (Event, Protected, BlueprintEvent)
void AAutoFlightTrigger_BP_C::ReceiveBeginPlay()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AutoFlightTrigger_BP.AutoFlightTrigger_BP_C.ReceiveBeginPlay");

	AAutoFlightTrigger_BP_C_ReceiveBeginPlay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function AutoFlightTrigger_BP.AutoFlightTrigger_BP_C.ExecuteUbergraph_AutoFlightTrigger_BP
//		Flags  -> (Final)
// Parameters:
//		int                                                EntryPoint                                                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AAutoFlightTrigger_BP_C::ExecuteUbergraph_AutoFlightTrigger_BP(int EntryPoint)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function AutoFlightTrigger_BP.AutoFlightTrigger_BP_C.ExecuteUbergraph_AutoFlightTrigger_BP");

	AAutoFlightTrigger_BP_C_ExecuteUbergraph_AutoFlightTrigger_BP_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

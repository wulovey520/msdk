﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function AutoFlightTrigger_BP.AutoFlightTrigger_BP_C.UserConstructionScript
struct AAutoFlightTrigger_BP_C_UserConstructionScript_Params
{
};

// Function AutoFlightTrigger_BP.AutoFlightTrigger_BP_C.ReceiveBeginPlay
struct AAutoFlightTrigger_BP_C_ReceiveBeginPlay_Params
{
};

// Function AutoFlightTrigger_BP.AutoFlightTrigger_BP_C.ExecuteUbergraph_AutoFlightTrigger_BP
struct AAutoFlightTrigger_BP_C_ExecuteUbergraph_AutoFlightTrigger_BP_Params
{
	int                                                EntryPoint;                                                // 0x0000(0x0004)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

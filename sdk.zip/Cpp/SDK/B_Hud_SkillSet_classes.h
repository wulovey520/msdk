﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass B_Hud_SkillSet.B_Hud_SkillSet_C
// 0x0008 (FullSize[0x03D0] - InheritedSize[0x03C8])
class UB_Hud_SkillSet_C : public UMM_B_SkillSet
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                            // 0x03C8(0x0008) (ZeroConstructor, Transient, DuplicateTransient)


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("WidgetBlueprintGeneratedClass B_Hud_SkillSet.B_Hud_SkillSet_C");
		return ptr;
	}



	void PreConstruct(bool IsDesignTime);
	void ExecuteUbergraph_B_Hud_SkillSet(int EntryPoint);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x01C40890
//		Name   -> Function Common_Btn_Symbol.Common_Btn_Symbol_C.Construct
//		Flags  -> (BlueprintCosmetic, Event, Public, BlueprintEvent)
void UCommon_Btn_Symbol_C::Construct()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function Common_Btn_Symbol.Common_Btn_Symbol_C.Construct");

	UCommon_Btn_Symbol_C_Construct_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function Common_Btn_Symbol.Common_Btn_Symbol_C.PreConstruct
//		Flags  -> (BlueprintCosmetic, Event, Public, BlueprintEvent)
// Parameters:
//		bool                                               IsDesignTime                                               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
void UCommon_Btn_Symbol_C::PreConstruct(bool IsDesignTime)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function Common_Btn_Symbol.Common_Btn_Symbol_C.PreConstruct");

	UCommon_Btn_Symbol_C_PreConstruct_Params params;
	params.IsDesignTime = IsDesignTime;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function Common_Btn_Symbol.Common_Btn_Symbol_C.ExecuteUbergraph_Common_Btn_Symbol
//		Flags  -> (Final)
// Parameters:
//		int                                                EntryPoint                                                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UCommon_Btn_Symbol_C::ExecuteUbergraph_Common_Btn_Symbol(int EntryPoint)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function Common_Btn_Symbol.Common_Btn_Symbol_C.ExecuteUbergraph_Common_Btn_Symbol");

	UCommon_Btn_Symbol_C_ExecuteUbergraph_Common_Btn_Symbol_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

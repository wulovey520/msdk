﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass Customizing_Palette_4.Customizing_Palette_3_C
// 0x0030 (FullSize[0x0388] - InheritedSize[0x0358])
class UCustomizing_Palette_3_C : public UMM_Customizing_Costume_Palette
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                            // 0x0358(0x0008) (ZeroConstructor, Transient, DuplicateTransient)
	class UCustomizing_Palette_ColorItem_C*            Customizing_Palette_ColorItem;                             // 0x0360(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UMirImage*                                   MirImage;                                                  // 0x0368(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UMirImage*                                   MirImage_128;                                              // 0x0370(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	TArray<class UCustomizing_Palette_ColorItem_C*>    m_PaletteItemArray_1;                                      // 0x0378(0x0010) (Edit, BlueprintVisible, ZeroConstructor, ContainsInstancedReference)


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("WidgetBlueprintGeneratedClass Customizing_Palette_4.Customizing_Palette_3_C");
		return ptr;
	}



	TArray<class UMM_Customizing_PaletteItem*> CreatePaletteItem(int Count);
	void PreConstruct(bool IsDesignTime);
	void ExecuteUbergraph_Customizing_Palette_4(int EntryPoint);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

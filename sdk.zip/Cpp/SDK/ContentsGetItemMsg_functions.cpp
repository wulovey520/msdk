﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x01C40890
//		Name   -> Function ContentsGetItemMsg.ContentsGetItemMsg_C.Construct
//		Flags  -> (BlueprintCosmetic, Event, Public, BlueprintEvent)
void UContentsGetItemMsg_C::Construct()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function ContentsGetItemMsg.ContentsGetItemMsg_C.Construct");

	UContentsGetItemMsg_C_Construct_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function ContentsGetItemMsg.ContentsGetItemMsg_C.UpdateDesign
//		Flags  -> (Event, Public, BlueprintEvent)
void UContentsGetItemMsg_C::UpdateDesign()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function ContentsGetItemMsg.ContentsGetItemMsg_C.UpdateDesign");

	UContentsGetItemMsg_C_UpdateDesign_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function ContentsGetItemMsg.ContentsGetItemMsg_C.ExecuteUbergraph_ContentsGetItemMsg
//		Flags  -> (Final)
// Parameters:
//		int                                                EntryPoint                                                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UContentsGetItemMsg_C::ExecuteUbergraph_ContentsGetItemMsg(int EntryPoint)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function ContentsGetItemMsg.ContentsGetItemMsg_C.ExecuteUbergraph_ContentsGetItemMsg");

	UContentsGetItemMsg_C_ExecuteUbergraph_ContentsGetItemMsg_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

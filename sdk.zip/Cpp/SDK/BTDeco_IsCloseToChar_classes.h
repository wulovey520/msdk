﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BTDeco_IsCloseToChar.BTDeco_IsCloseToChar_C
// 0x0050 (FullSize[0x00F0] - InheritedSize[0x00A0])
class UBTDeco_IsCloseToChar_C : public UBTDecorator_BlueprintBase
{
public:
	struct FBlackboardKeySelector                      CharacterKey;                                              // 0x00A0(0x0028) (Edit, BlueprintVisible)
	struct FBlackboardKeySelector                      RangeKey;                                                  // 0x00C8(0x0028) (Edit, BlueprintVisible)


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("BlueprintGeneratedClass BTDeco_IsCloseToChar.BTDeco_IsCloseToChar_C");
		return ptr;
	}



	bool PerformConditionCheck(class AActor* OwnerActor);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

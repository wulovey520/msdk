﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BGMTrigger_BP.BGMTrigger_BP_C.UserConstructionScript
struct ABGMTrigger_BP_C_UserConstructionScript_Params
{
};

// Function BGMTrigger_BP.BGMTrigger_BP_C.OverlapPlayBGM_Event
struct ABGMTrigger_BP_C_OverlapPlayBGM_Event_Params
{
};

// Function BGMTrigger_BP.BGMTrigger_BP_C.ExecuteUbergraph_BGMTrigger_BP
struct ABGMTrigger_BP_C_ExecuteUbergraph_BGMTrigger_BP_Params
{
	int                                                EntryPoint;                                                // 0x0000(0x0004)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

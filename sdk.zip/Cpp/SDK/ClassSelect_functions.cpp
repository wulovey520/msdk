﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x01C40890
//		Name   -> Function ClassSelect.ClassSelect_C.PlayOpenAnimation
//		Flags  -> (Event, Public, BlueprintEvent)
void UClassSelect_C::PlayOpenAnimation()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function ClassSelect.ClassSelect_C.PlayOpenAnimation");

	UClassSelect_C_PlayOpenAnimation_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function ClassSelect.ClassSelect_C.MoveToCustomizingEvent
//		Flags  -> (Event, Public, BlueprintEvent)
void UClassSelect_C::MoveToCustomizingEvent()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function ClassSelect.ClassSelect_C.MoveToCustomizingEvent");

	UClassSelect_C_MoveToCustomizingEvent_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function ClassSelect.ClassSelect_C.MoveToCharacterSelectEvent
//		Flags  -> (Event, Public, BlueprintEvent)
void UClassSelect_C::MoveToCharacterSelectEvent()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function ClassSelect.ClassSelect_C.MoveToCharacterSelectEvent");

	UClassSelect_C_MoveToCharacterSelectEvent_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function ClassSelect.ClassSelect_C.ExecuteUbergraph_ClassSelect
//		Flags  -> (Final)
// Parameters:
//		int                                                EntryPoint                                                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UClassSelect_C::ExecuteUbergraph_ClassSelect(int EntryPoint)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function ClassSelect.ClassSelect_C.ExecuteUbergraph_ClassSelect");

	UClassSelect_C_ExecuteUbergraph_ClassSelect_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

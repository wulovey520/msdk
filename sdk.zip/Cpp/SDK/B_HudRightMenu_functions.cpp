﻿// Name: Mir4, Version: 2

#include "../pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_HudRightMenu.B_HudRightMenu_C.Construct
//		Flags  -> (BlueprintCosmetic, Event, Public, BlueprintEvent)
void UB_HudRightMenu_C::Construct()
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_HudRightMenu.B_HudRightMenu_C.Construct");

	UB_HudRightMenu_C_Construct_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function:
//		Offset -> 0x01C40890
//		Name   -> Function B_HudRightMenu.B_HudRightMenu_C.ExecuteUbergraph_B_HudRightMenu
//		Flags  -> (Final)
// Parameters:
//		int                                                EntryPoint                                                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UB_HudRightMenu_C::ExecuteUbergraph_B_HudRightMenu(int EntryPoint)
{
	static UFunction* fn = UObject::FindObject<UFunction>("Function B_HudRightMenu.B_HudRightMenu_C.ExecuteUbergraph_B_HudRightMenu");

	UB_HudRightMenu_C_ExecuteUbergraph_B_HudRightMenu_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

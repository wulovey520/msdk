﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BTDeco_IsCloseAnyChar.BTDeco_IsCloseAnyChar_C
// 0x0050 (FullSize[0x00F0] - InheritedSize[0x00A0])
class UBTDeco_IsCloseAnyChar_C : public UBTDecorator_BlueprintBase
{
public:
	struct FBlackboardKeySelector                      CharacterKeyA;                                             // 0x00A0(0x0028) (Edit, BlueprintVisible)
	struct FBlackboardKeySelector                      CharacterKeyB;                                             // 0x00C8(0x0028) (Edit, BlueprintVisible)


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("BlueprintGeneratedClass BTDeco_IsCloseAnyChar.BTDeco_IsCloseAnyChar_C");
		return ptr;
	}



	bool PerformConditionCheck(class AActor* OwnerActor);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass Common_Dialog_Btn.Common_Dialog_Btn_C
// 0x0000 (FullSize[0x0340] - InheritedSize[0x0340])
class UCommon_Dialog_Btn_C : public UMM_Common_Dialog_Btn
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("WidgetBlueprintGeneratedClass Common_Dialog_Btn.Common_Dialog_Btn_C");
		return ptr;
	}



};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

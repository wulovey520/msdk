﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass Customizing_ComponentTitle.Customizing_ComponentTitle_C
// 0x0000 (FullSize[0x02F0] - InheritedSize[0x02F0])
class UCustomizing_ComponentTitle_C : public UMM_Customizing_ComponentTitle
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("WidgetBlueprintGeneratedClass Customizing_ComponentTitle.Customizing_ComponentTitle_C");
		return ptr;
	}



};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

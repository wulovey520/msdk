﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass Customizing_Component.Customizing_Component_C
// 0x0030 (FullSize[0x0350] - InheritedSize[0x0320])
class UCustomizing_Component_C : public UMM_Customizing_Component
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                            // 0x0320(0x0008) (ZeroConstructor, Transient, DuplicateTransient)
	class UCustomizing_DoubleScroll_C*                 Customizing_DoubleScroll;                                  // 0x0328(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UCustomizing_Palette_3_C*                    Customizing_Palette_4;                                     // 0x0330(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	class UCustomizing_Palette_Item_C*                 Customizing_Palette_Item;                                  // 0x0338(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)
	TArray<class UCustomizing_Palette_ColorItem_C*>    m_PaletteItemArray_1;                                      // 0x0340(0x0010) (Edit, BlueprintVisible, ZeroConstructor, ContainsInstancedReference)


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("WidgetBlueprintGeneratedClass Customizing_Component.Customizing_Component_C");
		return ptr;
	}



	TArray<class UMM_Customizing_PaletteItem*> CreatePaletteItem(int Count);
	void PreConstruct(bool IsDesignTime);
	void ExecuteUbergraph_Customizing_Component(int EntryPoint);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass CrowdControlText.CrowdControlText_C
// 0x0020 (FullSize[0x03B0] - InheritedSize[0x0390])
class UCrowdControlText_C : public UMM_CrowdControlText
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                            // 0x0390(0x0008) (ZeroConstructor, Transient, DuplicateTransient)
	class UWidgetAnimation*                            Ani_PetUp;                                                 // 0x0398(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                            Ani_Down;                                                  // 0x03A0(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                            Ani_Up;                                                    // 0x03A8(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("WidgetBlueprintGeneratedClass CrowdControlText.CrowdControlText_C");
		return ptr;
	}



	void Construct();
	void WidgetAnimationEvt_Ani_Up_K2Node_WidgetAnimationEvent_1();
	void WidgetAnimationEvt_Ani_Down_K2Node_WidgetAnimationEvent_2();
	void ExecuteUbergraph_CrowdControlText(int EntryPoint);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

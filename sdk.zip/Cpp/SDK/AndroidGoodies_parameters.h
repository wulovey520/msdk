﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function AndroidGoodies.AGAlarmClock.SnoozeAlarm
struct UAGAlarmClock_SnoozeAlarm_Params
{
	int                                                snoozeDurationMinutes;                                     // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGAlarmClock.ShowAllTimers
struct UAGAlarmClock_ShowAllTimers_Params
{
};

// Function AndroidGoodies.AGAlarmClock.ShowAllAlarms
struct UAGAlarmClock_ShowAllAlarms_Params
{
};

// Function AndroidGoodies.AGAlarmClock.SetTimer
struct UAGAlarmClock_SetTimer_Params
{
	int                                                lengthSeconds;                                             // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Message;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               skipUi;                                                    // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGAlarmClock.SetAlarm
struct UAGAlarmClock_SetAlarm_Params
{
	int                                                Hour;                                                      // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                Minute;                                                    // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Message;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FAGAlarmDaysData                            days;                                                      // 0x0000(0x0007)  (Parm, NoDestructor, NativeAccessSpecifierPublic)
	bool                                               Vibrate;                                                   // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               skipUi;                                                    // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGAlarmClock.CanSetTimer
struct UAGAlarmClock_CanSetTimer_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGAlarmClock.CanSetAlarm
struct UAGAlarmClock_CanSetAlarm_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGApps.UninstallPackage
struct UAGApps_UninstallPackage_Params
{
	struct FString                                     PackageName;                                               // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGApps.OpenYoutubeVideo
struct UAGApps_OpenYoutubeVideo_Params
{
	struct FString                                     videoId;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGApps.OpenTwitterProfile
struct UAGApps_OpenTwitterProfile_Params
{
	struct FString                                     profileId;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGApps.OpenInstagramProfile
struct UAGApps_OpenInstagramProfile_Params
{
	struct FString                                     profileId;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGApps.OpenFacebookProfile
struct UAGApps_OpenFacebookProfile_Params
{
	struct FString                                     profileId;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGApps.OpenAnotherApplication
struct UAGApps_OpenAnotherApplication_Params
{
	struct FString                                     PackageName;                                               // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGApps.InstallApkFromFile
struct UAGApps_InstallApkFromFile_Params
{
	struct FString                                     FilePath;                                                  // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             OnError;                                                   // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGApps.HasPhoneApp
struct UAGApps_HasPhoneApp_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGApps.DownloadAndInstallApk
struct UAGApps_DownloadAndInstallApk_Params
{
	struct FString                                     DownloadUrl;                                               // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     DownloadTitle;                                             // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     DownloadDescription;                                       // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             OnError;                                                   // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGApps.DialPhoneNumber
struct UAGApps_DialPhoneNumber_Params
{
	struct FString                                     Number;                                                    // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGApps.CallPhoneNumber
struct UAGApps_CallPhoneNumber_Params
{
	struct FString                                     Number;                                                    // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenFile.IsSuccess
struct UAGChosenFile_IsSuccess_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenFile.GetSize
struct UAGChosenFile_GetSize_Params
{
	int64_t                                            ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenFile.GetOriginalPath
struct UAGChosenFile_GetOriginalPath_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenFile.GetMimeType
struct UAGChosenFile_GetMimeType_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenFile.GetHumanReadableSize
struct UAGChosenFile_GetHumanReadableSize_Params
{
	bool                                               bytesRounded;                                              // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenFile.GetFileExtensionFromMimeTypeWithoutDot
struct UAGChosenFile_GetFileExtensionFromMimeTypeWithoutDot_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenFile.GetFileExtensionFromMimeType
struct UAGChosenFile_GetFileExtensionFromMimeType_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenFile.GetDisplayName
struct UAGChosenFile_GetDisplayName_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenFile.GetCreatedAt
struct UAGChosenFile_GetCreatedAt_Params
{
	struct FDateTime                                   ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenImage.GetWidth
struct UAGChosenImage_GetWidth_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenImage.GetThumbnailSmallPath
struct UAGChosenImage_GetThumbnailSmallPath_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenImage.GetThumbnailPath
struct UAGChosenImage_GetThumbnailPath_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenImage.GetOrientationName
struct UAGChosenImage_GetOrientationName_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenImage.GetOrientation
struct UAGChosenImage_GetOrientation_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGChosenImage.GetHeight
struct UAGChosenImage_GetHeight_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGContactsBPL.GetUserPhoneNumber
struct UAGContactsBPL_GetUserPhoneNumber_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGContactsBPL.GetContactsWithNumber
struct UAGContactsBPL_GetContactsWithNumber_Params
{
	struct FString                                     Number;                                                    // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<struct FAGContact>                          ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGContactsBPL.GetContactsWithName
struct UAGContactsBPL_GetContactsWithName_Params
{
	struct FString                                     Name;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<struct FAGContact>                          ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGContactsBPL.GetAllContacts
struct UAGContactsBPL_GetAllContacts_Params
{
	TArray<struct FAGContact>                          ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGContactsBPL.AddContact
struct UAGContactsBPL_AddContact_Params
{
	struct FAGContact                                  contact;                                                   // 0x0000(0x0020)  (Parm, NativeAccessSpecifierPublic)
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDateTimePickerBPL.ShowTimePicker
struct UAGDateTimePickerBPL_ShowTimePicker_Params
{
	int                                                Hour;                                                      // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                Minute;                                                    // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onTimeSetCallback;                                         // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onCancelCallback;                                          // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme;                                                     // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               is24HourView;                                              // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDateTimePickerBPL.ShowDatePickerWithLimits
struct UAGDateTimePickerBPL_ShowDatePickerWithLimits_Params
{
	struct FDateTime                                   initialDate;                                               // 0x0000(0x0008)  (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onDateSetCallback;                                         // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onCancelCallback;                                          // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FDateTime                                   fromDate;                                                  // 0x0000(0x0008)  (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FDateTime                                   toDate;                                                    // 0x0000(0x0008)  (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme;                                                     // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDateTimePickerBPL.ShowDatePicker
struct UAGDateTimePickerBPL_ShowDatePicker_Params
{
	struct FDateTime                                   initialDate;                                               // 0x0000(0x0008)  (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onDateSetCallback;                                         // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onCancelCallback;                                          // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme;                                                     // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsWifiRtt
struct UAGDeviceInfo_SupportsWifiRtt_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsWifiPassPoint
struct UAGDeviceInfo_SupportsWifiPassPoint_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsWifiDirect
struct UAGDeviceInfo_SupportsWifiDirect_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsWifiAware
struct UAGDeviceInfo_SupportsWifiAware_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsWifi
struct UAGDeviceInfo_SupportsWifi_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsWebView
struct UAGDeviceInfo_SupportsWebView_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsVulkanHardwareVersion
struct UAGDeviceInfo_SupportsVulkanHardwareVersion_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsVulkanHardwareLevel
struct UAGDeviceInfo_SupportsVulkanHardwareLevel_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsVulkanHardwareCompute
struct UAGDeviceInfo_SupportsVulkanHardwareCompute_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsVerifiedBoot
struct UAGDeviceInfo_SupportsVerifiedBoot_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsUsbHost
struct UAGDeviceInfo_SupportsUsbHost_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsUsbAccessory
struct UAGDeviceInfo_SupportsUsbAccessory_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsTouchScreenMultiTouchJazzHand
struct UAGDeviceInfo_SupportsTouchScreenMultiTouchJazzHand_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsTouchScreenMultiTouchDistinct
struct UAGDeviceInfo_SupportsTouchScreenMultiTouchDistinct_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsTouchScreenMultiTouch
struct UAGDeviceInfo_SupportsTouchScreenMultiTouch_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsSipVoip
struct UAGDeviceInfo_SupportsSipVoip_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsSecureUserRemoval
struct UAGDeviceInfo_SupportsSecureUserRemoval_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsScreenPortrtait
struct UAGDeviceInfo_SupportsScreenPortrtait_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsScreenLandscape
struct UAGDeviceInfo_SupportsScreenLandscape_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsPrinting
struct UAGDeviceInfo_SupportsPrinting_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsPictureInPicture
struct UAGDeviceInfo_SupportsPictureInPicture_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsOpenGlEsExtensionPack
struct UAGDeviceInfo_SupportsOpenGlEsExtensionPack_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsNfcHostCardEmulationNfcf
struct UAGDeviceInfo_SupportsNfcHostCardEmulationNfcf_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsNfcHostCardEmulation
struct UAGDeviceInfo_SupportsNfcHostCardEmulation_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsNfc
struct UAGDeviceInfo_SupportsNfc_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsMidi
struct UAGDeviceInfo_SupportsMidi_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsManagedUsers
struct UAGDeviceInfo_SupportsManagedUsers_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsLocationNetwork
struct UAGDeviceInfo_SupportsLocationNetwork_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsLocationGps
struct UAGDeviceInfo_SupportsLocationGps_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsLocation
struct UAGDeviceInfo_SupportsLocation_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsLiveWallpaper
struct UAGDeviceInfo_SupportsLiveWallpaper_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsLiveTv
struct UAGDeviceInfo_SupportsLiveTv_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsLeanbackOnly
struct UAGDeviceInfo_SupportsLeanbackOnly_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsLeanback
struct UAGDeviceInfo_SupportsLeanback_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsInputMethods
struct UAGDeviceInfo_SupportsInputMethods_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsHomeScreen
struct UAGDeviceInfo_SupportsHomeScreen_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsHifiSensors
struct UAGDeviceInfo_SupportsHifiSensors_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsFreeFormWindowManagement
struct UAGDeviceInfo_SupportsFreeFormWindowManagement_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsFingerprint
struct UAGDeviceInfo_SupportsFingerprint_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsFakeTouchMultiTouchJazzHand
struct UAGDeviceInfo_SupportsFakeTouchMultiTouchJazzHand_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsFakeTouchMultiTouchDistinct
struct UAGDeviceInfo_SupportsFakeTouchMultiTouchDistinct_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsFakeTouch
struct UAGDeviceInfo_SupportsFakeTouch_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsEthernet
struct UAGDeviceInfo_SupportsEthernet_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsDeviceAdmin
struct UAGDeviceInfo_SupportsDeviceAdmin_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsConsumerIr
struct UAGDeviceInfo_SupportsConsumerIr_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsConnectionService
struct UAGDeviceInfo_SupportsConnectionService_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsCompanionDeviceSetup
struct UAGDeviceInfo_SupportsCompanionDeviceSetup_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsCantSaveState
struct UAGDeviceInfo_SupportsCantSaveState_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsBluetoothLe
struct UAGDeviceInfo_SupportsBluetoothLe_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsBluetooth
struct UAGDeviceInfo_SupportsBluetooth_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsBackup
struct UAGDeviceInfo_SupportsBackup_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsAutomotive
struct UAGDeviceInfo_SupportsAutomotive_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsAutofill
struct UAGDeviceInfo_SupportsAutofill_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsAudioPro
struct UAGDeviceInfo_SupportsAudioPro_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsAudioOutput
struct UAGDeviceInfo_SupportsAudioOutput_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsAudioLowLatency
struct UAGDeviceInfo_SupportsAudioLowLatency_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsAppWidgets
struct UAGDeviceInfo_SupportsAppWidgets_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.SupportsActivitiesOnSecondaryDisplays
struct UAGDeviceInfo_SupportsActivitiesOnSecondaryDisplays_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.IsWatch
struct UAGDeviceInfo_IsWatch_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.IsTelevision
struct UAGDeviceInfo_IsTelevision_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.IsPc
struct UAGDeviceInfo_IsPc_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.IsPackageInstalled
struct UAGDeviceInfo_IsPackageInstalled_Params
{
	struct FString                                     PackageName;                                               // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.IsEmbedded
struct UAGDeviceInfo_IsEmbedded_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasVrModeHighPerformance
struct UAGDeviceInfo_HasVrModeHighPerformance_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasVrMode
struct UAGDeviceInfo_HasVrMode_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasVrHeadTracking
struct UAGDeviceInfo_HasVrHeadTracking_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasTouchScreen
struct UAGDeviceInfo_HasTouchScreen_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasTelephonyMbms
struct UAGDeviceInfo_HasTelephonyMbms_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasTelephonyGsm
struct UAGDeviceInfo_HasTelephonyGsm_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasTelephonyEuicc
struct UAGDeviceInfo_HasTelephonyEuicc_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasTelephonyCdma
struct UAGDeviceInfo_HasTelephonyCdma_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasTelephony
struct UAGDeviceInfo_HasTelephony_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSystemFeature
struct UAGDeviceInfo_HasSystemFeature_Params
{
	struct FString                                     featureName;                                               // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasStrongBoxKeyStore
struct UAGDeviceInfo_HasStrongBoxKeyStore_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSip
struct UAGDeviceInfo_HasSip_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorStepDetector
struct UAGDeviceInfo_HasSensorStepDetector_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorStepCounter
struct UAGDeviceInfo_HasSensorStepCounter_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorRelativeHumidity
struct UAGDeviceInfo_HasSensorRelativeHumidity_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorProximity
struct UAGDeviceInfo_HasSensorProximity_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorLight
struct UAGDeviceInfo_HasSensorLight_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorHeartRateEcg
struct UAGDeviceInfo_HasSensorHeartRateEcg_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorHeartRate
struct UAGDeviceInfo_HasSensorHeartRate_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorGyroscope
struct UAGDeviceInfo_HasSensorGyroscope_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorCompass
struct UAGDeviceInfo_HasSensorCompass_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorBarometer
struct UAGDeviceInfo_HasSensorBarometer_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorAmbientTemperature
struct UAGDeviceInfo_HasSensorAmbientTemperature_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasSensorAccelerometer
struct UAGDeviceInfo_HasSensorAccelerometer_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasRamNormal
struct UAGDeviceInfo_HasRamNormal_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasRamLow
struct UAGDeviceInfo_HasRamLow_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasMicrophone
struct UAGDeviceInfo_HasMicrophone_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasGamepad
struct UAGDeviceInfo_HasGamepad_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasCameraLevelFull
struct UAGDeviceInfo_HasCameraLevelFull_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasCameraFront
struct UAGDeviceInfo_HasCameraFront_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasCameraFlash
struct UAGDeviceInfo_HasCameraFlash_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasCameraExternal
struct UAGDeviceInfo_HasCameraExternal_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasCameraCapabilityRaw
struct UAGDeviceInfo_HasCameraCapabilityRaw_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasCameraCapabilityManualSensor
struct UAGDeviceInfo_HasCameraCapabilityManualSensor_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasCameraCapabilityManualPostprocessing
struct UAGDeviceInfo_HasCameraCapabilityManualPostprocessing_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasCameraAutofocus
struct UAGDeviceInfo_HasCameraAutofocus_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasCameraAr
struct UAGDeviceInfo_HasCameraAr_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasCameraAny
struct UAGDeviceInfo_HasCameraAny_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.HasCamera
struct UAGDeviceInfo_HasCamera_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetType
struct UAGDeviceInfo_GetType_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetTags
struct UAGDeviceInfo_GetTags_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetSerial
struct UAGDeviceInfo_GetSerial_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetSdkInt
struct UAGDeviceInfo_GetSdkInt_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetRelease
struct UAGDeviceInfo_GetRelease_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetRadio
struct UAGDeviceInfo_GetRadio_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetProduct
struct UAGDeviceInfo_GetProduct_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetModel
struct UAGDeviceInfo_GetModel_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetManufacturer
struct UAGDeviceInfo_GetManufacturer_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetHardware
struct UAGDeviceInfo_GetHardware_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetDisplay
struct UAGDeviceInfo_GetDisplay_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetDevice
struct UAGDeviceInfo_GetDevice_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetCodeName
struct UAGDeviceInfo_GetCodeName_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetBrand
struct UAGDeviceInfo_GetBrand_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetBootloader
struct UAGDeviceInfo_GetBootloader_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetBoard
struct UAGDeviceInfo_GetBoard_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetBaseOs
struct UAGDeviceInfo_GetBaseOs_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetApplicationPackageName
struct UAGDeviceInfo_GetApplicationPackageName_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDeviceInfo.GetAndroidId
struct UAGDeviceInfo_GetAndroidId_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDialogBPL.ShowTwoButtonsDialog
struct UAGDialogBPL_ShowTwoButtonsDialog_Params
{
	struct FString                                     messageTitle;                                              // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Message;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     PositiveButtonText;                                        // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     NegativeButtonText;                                        // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onPositiveButtonClickedCallback;                           // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onNegativeButtonClickedCallback;                           // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onDialogCancelledCallback;                                 // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme;                                                     // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDialogBPL.ShowThreeButtonsDialog
struct UAGDialogBPL_ShowThreeButtonsDialog_Params
{
	struct FString                                     messageTitle;                                              // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Message;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     PositiveButtonText;                                        // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     NegativeButtonText;                                        // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     NeutralButtonText;                                         // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onPositiveButtonClickedCallback;                           // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onNegativeButtonClickedCallback;                           // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onNeutralButtonClickedCallback;                            // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onDialogCancelledCallback;                                 // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme;                                                     // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDialogBPL.ShowSingleItemChoiceDialog
struct UAGDialogBPL_ShowSingleItemChoiceDialog_Params
{
	struct FString                                     listTitle;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<struct FString>                             listItems;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	struct FString                                     PositiveButtonText;                                        // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                selectedItemIndex;                                         // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onSingleChoiceItemClickedCallback;                         // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onPositiveButtonClickedCallback;                           // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onDialogCancelledCallback;                                 // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme;                                                     // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDialogBPL.ShowSingleButtonDialog
struct UAGDialogBPL_ShowSingleButtonDialog_Params
{
	struct FString                                     messageTitle;                                              // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Message;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     PositiveButtonText;                                        // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onPositiveButtonClickedCallback;                           // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onDialogCancelledCallback;                                 // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme;                                                     // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDialogBPL.ShowMultipleItemChoiceDialog
struct UAGDialogBPL_ShowMultipleItemChoiceDialog_Params
{
	struct FString                                     listTitle;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<struct FString>                             listItems;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	struct FString                                     PositiveButtonText;                                        // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<bool>                                       checkedListItems;                                          // 0x0000(0x0010)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onMultipleChoiceItemClickedCallback;                       // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onPositiveButtonClickedCallback;                           // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onDialogCancelledCallback;                                 // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme;                                                     // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGDialogBPL.ShowChooserDialog
struct UAGDialogBPL_ShowChooserDialog_Params
{
	struct FString                                     listTitle;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<struct FString>                             listItems;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onItemChoosedCallback;                                     // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onDialogCancelledCallback;                                 // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EDialogTheme>           Theme;                                                     // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.VibrateWithPattern
struct UAGHardwareBPL_VibrateWithPattern_Params
{
	TArray<float>                                      pattern;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	int                                                repeatFrom;                                                // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.VibrateWithEffectAndAttributes
struct UAGHardwareBPL_VibrateWithEffectAndAttributes_Params
{
	class UAGVibrationEffect*                          vibrationEffect;                                           // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FAGAudioAttributes                          audioAttributes;                                           // 0x0000(0x0005)  (Parm, NoDestructor, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.VibrateWithEffect
struct UAGHardwareBPL_VibrateWithEffect_Params
{
	class UAGVibrationEffect*                          vibrationEffect;                                           // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.Vibrate
struct UAGHardwareBPL_Vibrate_Params
{
	float                                              Duration;                                                  // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.StopVibration
struct UAGHardwareBPL_StopVibration_Params
{
};

// Function AndroidGoodies.AGHardwareBPL.IsBatteryPresent
struct UAGHardwareBPL_IsBatteryPresent_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.IsBatteryLow
struct UAGHardwareBPL_IsBatteryLow_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.HasVibrator
struct UAGHardwareBPL_HasVibrator_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.HasAmplitudeControl
struct UAGHardwareBPL_HasAmplitudeControl_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetImmediateBatteryCurrent
struct UAGHardwareBPL_GetImmediateBatteryCurrent_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetBatteryVoltage
struct UAGHardwareBPL_GetBatteryVoltage_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetBatteryTemperature
struct UAGHardwareBPL_GetBatteryTemperature_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetBatteryTechnology
struct UAGHardwareBPL_GetBatteryTechnology_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetBatteryStatus
struct UAGHardwareBPL_GetBatteryStatus_Params
{
	AndroidGoodies_EBatteryStatus                      ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetBatteryScale
struct UAGHardwareBPL_GetBatteryScale_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetBatteryPluggedState
struct UAGHardwareBPL_GetBatteryPluggedState_Params
{
	TEnumAsByte<AndroidGoodies_EBatteryPluggedState>   ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetBatteryLevel
struct UAGHardwareBPL_GetBatteryLevel_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetBatteryHealth
struct UAGHardwareBPL_GetBatteryHealth_Params
{
	AndroidGoodies_EBatteryHealth                      ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetBatteryEnergyCounter
struct UAGHardwareBPL_GetBatteryEnergyCounter_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetBatteryChargeCounter
struct UAGHardwareBPL_GetBatteryChargeCounter_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetBatteryCapacity
struct UAGHardwareBPL_GetBatteryCapacity_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.GetAverageBatteryCurrent
struct UAGHardwareBPL_GetAverageBatteryCurrent_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.EnableFlashlight
struct UAGHardwareBPL_EnableFlashlight_Params
{
	bool                                               Enable;                                                    // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.ComputeRemainingChargeTime
struct UAGHardwareBPL_ComputeRemainingChargeTime_Params
{
	int                                                ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGHardwareBPL.AreVibrationEffectsSupported
struct UAGHardwareBPL_AreVibrationEffectsSupported_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGMaps.UserHasMapsApp
struct UAGMaps_UserHasMapsApp_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGMaps.OpenMapLocationWithLabel
struct UAGMaps_OpenMapLocationWithLabel_Params
{
	float                                              latitude;                                                  // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	float                                              longitude;                                                 // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Label;                                                     // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGMaps.OpenMapLocationWithAddress
struct UAGMaps_OpenMapLocationWithAddress_Params
{
	struct FString                                     address;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGMaps.OpenMapLocation
struct UAGMaps_OpenMapLocation_Params
{
	float                                              latitude;                                                  // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	float                                              longitude;                                                 // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                zoom;                                                      // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBigPictureStyle.SetSummaryText
struct UAGNotificationBigPictureStyle_SetSummaryText_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBigPictureStyle*              ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBigPictureStyle.SetBigLargeIcon
struct UAGNotificationBigPictureStyle_SetBigLargeIcon_Params
{
	class UTexture2D*                                  icon;                                                      // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBigPictureStyle*              ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBigPictureStyle.SetBigContentTitle
struct UAGNotificationBigPictureStyle_SetBigContentTitle_Params
{
	struct FString                                     Title;                                                     // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBigPictureStyle*              ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBigPictureStyle.CreateBigPictureStyle
struct UAGNotificationBigPictureStyle_CreateBigPictureStyle_Params
{
	class UTexture2D*                                  bigPicture;                                                // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBigPictureStyle*              ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBigTextStyle.SetSummaryText
struct UAGNotificationBigTextStyle_SetSummaryText_Params
{
	struct FString                                     summary;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBigTextStyle*                 ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBigTextStyle.SetBigContentTitle
struct UAGNotificationBigTextStyle_SetBigContentTitle_Params
{
	struct FString                                     Title;                                                     // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBigTextStyle*                 ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBigTextStyle.CreateBigTextStyle
struct UAGNotificationBigTextStyle_CreateBigTextStyle_Params
{
	struct FString                                     bigText;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBigTextStyle*                 ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetWhen
struct UAGNotificationBuilder_SetWhen_Params
{
	struct FDateTime                                   DateTime;                                                  // 0x0000(0x0008)  (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetVisibility
struct UAGNotificationBuilder_SetVisibility_Params
{
	TEnumAsByte<AndroidGoodies_ENotificationVisibility> Visibility;                                                // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetVibrate
struct UAGNotificationBuilder_SetVibrate_Params
{
	TArray<float>                                      pattern;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetUsesChronometer
struct UAGNotificationBuilder_SetUsesChronometer_Params
{
	bool                                               usesChronometer;                                           // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetTitle
struct UAGNotificationBuilder_SetTitle_Params
{
	struct FString                                     Title;                                                     // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetTimeoutAfter
struct UAGNotificationBuilder_SetTimeoutAfter_Params
{
	int                                                milliSeconds;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetTicker
struct UAGNotificationBuilder_SetTicker_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetText
struct UAGNotificationBuilder_SetText_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetSubText
struct UAGNotificationBuilder_SetSubText_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetSound
struct UAGNotificationBuilder_SetSound_Params
{
	struct FString                                     Path;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetSortKey
struct UAGNotificationBuilder_SetSortKey_Params
{
	struct FString                                     Key;                                                       // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetSmallIcon
struct UAGNotificationBuilder_SetSmallIcon_Params
{
	struct FString                                     Filename;                                                  // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetShowWhen
struct UAGNotificationBuilder_SetShowWhen_Params
{
	bool                                               showWhen;                                                  // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetShortcutId
struct UAGNotificationBuilder_SetShortcutId_Params
{
	struct FString                                     ID;                                                        // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetPublicVersion
struct UAGNotificationBuilder_SetPublicVersion_Params
{
	class UAGNotification*                             Notification;                                              // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetProgress
struct UAGNotificationBuilder_SetProgress_Params
{
	int                                                current;                                                   // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                Max;                                                       // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               indeterminate;                                             // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetPriority
struct UAGNotificationBuilder_SetPriority_Params
{
	TEnumAsByte<AndroidGoodies_ENotificationPriority>  Priority;                                                  // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetOngoing
struct UAGNotificationBuilder_SetOngoing_Params
{
	bool                                               ongoing;                                                   // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetNumber
struct UAGNotificationBuilder_SetNumber_Params
{
	int                                                Number;                                                    // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetMessagingStyle
struct UAGNotificationBuilder_SetMessagingStyle_Params
{
	class UAGNotificationMessageStyle*                 Style;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetLocalOnly
struct UAGNotificationBuilder_SetLocalOnly_Params
{
	bool                                               localOnly;                                                 // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetLights
struct UAGNotificationBuilder_SetLights_Params
{
	struct FColor                                      Color;                                                     // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                inMilliSeconds;                                            // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                outMilliSeconds;                                           // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetLargeIcon
struct UAGNotificationBuilder_SetLargeIcon_Params
{
	class UTexture2D*                                  icon;                                                      // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetInboxStyle
struct UAGNotificationBuilder_SetInboxStyle_Params
{
	class UAGNotificationInboxStyle*                   Style;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetGroupSummary
struct UAGNotificationBuilder_SetGroupSummary_Params
{
	bool                                               summary;                                                   // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetGroupAlertBehaviour
struct UAGNotificationBuilder_SetGroupAlertBehaviour_Params
{
	TEnumAsByte<AndroidGoodies_ENotificationGroupAlert> behaviour;                                                 // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetGroup
struct UAGNotificationBuilder_SetGroup_Params
{
	struct FString                                     groupKey;                                                  // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetDefaults
struct UAGNotificationBuilder_SetDefaults_Params
{
	struct FAGNotificationDefaults                     defaults;                                                  // 0x0000(0x0003)  (Parm, NoDestructor, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetContentInfo
struct UAGNotificationBuilder_SetContentInfo_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetColorized
struct UAGNotificationBuilder_SetColorized_Params
{
	bool                                               colorized;                                                 // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetColor
struct UAGNotificationBuilder_SetColor_Params
{
	struct FColor                                      Color;                                                     // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetCategory
struct UAGNotificationBuilder_SetCategory_Params
{
	TEnumAsByte<AndroidGoodies_ENotificationCategory>  Category;                                                  // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetBigTextStyle
struct UAGNotificationBuilder_SetBigTextStyle_Params
{
	class UAGNotificationBigTextStyle*                 Style;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetBigPictureStyle
struct UAGNotificationBuilder_SetBigPictureStyle_Params
{
	class UAGNotificationBigPictureStyle*              Style;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetBadgeIconType
struct UAGNotificationBuilder_SetBadgeIconType_Params
{
	TEnumAsByte<AndroidGoodies_ENotificationBadgeIconType> badgeIconType;                                             // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetAutoCancel
struct UAGNotificationBuilder_SetAutoCancel_Params
{
	bool                                               autoCancel;                                                // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.SetAlertOnce
struct UAGNotificationBuilder_SetAlertOnce_Params
{
	bool                                               alertOnce;                                                 // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.NewNotificationBuilder
struct UAGNotificationBuilder_NewNotificationBuilder_Params
{
	struct FString                                     ChannelId;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TMap<struct FString, struct FString>               additionalData;                                            // 0x0000(0x0050)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.Build
struct UAGNotificationBuilder_Build_Params
{
	class UAGNotification*                             ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationBuilder.AddOpenUrlAction
struct UAGNotificationBuilder_AddOpenUrlAction_Params
{
	struct FString                                     iconName;                                                  // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Title;                                                     // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     URL;                                                       // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationBuilder*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.ShouldVibrate
struct UAGNotificationChannel_ShouldVibrate_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.ShouldShowLights
struct UAGNotificationChannel_ShouldShowLights_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.SetVibrationPattern
struct UAGNotificationChannel_SetVibrationPattern_Params
{
	TArray<float>                                      pattern;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.SetSound
struct UAGNotificationChannel_SetSound_Params
{
	struct FString                                     FilePath;                                                  // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FAGAudioAttributes                          Attributes;                                                // 0x0000(0x0005)  (Parm, NoDestructor, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.SetShowBadge
struct UAGNotificationChannel_SetShowBadge_Params
{
	bool                                               Show;                                                      // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.SetLockScreenVisibility
struct UAGNotificationChannel_SetLockScreenVisibility_Params
{
	TEnumAsByte<AndroidGoodies_ENotificationVisibility> Visibility;                                                // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.SetLightColor
struct UAGNotificationChannel_SetLightColor_Params
{
	struct FColor                                      Color;                                                     // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.SetImportance
struct UAGNotificationChannel_SetImportance_Params
{
	TEnumAsByte<AndroidGoodies_EChannelImportance>     importance;                                                // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.SetGroup
struct UAGNotificationChannel_SetGroup_Params
{
	struct FString                                     GroupId;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.SetEnableVibration
struct UAGNotificationChannel_SetEnableVibration_Params
{
	bool                                               Enable;                                                    // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.SetEnableLights
struct UAGNotificationChannel_SetEnableLights_Params
{
	bool                                               Enable;                                                    // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.SetDescription
struct UAGNotificationChannel_SetDescription_Params
{
	struct FString                                     Description;                                               // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.SetBypassDnd
struct UAGNotificationChannel_SetBypassDnd_Params
{
	bool                                               bypass;                                                    // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.NewNotificationChannel
struct UAGNotificationChannel_NewNotificationChannel_Params
{
	struct FString                                     ID;                                                        // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Name;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EChannelImportance>     importance;                                                // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.GetVibrationPattern
struct UAGNotificationChannel_GetVibrationPattern_Params
{
	TArray<float>                                      ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.GetSoundPath
struct UAGNotificationChannel_GetSoundPath_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.GetName
struct UAGNotificationChannel_GetName_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.GetLockScreenVisibility
struct UAGNotificationChannel_GetLockScreenVisibility_Params
{
	TEnumAsByte<AndroidGoodies_ENotificationVisibility> ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.GetLightColor
struct UAGNotificationChannel_GetLightColor_Params
{
	struct FColor                                      ReturnValue;                                               // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.GetImportance
struct UAGNotificationChannel_GetImportance_Params
{
	TEnumAsByte<AndroidGoodies_EChannelImportance>     ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.GetId
struct UAGNotificationChannel_GetId_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.GetGroupId
struct UAGNotificationChannel_GetGroupId_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.GetDescription
struct UAGNotificationChannel_GetDescription_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.GetAudioAttributes
struct UAGNotificationChannel_GetAudioAttributes_Params
{
	struct FAGAudioAttributes                          ReturnValue;                                               // 0x0000(0x0005)  (Parm, OutParm, ReturnParm, NoDestructor, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.CanShowBadge
struct UAGNotificationChannel_CanShowBadge_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannel.CanBypassDnd
struct UAGNotificationChannel_CanBypassDnd_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannelGroup.SetDescription
struct UAGNotificationChannelGroup_SetDescription_Params
{
	struct FString                                     Description;                                               // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannelGroup*                 ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannelGroup.NewNotificationChannelGroup
struct UAGNotificationChannelGroup_NewNotificationChannelGroup_Params
{
	struct FString                                     ID;                                                        // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Name;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannelGroup*                 ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannelGroup.IsBlocked
struct UAGNotificationChannelGroup_IsBlocked_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannelGroup.GetName
struct UAGNotificationChannelGroup_GetName_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannelGroup.GetId
struct UAGNotificationChannelGroup_GetId_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannelGroup.GetDescription
struct UAGNotificationChannelGroup_GetDescription_Params
{
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationChannelGroup.GetChannels
struct UAGNotificationChannelGroup_GetChannels_Params
{
	TArray<class UAGNotificationChannel*>              ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationInboxStyle.SetSummaryText
struct UAGNotificationInboxStyle_SetSummaryText_Params
{
	struct FString                                     summary;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationInboxStyle*                   ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationInboxStyle.SetBigContentTitle
struct UAGNotificationInboxStyle_SetBigContentTitle_Params
{
	struct FString                                     Title;                                                     // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationInboxStyle*                   ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationInboxStyle.CreateInboxStyle
struct UAGNotificationInboxStyle_CreateInboxStyle_Params
{
	class UAGNotificationInboxStyle*                   ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationInboxStyle.AddLine
struct UAGNotificationInboxStyle_AddLine_Params
{
	struct FString                                     line;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationInboxStyle*                   ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.WasApplicationOpenViaNotification
struct UAGNotificationManager_WasApplicationOpenViaNotification_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.SetCurrentInterruptionFilter
struct UAGNotificationManager_SetCurrentInterruptionFilter_Params
{
	TEnumAsByte<AndroidGoodies_EInterruptionFilter>    Filter;                                                    // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.ScheduleRepeatingNotification
struct UAGNotificationManager_ScheduleRepeatingNotification_Params
{
	class UAGNotification*                             Notification;                                              // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                ID;                                                        // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FTimespan                                   notifyAfter;                                               // 0x0000(0x0008)  (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FTimespan                                   repeatAfter;                                               // 0x0000(0x0008)  (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.ScheduleNotification
struct UAGNotificationManager_ScheduleNotification_Params
{
	class UAGNotification*                             Notification;                                              // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                ID;                                                        // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FTimespan                                   notifyAfter;                                               // 0x0000(0x0008)  (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.OpenNotificationChannelSettings
struct UAGNotificationManager_OpenNotificationChannelSettings_Params
{
	struct FString                                     ChannelId;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.Notify
struct UAGNotificationManager_Notify_Params
{
	class UAGNotification*                             Notification;                                              // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                ID;                                                        // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.GetNotificationDataForKey
struct UAGNotificationManager_GetNotificationDataForKey_Params
{
	struct FString                                     Key;                                                       // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.GetNotificationChannels
struct UAGNotificationManager_GetNotificationChannels_Params
{
	TArray<class UAGNotificationChannel*>              ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.GetNotificationChannelGroups
struct UAGNotificationManager_GetNotificationChannelGroups_Params
{
	TArray<class UAGNotificationChannelGroup*>         ReturnValue;                                               // 0x0000(0x0010)  (Parm, OutParm, ZeroConstructor, ReturnParm, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.GetNotificationChannelGroup
struct UAGNotificationManager_GetNotificationChannelGroup_Params
{
	struct FString                                     GroupId;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannelGroup*                 ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.GetNotificationChannel
struct UAGNotificationManager_GetNotificationChannel_Params
{
	struct FString                                     ChannelId;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationChannel*                      ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.GetCurrentInterruptionFilter
struct UAGNotificationManager_GetCurrentInterruptionFilter_Params
{
	TEnumAsByte<AndroidGoodies_EInterruptionFilter>    ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.GetCurrentImportance
struct UAGNotificationManager_GetCurrentImportance_Params
{
	TEnumAsByte<AndroidGoodies_EChannelImportance>     ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.DeleteNotificationChannelGroup
struct UAGNotificationManager_DeleteNotificationChannelGroup_Params
{
	struct FString                                     GroupId;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.DeleteNotificationChannel
struct UAGNotificationManager_DeleteNotificationChannel_Params
{
	struct FString                                     ChannelId;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.CreateNotificationChannelGroup
struct UAGNotificationManager_CreateNotificationChannelGroup_Params
{
	class UAGNotificationChannelGroup*                 Group;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.CreateNotificationChannel
struct UAGNotificationManager_CreateNotificationChannel_Params
{
	class UAGNotificationChannel*                      Channel;                                                   // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.CancelScheduledNotification
struct UAGNotificationManager_CancelScheduledNotification_Params
{
	int                                                ID;                                                        // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.CancelNotification
struct UAGNotificationManager_CancelNotification_Params
{
	int                                                ID;                                                        // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationManager.CancelAllNotifications
struct UAGNotificationManager_CancelAllNotifications_Params
{
};

// Function AndroidGoodies.AGNotificationManager.AreNotificationChannelsSupported
struct UAGNotificationManager_AreNotificationChannelsSupported_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationMessageStyle.SetGroupConversation
struct UAGNotificationMessageStyle_SetGroupConversation_Params
{
	bool                                               isGroupConversation;                                       // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationMessageStyle*                 ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationMessageStyle.SetConversationTitle
struct UAGNotificationMessageStyle_SetConversationTitle_Params
{
	struct FString                                     Title;                                                     // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationMessageStyle*                 ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationMessageStyle.CreateMessageStyle
struct UAGNotificationMessageStyle_CreateMessageStyle_Params
{
	struct FString                                     userDisplayName;                                           // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationMessageStyle*                 ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGNotificationMessageStyle.AddMessage
struct UAGNotificationMessageStyle_AddMessage_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FDateTime                                   Timestamp;                                                 // 0x0000(0x0008)  (Parm, ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     sender;                                                    // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGNotificationMessageStyle*                 ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGPickersBPL.TakeScreenShot
struct UAGPickersBPL_TakeScreenShot_Params
{
	struct FScriptDelegate                             onScreenShotTakenCallback;                                 // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onErrorCallback;                                           // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	bool                                               ShowUI;                                                    // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGPickersBPL.SaveImageToGallery
struct UAGPickersBPL_SaveImageToGallery_Params
{
	class UTexture2D*                                  Image;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Filename;                                                  // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGPickersBPL.PickPhotoFromCamera
struct UAGPickersBPL_PickPhotoFromCamera_Params
{
	bool                                               shouldGenerateThumbnails;                                  // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onPhotoPickedCallback;                                     // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onPhotoPickErrorCallback;                                  // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGPickersBPL.PickImageFromGallery
struct UAGPickersBPL_PickImageFromGallery_Params
{
	int                                                quality;                                                   // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EImageSize>             MaxSize;                                                   // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               shouldGenerateThumbnails;                                  // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onImagePickedCallback;                                     // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onImagePickErrorCallback;                                  // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGPickersBPL.PickFilesFromLocalStorage
struct UAGPickersBPL_PickFilesFromLocalStorage_Params
{
	bool                                               allowMultiple;                                             // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             OnFilesPickedCallback;                                     // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             OnFilesPickErrorCallback;                                  // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGPickersBPL.GetTextureFromPath
struct UAGPickersBPL_GetTextureFromPath_Params
{
	struct FString                                     imagePath;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onTextureReadyCallback;                                    // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             onTextureErrorCallback;                                    // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGPickersBPL.GetPhotoDataFromCamera
struct UAGPickersBPL_GetPhotoDataFromCamera_Params
{
	bool                                               shouldGenerateThumbnails;                                  // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             OnPhotoTakenCallback;                                      // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             OnPhotoTakeErrorCallback;                                  // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGPickersBPL.GetChosenImagesData
struct UAGPickersBPL_GetChosenImagesData_Params
{
	int                                                quality;                                                   // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EImageSize>             MaxSize;                                                   // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               shouldGenerateThumbnails;                                  // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               allowMultiple;                                             // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             OnImagesPickedCallback;                                    // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
	struct FScriptDelegate                             OnImagesPickErrorCallback;                                 // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NoDestructor, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGPickersBPL.ClearTexture
struct UAGPickersBPL_ClearTexture_Params
{
	class UTexture2D*                                  Texture;                                                   // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGProgressDialogBPL.CreateProgressDialog
struct UAGProgressDialogBPL_CreateProgressDialog_Params
{
};

// Function AndroidGoodies.AGProgressDialogInterface.Show
struct UAGProgressDialogInterface_Show_Params
{
	struct FAGProgressDialogData                       progressDialogData;                                        // 0x0000(0x0030)  (Parm, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGProgressDialogInterface.SetProgress
struct UAGProgressDialogInterface_SetProgress_Params
{
	int                                                Progress;                                                  // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGProgressDialogInterface.Dismiss
struct UAGProgressDialogInterface_Dismiss_Params
{
};

// Function AndroidGoodies.ScreenShotHelper.ProcessScreenShot
struct UScreenShotHelper_ProcessScreenShot_Params
{
	int                                                InSizeX;                                                   // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                InSizeY;                                                   // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<struct FColor>                              InImageData;                                               // 0x0000(0x0010)  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.TweetTextWithImage
struct UAGShareBPL_TweetTextWithImage_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UTexture2D*                                  Image;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.TweetText
struct UAGShareBPL_TweetText_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.ShareVideo
struct UAGShareBPL_ShareVideo_Params
{
	struct FString                                     videoPath;                                                 // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               showChooser;                                               // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     chooserTitle;                                              // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.ShareTextWithImage
struct UAGShareBPL_ShareTextWithImage_Params
{
	struct FString                                     Subject;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UTexture2D*                                  Image;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               showChooser;                                               // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     chooserTitle;                                              // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.ShareText
struct UAGShareBPL_ShareText_Params
{
	struct FString                                     Subject;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               showChooser;                                               // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     chooserTitle;                                              // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.ShareInstagram
struct UAGShareBPL_ShareInstagram_Params
{
	class UTexture2D*                                  Image;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.ShareImage
struct UAGShareBPL_ShareImage_Params
{
	class UTexture2D*                                  Image;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               showChooser;                                               // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     chooserTitle;                                              // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendWhatsAppText
struct UAGShareBPL_SendWhatsAppText_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendWhatsAppImage
struct UAGShareBPL_SendWhatsAppImage_Params
{
	class UTexture2D*                                  Image;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendViberText
struct UAGShareBPL_SendViberText_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendViberImage
struct UAGShareBPL_SendViberImage_Params
{
	class UTexture2D*                                  Image;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendTelegramText
struct UAGShareBPL_SendTelegramText_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendTelegramImage
struct UAGShareBPL_SendTelegramImage_Params
{
	class UTexture2D*                                  Image;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendSmsWithDefaultApp
struct UAGShareBPL_SendSmsWithDefaultApp_Params
{
	struct FString                                     phoneNumber;                                               // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Message;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               showChooser;                                               // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     chooserTitle;                                              // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendSmsSilently
struct UAGShareBPL_SendSmsSilently_Params
{
	struct FString                                     phoneNumber;                                               // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Message;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendMultipleImagesEMail
struct UAGShareBPL_SendMultipleImagesEMail_Params
{
	struct FAGShareEmailData                           emailData;                                                 // 0x0000(0x0058)  (Parm, NativeAccessSpecifierPublic)
	TArray<class UTexture2D*>                          extraImages;                                               // 0x0000(0x0010)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	bool                                               showChooser;                                               // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     chooserTitle;                                              // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendFacebookText
struct UAGShareBPL_SendFacebookText_Params
{
	struct FString                                     Text;                                                      // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendFacebookImage
struct UAGShareBPL_SendFacebookImage_Params
{
	class UTexture2D*                                  Image;                                                     // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGShareBPL.SendEMail
struct UAGShareBPL_SendEMail_Params
{
	struct FAGShareEmailData                           emailData;                                                 // 0x0000(0x0058)  (Parm, NativeAccessSpecifierPublic)
	bool                                               showChooser;                                               // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     chooserTitle;                                              // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGToastBPL.ShowToast
struct UAGToastBPL_ShowToast_Params
{
	struct FString                                     Message;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TEnumAsByte<AndroidGoodies_EToastLength>           Length;                                                    // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGVibrationEffect.VibrationEffectWaveFormWithAmplitudes
struct UAGVibrationEffect_VibrationEffectWaveFormWithAmplitudes_Params
{
	TArray<float>                                      timings;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	TArray<int>                                        amplitudes;                                                // 0x0000(0x0010)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	int                                                Repeat;                                                    // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGVibrationEffect*                          ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGVibrationEffect.VibrationEffectWaveForm
struct UAGVibrationEffect_VibrationEffectWaveForm_Params
{
	TArray<float>                                      timings;                                                   // 0x0000(0x0010)  (Parm, ZeroConstructor, NativeAccessSpecifierPublic)
	int                                                Repeat;                                                    // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGVibrationEffect*                          ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

// Function AndroidGoodies.AGVibrationEffect.VibrationEffectOneShot
struct UAGVibrationEffect_VibrationEffectOneShot_Params
{
	float                                              Seconds;                                                   // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                Amplitude;                                                 // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	class UAGVibrationEffect*                          ReturnValue;                                               // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ClassSelect_Slot.ClassSelect_Slot_C.PreConstruct
struct UClassSelect_Slot_C_PreConstruct_Params
{
	bool                                               IsDesignTime;                                              // 0x0000(0x0001)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function ClassSelect_Slot.ClassSelect_Slot_C.Construct
struct UClassSelect_Slot_C_Construct_Params
{
};

// Function ClassSelect_Slot.ClassSelect_Slot_C.ExecuteUbergraph_ClassSelect_Slot
struct UClassSelect_Slot_C_ExecuteUbergraph_ClassSelect_Slot_Params
{
	int                                                EntryPoint;                                                // 0x0000(0x0004)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

﻿#pragma once

// Name: Mir4, Version: 2


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function B_Login.B_Login_C.Display_OpenWidget
struct UB_Login_C_Display_OpenWidget_Params
{
};

// Function B_Login.B_Login_C.Display_ClearAll
struct UB_Login_C_Display_ClearAll_Params
{
};

// Function B_Login.B_Login_C.Display_ShowLoading
struct UB_Login_C_Display_ShowLoading_Params
{
};

// Function B_Login.B_Login_C.Display_EndLoading
struct UB_Login_C_Display_EndLoading_Params
{
};

// Function B_Login.B_Login_C.Display_ShowLoginInfo
struct UB_Login_C_Display_ShowLoginInfo_Params
{
};

// Function B_Login.B_Login_C.Display_ShowTouchNotice
struct UB_Login_C_Display_ShowTouchNotice_Params
{
};

// Function B_Login.B_Login_C.ExecuteUbergraph_B_Login
struct UB_Login_C_ExecuteUbergraph_B_Login_Params
{
	int                                                EntryPoint;                                                // 0x0000(0x0004)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
